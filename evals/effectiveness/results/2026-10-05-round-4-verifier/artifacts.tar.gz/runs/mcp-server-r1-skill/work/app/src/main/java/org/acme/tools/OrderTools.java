package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Order-lookup operations. One implementation backs both the model (these langchain4j
 * {@code @Tool} methods) and remote MCP clients (see {@code OrderMcpServer}).
 */
@ApplicationScoped
public class OrderTools {

    static final int MAX_RECENT = 20;

    @Inject
    OrderRepository repository;

    @Tool("Gets the status of an order by its id, e.g. ORD-1001. Returns null when the order does not exist.")
    @RunOnVirtualThread // a real lookup would be blocking I/O
    public Order getOrderStatus(@P("The order id") String orderId) {
        return repository.findById(orderId).orElse(null);
    }

    @Tool("Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return (1-20)") int limit) {
        return repository.recentForCustomer(customerId, Math.min(Math.max(limit, 1), MAX_RECENT));
    }
}
