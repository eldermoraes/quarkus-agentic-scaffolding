package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.acme.dto.Order.OrderStatus;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

/** Wiring smoke test: boots the app without calling the model, so no Ollama is needed. */
@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void getOrderStatus() {
        assertEquals(OrderStatus.SHIPPED, tools.getOrderStatus("ORD-1002").status());
        assertNull(tools.getOrderStatus("nope"));
    }

    @Test
    void listRecentOrdersIsNewestFirstAndLimited() {
        var recent = tools.listRecentOrders("CUST-1", 2);
        assertEquals(2, recent.size());
        assertEquals("ORD-1003", recent.get(0).id());
    }
}
