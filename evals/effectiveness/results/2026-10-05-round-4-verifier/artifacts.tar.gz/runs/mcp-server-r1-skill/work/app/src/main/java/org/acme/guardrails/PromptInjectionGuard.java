package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects over-long input and smuggled delimiter markup before the model is called. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final int MAX_INPUT_CHARS = 4_000;
    private static final int TEMPLATE_TAGS = 4;

    /** A closing tag inside free text would end the delimited region early. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(customer|question)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // The rendered prompt holds exactly the template's own four tags; any more were smuggled in.
        if (DELIMITER_MARKUP.matcher(text).results().count() > TEMPLATE_TAGS) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
