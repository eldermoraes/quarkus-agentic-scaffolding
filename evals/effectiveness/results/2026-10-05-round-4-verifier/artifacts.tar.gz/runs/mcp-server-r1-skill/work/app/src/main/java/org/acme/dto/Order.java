package org.acme.dto;

import java.math.BigDecimal;
import java.time.Instant;

/** An order as returned to tools, MCP clients and the model. */
public record Order(
        String id,
        String customerId,
        OrderStatus status,
        BigDecimal total,
        Instant placedAt) {

    public enum OrderStatus {
        PENDING, PAID, SHIPPED, DELIVERED, CANCELLED
    }
}
