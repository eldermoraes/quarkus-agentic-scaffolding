package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;

/*
 * MCP server — offers the order lookups to remote MCP clients over Streamable HTTP at /mcp.
 * In production, put /mcp behind the application's access layer (HTTP auth policies or a gateway).
 * These methods delegate to OrderTools so one implementation backs both MCP and the assistant.
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(name = "get_order_status", description = "Gets the status of an order by its id, e.g. ORD-1001. Returns null when the order does not exist.")
    @RunOnVirtualThread
    public Order getOrderStatus(
            @ToolArg(description = "The order id") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(name = "list_recent_orders", description = "Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return (1-20)", required = false, defaultValue = "5") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
