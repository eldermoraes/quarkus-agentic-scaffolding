package org.acme.tools;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.Order.OrderStatus;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store seeded with sample data. */
@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderRepository() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, new BigDecimal("59.90"), now.minus(30, ChronoUnit.DAYS)));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, new BigDecimal("120.00"), now.minus(3, ChronoUnit.DAYS)));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PENDING, new BigDecimal("15.25"), now.minus(1, ChronoUnit.HOURS)));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.PAID, new BigDecimal("310.40"), now.minus(2, ChronoUnit.DAYS)));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.CANCELLED, new BigDecimal("42.00"), now.minus(10, ChronoUnit.DAYS)));
    }

    public void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(id).map(orders::get);
    }

    /** Most recent first, at most {@code limit} entries. */
    public List<Order> recentForCustomer(String customerId, int limit) {
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(limit, 0))
                .toList();
    }
}
