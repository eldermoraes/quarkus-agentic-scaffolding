package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.dto.BriefReport;
import org.acme.workflow.BriefReviewService;

/** REST edge: blank or over-long briefs are rejected before any model call. */
@Path("/review")
public class BriefReviewResource {

    public record BriefRequest(String brief) {}

    private static final int MAX_BRIEF_CHARS = 8_000;

    @Inject
    BriefReviewService service;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public BriefReport review(BriefRequest request) {
        if (request == null || request.brief() == null || request.brief().isBlank()) {
            throw new BadRequestException("brief must not be empty");
        }
        if (request.brief().length() > MAX_BRIEF_CHARS) {
            throw new BadRequestException("brief exceeds " + MAX_BRIEF_CHARS + " characters");
        }
        return service.review(request.brief());
    }
}
