package org.acme.workflow;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.acme.dto.BriefReport;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;

/** Entry point to the workflow; declarative fault tolerance wraps the whole multi-agent run. */
@ApplicationScoped
public class BriefReviewService {

    @Inject
    BriefReviewAgent agent;

    // Generous: the two reviewers run in parallel but each is a full model round-trip.
    @Timeout(180_000)
    @Retry(maxRetries = 1)
    public BriefReport review(String brief) {
        return agent.review(brief);
    }
}
