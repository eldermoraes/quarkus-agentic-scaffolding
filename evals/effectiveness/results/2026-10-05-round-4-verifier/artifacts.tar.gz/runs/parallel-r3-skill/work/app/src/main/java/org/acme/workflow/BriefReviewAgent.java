package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.acme.dto.BriefReport;
import org.acme.dto.BusinessReview;
import org.acme.dto.TechnicalReview;

/** Runs both reviewers concurrently; @Output combines their results into one report. */
public interface BriefReviewAgent {

    @ParallelAgent(outputKey = "briefReport", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    BriefReport review(@V("brief") String brief);

    @Output
    static BriefReport assemble(AgenticScope scope) {
        return new BriefReport(
                (TechnicalReview) scope.readState("technicalReview"),
                (BusinessReview) scope.readState("businessReview"));
    }
}
