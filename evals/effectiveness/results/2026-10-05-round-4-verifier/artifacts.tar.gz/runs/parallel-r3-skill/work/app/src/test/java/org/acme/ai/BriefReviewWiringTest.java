package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.workflow.BriefReviewAgent;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: boots the app and injects the AI services; never calls the model. */
@QuarkusTest
class BriefReviewWiringTest {

    @Inject
    TechnicalReviewer technicalReviewer;

    @Inject
    BusinessReviewer businessReviewer;

    @Inject
    BriefReviewAgent workflow;

    @Test
    void aiServicesAreWired() {
        assertNotNull(technicalReviewer);
        assertNotNull(businessReviewer);
        assertNotNull(workflow);
    }
}
