package org.acme.dto;

/** The single combined report: both reviews side by side. */
public record BriefReport(TechnicalReview technical, BusinessReview business) {}
