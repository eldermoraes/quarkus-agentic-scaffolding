package org.acme.dto;

import java.util.List;

public record BusinessReview(String valueAssessment, List<String> risks, List<String> recommendations) {}
