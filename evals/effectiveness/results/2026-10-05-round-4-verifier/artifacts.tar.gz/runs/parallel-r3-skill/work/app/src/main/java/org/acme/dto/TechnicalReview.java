package org.acme.dto;

import java.util.List;

public record TechnicalReview(String feasibility, List<String> risks, List<String> recommendations) {}
