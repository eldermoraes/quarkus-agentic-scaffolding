package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Rejects over-long input, reserved delimiter markup, and a known injection marker. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    // A closing tag smuggled inside the text would end the delimited region early.
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(ticket|problem|request|question|text)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 40) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // Strip the template's own <question> wrapper before checking for smuggled markup.
        String body = text.replaceFirst("^<question>\\n", "").replaceFirst("\\n</question>$", "");
        if (DELIMITER_MARKUP.matcher(body).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (body.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
