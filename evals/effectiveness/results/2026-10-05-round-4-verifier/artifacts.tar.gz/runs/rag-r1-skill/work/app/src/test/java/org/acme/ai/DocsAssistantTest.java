package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: boots the app and injects the AI service; never calls the model. */
@QuarkusTest
class DocsAssistantTest {

    @Inject
    DocsAssistant assistant;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }
}
