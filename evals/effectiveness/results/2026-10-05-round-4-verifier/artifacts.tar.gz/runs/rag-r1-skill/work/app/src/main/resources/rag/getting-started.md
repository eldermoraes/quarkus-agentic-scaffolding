# Getting Started with Acme Widgets

Acme Widgets is a small service for managing widget inventories.

## Installation

Download the latest release archive, unpack it, and run `./widgets start`.
The service listens on port 7070 by default.

## Configuration

Settings live in `widgets.conf`. The most common options are:

- `port`: the HTTP port (default 7070).
- `data-dir`: where inventory data is stored (default `./data`).
- `log-level`: one of `DEBUG`, `INFO`, `WARN` (default `INFO`).

## Support

Report problems at support@acme.example. Support is available on weekdays
from 9:00 to 17:00 UTC.
