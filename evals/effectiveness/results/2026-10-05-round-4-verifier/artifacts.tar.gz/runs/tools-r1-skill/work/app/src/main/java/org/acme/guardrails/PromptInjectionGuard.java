package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Rejects oversized input, smuggled delimiter markup and obvious injection markers before the
 * customer's message reaches the model.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    // Keep in step with ChatResource.MAX_MESSAGE_CHARS (the template wraps the message, so leave headroom).
    private static final int MAX_INPUT_CHARS = 5_000;

    /** A closing tag inside the text would end the delimited region early, so reject the markup. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(customer_message)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(text).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
