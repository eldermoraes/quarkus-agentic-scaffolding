package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

/** Wiring smoke test: boots the app and never calls the model, so no Ollama is needed. */
@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void shippingLookup() {
        assertEquals(OrderTools.ShippingState.SHIPPED, tools.getShippingStatus("a1002").state());
    }

    @Test
    void refundIsOpenedOnceAndRejectsUnknownOrders() {
        assertTrue(tools.openRefundRequest("A1001", "Damaged item").opened());
        assertFalse(tools.openRefundRequest("A1001", "Damaged item").opened());
        assertFalse(tools.openRefundRequest("ZZZ", "Damaged item").opened());
    }
}
