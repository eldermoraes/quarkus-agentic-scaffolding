package org.acme.rest;

import org.acme.ai.SupportAssistant;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/**
 * REST edge of the support assistant. Blank or over-long input is rejected before any model call;
 * anything that escapes becomes an RFC 9457 problem response (quarkus-http-problem).
 */
@Path("/chat")
public class ChatResource {

    public record ChatRequest(String conversationId, String message) {}

    public record ChatResponse(String conversationId, String answer) {}

    // Keep in step with PromptInjectionGuard.MAX_INPUT_CHARS.
    private static final int MAX_MESSAGE_CHARS = 4_000;
    private static final int MAX_ID_CHARS = 100;

    @Inject
    SupportAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ChatResponse chat(ChatRequest request) {
        if (request == null || request.conversationId() == null || request.conversationId().isBlank()) {
            throw new BadRequestException("conversationId must not be empty");
        }
        if (request.conversationId().length() > MAX_ID_CHARS) {
            throw new BadRequestException("conversationId exceeds " + MAX_ID_CHARS + " characters");
        }
        if (request.message() == null || request.message().isBlank()) {
            throw new BadRequestException("message must not be empty");
        }
        if (request.message().length() > MAX_MESSAGE_CHARS) {
            throw new BadRequestException("message exceeds " + MAX_MESSAGE_CHARS + " characters");
        }
        return new ChatResponse(request.conversationId(),
                assistant.chat(request.conversationId(), request.message()));
    }
}
