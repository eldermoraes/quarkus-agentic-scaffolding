package org.acme.tools;

import java.time.LocalDate;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;

/** Order lookup and refund tools backed by in-memory data. */
@ApplicationScoped
public class OrderTools {

    public enum ShippingState { PROCESSING, SHIPPED, DELIVERED }

    public record ShippingStatus(String orderId, ShippingState state, String carrier,
            String trackingNumber, LocalDate estimatedDelivery) {}

    public record RefundResult(boolean opened, String refundId, String message) {}

    private final Map<String, ShippingStatus> orders = Map.of(
            "A1001", new ShippingStatus("A1001", ShippingState.DELIVERED, "UPS", "1Z999AA10123456784", LocalDate.of(2026, 9, 28)),
            "A1002", new ShippingStatus("A1002", ShippingState.SHIPPED, "FedEx", "794644790132", LocalDate.of(2026, 10, 9)),
            "A1003", new ShippingStatus("A1003", ShippingState.PROCESSING, null, null, LocalDate.of(2026, 10, 14)));

    private final Map<String, RefundResult> refunds = new ConcurrentHashMap<>();

    @Tool("Looks up the shipping status of an order by its order id (for example A1001)")
    @RunOnVirtualThread
    public ShippingStatus getShippingStatus(@P("The order id") String orderId) {
        ShippingStatus status = orders.get(normalize(orderId));
        if (status == null) {
            throw new IllegalArgumentException("No order found with id " + orderId);
        }
        return status;
    }

    @Tool("Opens a refund request for an order. Only call when the customer explicitly asks for a refund and gave a reason")
    @RunOnVirtualThread
    public RefundResult openRefundRequest(@P("The order id") String orderId,
            @P("The customer's reason for the refund") String reason) {
        String id = normalize(orderId);
        if (!orders.containsKey(id)) {
            return new RefundResult(false, null, "No order found with id " + orderId);
        }
        if (reason == null || reason.isBlank()) {
            return new RefundResult(false, null, "A reason is required to open a refund request");
        }
        // putIfAbsent keeps this idempotent: one refund request per order.
        RefundResult opened = new RefundResult(true, "R-" + id, "Refund request opened for order " + id);
        RefundResult existing = refunds.putIfAbsent(id, opened);
        return existing == null
                ? opened
                : new RefundResult(false, existing.refundId(), "A refund request already exists for order " + id);
    }

    private static String normalize(String orderId) {
        return orderId == null ? "" : orderId.trim().toUpperCase();
    }
}
