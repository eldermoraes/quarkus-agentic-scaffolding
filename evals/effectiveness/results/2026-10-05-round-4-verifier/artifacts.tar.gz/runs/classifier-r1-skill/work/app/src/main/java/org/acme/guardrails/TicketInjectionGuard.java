package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Validates the customer text inside the {@code <ticket>} delimiters of the prompt. The
 * application's own opening and closing tags are stripped first; any further delimiter markup
 * in the text is rejected so it cannot close the data region early.
 */
@ApplicationScoped
public class TicketInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?ticket>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int start = text.indexOf("<ticket>");
        int end = text.lastIndexOf("</ticket>");
        String ticket = (start >= 0 && end > start) ? text.substring(start + 8, end) : text;

        if (ticket.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(ticket).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (ticket.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
