package org.acme.ai;

public enum Category {
    BILLING, TECHNICAL, OTHER
}
