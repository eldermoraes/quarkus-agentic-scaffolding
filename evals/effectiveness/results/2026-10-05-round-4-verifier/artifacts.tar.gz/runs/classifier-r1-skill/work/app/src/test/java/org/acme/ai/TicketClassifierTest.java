package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class TicketClassifierTest {

    @Inject
    TicketClassifier classifier;

    @Test
    void aiServiceIsWired() {
        // Boots the CDI container and AI-service proxy; no model call is made.
        assertNotNull(classifier);
    }
}
