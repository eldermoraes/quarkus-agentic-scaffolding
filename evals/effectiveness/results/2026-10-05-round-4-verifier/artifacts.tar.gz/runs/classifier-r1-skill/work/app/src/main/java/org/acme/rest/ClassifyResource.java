package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.Category;
import org.acme.ai.TicketClassifier;
import org.acme.guardrails.TicketInjectionGuard;

@Path("/classify")
public class ClassifyResource {

    public record ClassifyRequest(String ticket) {}

    public record ClassifyResponse(Category category) {}

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ClassifyResponse classify(ClassifyRequest request) {
        if (request == null || request.ticket() == null || request.ticket().isBlank()) {
            throw new BadRequestException("ticket must not be empty");
        }
        if (request.ticket().length() > TicketInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException(
                    "ticket exceeds " + TicketInjectionGuard.MAX_INPUT_CHARS + " characters");
        }
        return new ClassifyResponse(classifier.classify(request.ticket()));
    }
}
