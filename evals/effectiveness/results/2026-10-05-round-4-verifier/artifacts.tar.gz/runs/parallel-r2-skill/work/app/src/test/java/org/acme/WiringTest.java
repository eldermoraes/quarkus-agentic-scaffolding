package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.junit.jupiter.api.Test;

@QuarkusTest
class WiringTest {

    @Inject
    TechnicalReviewer technical;

    @Inject
    BusinessReviewer business;

    @Test
    void aiServicesAreWired() {
        assertNotNull(technical);
        assertNotNull(business);
    }
}
