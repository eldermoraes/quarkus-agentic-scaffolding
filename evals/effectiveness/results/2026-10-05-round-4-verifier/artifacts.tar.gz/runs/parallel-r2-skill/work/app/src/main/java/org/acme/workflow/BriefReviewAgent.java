package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.SequenceAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.ReportWriter;
import org.acme.dto.ReviewNotes;
import org.acme.dto.ReviewReport;

/** Sequence: parallel reviews -> summary. @Output assembles the single report from the scope. */
public interface BriefReviewAgent {

    @SequenceAgent(outputKey = "report", subAgents = { ParallelReviews.class, ReportWriter.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport assemble(AgenticScope scope) {
        return new ReviewReport(
                (ReviewNotes) scope.readState("technicalReview"),
                (ReviewNotes) scope.readState("businessReview"),
                (String) scope.readState("summary"));
    }
}
