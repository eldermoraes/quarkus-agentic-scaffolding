package org.acme.dto;

/** The combined report returned by POST /review. */
public record ReviewReport(ReviewNotes technical, ReviewNotes business, String summary) {}
