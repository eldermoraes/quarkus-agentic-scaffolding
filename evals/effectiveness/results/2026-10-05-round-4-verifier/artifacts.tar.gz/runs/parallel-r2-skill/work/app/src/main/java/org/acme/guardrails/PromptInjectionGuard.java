package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Input guardrail for externally originated free text (the product brief). */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 8_000;

    /**
     * The prompts wrap the brief in exactly one brief tag pair, so any further opening or closing
     * tag means the text smuggled markup that would end the delimited region early.
     */
    private static final Pattern BRIEF_TAG = Pattern.compile("</?brief>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 100) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (BRIEF_TAG.matcher(text).results().count() > 2) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
