# brief-review

Quarkus + LangChain4j (Ollama) multi-agent workflow: a technical reviewer and a business reviewer
analyse a product brief in parallel, and the results are combined into one report.

`POST /review` with a JSON body `{"brief": "..."}` returns `technical`, `business` and `summary`.

Requires a running Ollama with `qwen3:4b` and `qwen3:1.7b` pulled. Run with `./mvnw quarkus:dev`.
