package org.acme.dto;

import java.util.List;

/** Structured output of a reviewer agent. */
public record ReviewNotes(String verdict, List<String> strengths, List<String> risks, List<String> recommendations) {}
