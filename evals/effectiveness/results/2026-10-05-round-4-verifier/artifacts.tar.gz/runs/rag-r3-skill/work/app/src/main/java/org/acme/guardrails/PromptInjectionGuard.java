package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Rejects oversized questions, questions carrying the reserved delimiter markup, and an obvious
 * prompt-injection marker. Attach with {@code @InputGuardrails(PromptInjectionGuard.class)}.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    /** A smuggled closing tag would end the delimited region early, so the markup is rejected. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(question|context|document)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 32) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // The prompt template contributes exactly one <question>...</question> pair; any further
        // delimiter markup came from the caller.
        String inner = text.replaceFirst("(?is)^\\s*<question>", "").replaceFirst("(?is)</question>\\s*$", "");
        if (DELIMITER_MARKUP.matcher(inner).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (inner.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
