# Acme Widget Service — Getting Started

The Acme Widget Service lets teams create, track and retire widgets through a simple HTTP API.

## Authentication

Every request needs an API key sent in the `X-Api-Key` header. Keys are created in the
dashboard under **Settings > API Keys** and expire after 90 days. Rotate a key before it
expires by creating a new one and deleting the old one.

## Rate limits

The service allows 100 requests per minute per API key. Requests above the limit receive
HTTP 429 with a `Retry-After` header telling you how many seconds to wait.

## Creating a widget

Send `POST /widgets` with a JSON body containing `name` (required) and `color` (optional).
The response is HTTP 201 with the new widget's `id`.

## Support

Contact support at support@acme.example. Support hours are Monday to Friday, 09:00 to 17:00 UTC.
