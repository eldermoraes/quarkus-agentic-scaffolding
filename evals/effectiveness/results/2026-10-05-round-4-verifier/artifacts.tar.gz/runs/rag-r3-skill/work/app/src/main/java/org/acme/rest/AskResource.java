package org.acme.rest;

import dev.langchain4j.guardrail.GuardrailException;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.DocsAssistant;
import org.acme.guardrails.PromptInjectionGuard;

/**
 * REST edge: {@code POST /ask} with {@code {"question": "..."}}. Blank or over-long questions are
 * rejected before any model call. The blocking AI call runs on a virtual thread.
 */
@Path("/ask")
public class AskResource {

    public record AskRequest(String question) {}

    public record AskResponse(String answer) {}

    @Inject
    DocsAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public AskResponse ask(AskRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be empty");
        }
        if (request.question().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException(
                    "question exceeds " + PromptInjectionGuard.MAX_INPUT_CHARS + " characters");
        }
        try {
            return new AskResponse(assistant.ask(request.question()));
        } catch (GuardrailException e) {
            throw new BadRequestException("question rejected by input guardrail");
        }
    }
}
