package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guardrail for externally originated ticket text. Rejects over-long input, smuggled
 * delimiter markup (which could close the {@code <ticket>} span early) and a known injection marker.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    /** Keep in step with the limit enforced at the REST edge. */
    private static final int MAX_INPUT_CHARS = 4_000;

    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?ticket>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        // The user message wraps the ticket in a short template, so allow a little headroom.
        if (text.length() > MAX_INPUT_CHARS + 200) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // The template itself contributes exactly one opening and one closing tag.
        if (DELIMITER_MARKUP.matcher(text).results().count() > 2) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
