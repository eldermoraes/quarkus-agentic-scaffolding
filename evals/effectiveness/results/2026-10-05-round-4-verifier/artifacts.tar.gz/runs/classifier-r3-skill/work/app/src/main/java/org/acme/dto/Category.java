package org.acme.dto;

/** Support-ticket categories the classifier can return. */
public enum Category {
    BILLING,
    TECHNICAL,
    OTHER
}
