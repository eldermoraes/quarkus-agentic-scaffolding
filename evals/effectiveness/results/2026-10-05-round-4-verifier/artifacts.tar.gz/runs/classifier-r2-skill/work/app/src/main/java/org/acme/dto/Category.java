package org.acme.dto;

/** Support-ticket category produced by the classifier. */
public enum Category {
    BILLING,
    TECHNICAL,
    OTHER
}
