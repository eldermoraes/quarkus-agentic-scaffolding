package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.SupportAssistant;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void wiringWorks() {
        assertNotNull(assistant);
    }

    @Test
    void toolsUseInMemoryData() {
        assertTrue(tools.getShippingStatus("A1001").contains("SHIPPED"));
        assertTrue(tools.openRefundRequest("A1002", "broken").contains("opened"));
        assertTrue(tools.getShippingStatus("ZZZ").contains("No order"));
    }
}
