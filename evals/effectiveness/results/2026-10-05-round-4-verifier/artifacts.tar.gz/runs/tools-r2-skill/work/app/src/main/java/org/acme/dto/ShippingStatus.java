package org.acme.dto;

public enum ShippingStatus {
    PROCESSING, SHIPPED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
}
