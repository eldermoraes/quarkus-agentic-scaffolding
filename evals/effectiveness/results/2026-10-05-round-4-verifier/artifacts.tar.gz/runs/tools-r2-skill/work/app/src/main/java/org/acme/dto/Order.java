package org.acme.dto;

public record Order(String id, String customer, String item, ShippingStatus status, String carrier,
        String trackingNumber, String estimatedDelivery) {
}
