package org.acme.guardrails;

import java.util.List;
import java.util.Locale;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects over-long input and obvious attempts to override the system instructions. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final int MAX_LENGTH = 4000;
    private static final List<String> MARKERS = List.of("ignore previous instructions",
            "ignore all previous", "disregard your instructions", "reveal your system prompt",
            "</customer_message>");

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        // The template's own closing tag is always present once, so strip it before checking.
        String lower = text.toLowerCase(Locale.ROOT);
        if (text.length() > MAX_LENGTH) {
            return fatal("Message too long");
        }
        for (String marker : MARKERS) {
            int first = lower.indexOf(marker);
            if (first < 0) {
                continue;
            }
            boolean closingTag = marker.startsWith("</");
            if (!closingTag || lower.indexOf(marker, first + 1) >= 0) {
                return fatal("Message rejected");
            }
        }
        return success();
    }
}
