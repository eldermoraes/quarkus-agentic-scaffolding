package org.acme.tools;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.acme.dto.Order;
import org.acme.dto.RefundRequest;
import org.acme.dto.ShippingStatus;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order and refund data exposed to the model as tools. */
@ApplicationScoped
public class OrderTools {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    @PostConstruct
    void seed() {
        orders.put("A1001", new Order("A1001", "alice", "Wireless headphones", ShippingStatus.SHIPPED,
                "DHL", "DHL123456", "2026-10-09"));
        orders.put("A1002", new Order("A1002", "bob", "Mechanical keyboard", ShippingStatus.DELIVERED,
                "UPS", "UPS987654", "2026-10-01"));
        orders.put("A1003", new Order("A1003", "carol", "USB-C dock", ShippingStatus.PROCESSING,
                "n/a", "n/a", "2026-10-12"));
    }

    @Tool("Looks up the shipping status of an order by its order id (for example A1001)")
    @RunOnVirtualThread
    public String getShippingStatus(@P("The order id") String orderId) {
        Order order = orders.get(normalize(orderId));
        if (order == null) {
            return "No order found with id " + orderId;
        }
        return "Order %s (%s): status=%s, carrier=%s, tracking=%s, estimated delivery=%s".formatted(
                order.id(), order.item(), order.status(), order.carrier(), order.trackingNumber(),
                order.estimatedDelivery());
    }

    @Tool("Opens a refund request for an existing order. Only call after the customer has asked for a refund and given a reason")
    @RunOnVirtualThread
    public String openRefundRequest(@P("The order id") String orderId,
            @P("The customer's reason for the refund") String reason) {
        String id = normalize(orderId);
        Order order = orders.get(id);
        if (order == null) {
            return "Cannot open refund: no order found with id " + orderId;
        }
        if (order.status() == ShippingStatus.CANCELLED) {
            return "Cannot open refund: order " + id + " is already cancelled";
        }
        RefundRequest refund = new RefundRequest("R" + refundSeq.incrementAndGet(), id, reason, "OPEN");
        refunds.put(refund.refundId(), refund);
        return "Refund request %s opened for order %s (status %s)".formatted(refund.refundId(), id,
                refund.status());
    }

    private static String normalize(String orderId) {
        return orderId == null ? "" : orderId.trim().toUpperCase();
    }
}
