package org.acme.dto;

public record BriefInput(String brief) {}
