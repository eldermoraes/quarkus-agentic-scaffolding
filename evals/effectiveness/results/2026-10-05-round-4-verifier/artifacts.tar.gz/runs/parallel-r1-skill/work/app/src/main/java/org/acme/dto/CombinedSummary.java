package org.acme.dto;

/** What the synthesizer agent produces: the verdict and overall assessment. */
public record CombinedSummary(String verdict, String overview) {}
