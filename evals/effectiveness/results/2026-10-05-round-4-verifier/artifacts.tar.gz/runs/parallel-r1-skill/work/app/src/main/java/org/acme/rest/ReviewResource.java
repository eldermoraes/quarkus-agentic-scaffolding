package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.dto.BriefInput;
import org.acme.dto.ReviewReport;
import org.acme.workflow.BriefReviewAgent;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    /** Fail-fast edge limit, aligned by value with PromptInjectionGuard.MAX_INPUT_CHARS. */
    private static final int MAX_BRIEF_CHARS = 8_000;

    @Inject
    BriefReviewAgent reviewAgent;

    @POST
    @RunOnVirtualThread
    public ReviewReport review(BriefInput input) {
        if (input == null || input.brief() == null || input.brief().isBlank()) {
            throw new BadRequestException("Brief must not be empty.");
        }
        if (input.brief().length() > MAX_BRIEF_CHARS) {
            throw new BadRequestException("Brief exceeds the " + MAX_BRIEF_CHARS + "-character limit.");
        }
        return reviewAgent.review(input.brief());
    }
}
