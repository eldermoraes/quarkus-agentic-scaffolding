package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.SequenceAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.ReviewSynthesizer;
import org.acme.dto.BusinessReview;
import org.acme.dto.CombinedSummary;
import org.acme.dto.ReviewReport;
import org.acme.dto.TechnicalReview;

/** Sequence: parallel reviews -> synthesis. @Output assembles the report from the scope. */
public interface BriefReviewAgent {

    @SequenceAgent(outputKey = "report", subAgents = { ParallelReviewers.class, ReviewSynthesizer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport assemble(AgenticScope scope) {
        CombinedSummary summary = (CombinedSummary) scope.readState("combinedSummary");
        return new ReviewReport(
                (TechnicalReview) scope.readState("technicalReview"),
                (BusinessReview) scope.readState("businessReview"),
                summary.verdict(),
                summary.overview());
    }
}
