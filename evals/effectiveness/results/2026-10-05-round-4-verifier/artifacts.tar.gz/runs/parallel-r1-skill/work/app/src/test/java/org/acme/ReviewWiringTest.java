package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.acme.workflow.BriefReviewAgent;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: boots the container without calling the model. */
@QuarkusTest
class ReviewWiringTest {

    @Inject
    TechnicalReviewer technicalReviewer;

    @Inject
    BusinessReviewer businessReviewer;

    @Inject
    BriefReviewAgent reviewAgent;

    @Test
    void servicesAreWired() {
        assertNotNull(technicalReviewer);
        assertNotNull(businessReviewer);
        assertNotNull(reviewAgent);
    }
}
