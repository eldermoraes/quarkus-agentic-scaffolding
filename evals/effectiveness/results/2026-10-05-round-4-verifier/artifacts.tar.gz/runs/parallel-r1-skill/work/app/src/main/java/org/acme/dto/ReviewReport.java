package org.acme.dto;

/** The single combined report returned by POST /review. */
public record ReviewReport(
        TechnicalReview technical,
        BusinessReview business,
        String verdict,
        String overview) {}
