# Getting Started with Acme Widgets

Acme Widgets is a small service for managing widget inventory.

## Installation

Download the latest release from the Acme downloads page and run `acme-widgets start`.
The service listens on port 8080 by default.

## Configuration

Set the `ACME_DB_URL` environment variable to point to your PostgreSQL database.
The default log level is `INFO`; change it with `ACME_LOG_LEVEL`.

## Support

For help, open a ticket at support.acme.example or email support@acme.example.
Support hours are Monday to Friday, 9:00 to 17:00 UTC.
