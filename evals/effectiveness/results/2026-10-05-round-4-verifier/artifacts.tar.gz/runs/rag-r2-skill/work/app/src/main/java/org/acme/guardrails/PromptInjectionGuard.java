package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Rejects oversized input, smuggled delimiter markup and obvious injection markers. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    // A closing tag inside the text would end the delimited region early.
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(ticket|problem|request|question|text)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(text).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
