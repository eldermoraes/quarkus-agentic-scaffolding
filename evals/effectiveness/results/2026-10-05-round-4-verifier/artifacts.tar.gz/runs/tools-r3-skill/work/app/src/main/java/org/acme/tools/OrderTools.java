package org.acme.tools;

import org.acme.dto.RefundRequest;
import org.acme.store.OrderStore;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class OrderTools {

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of an order by its order id (for example A1001).")
    @RunOnVirtualThread
    public String getShippingStatus(@P("The order id, e.g. A1001") String orderId) {
        return store.findOrder(orderId)
                .map(o -> "Order %s (%s): status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s"
                        .formatted(o.id(), o.item(), o.status(), o.carrier(), o.trackingNumber(),
                                o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an order. Only call after the customer confirmed they want a refund and gave a reason.")
    @RunOnVirtualThread
    public String openRefundRequest(@P("The order id, e.g. A1001") String orderId,
            @P("The customer's reason for the refund") String reason) {
        if (store.findOrder(orderId).isEmpty()) {
            return "No order found with id " + orderId + "; refund not opened.";
        }
        RefundRequest r = store.openRefund(orderId, reason);
        return "Refund request %s is %s for order %s (reason: %s)".formatted(r.refundId(), r.state(),
                r.orderId(), r.reason());
    }
}
