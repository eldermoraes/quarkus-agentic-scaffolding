package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty, oversized, or obviously instruction-hijacking customer input. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final int MAX_LENGTH = 4000;
    private static final Pattern SUSPICIOUS = Pattern.compile(
            "(ignore|disregard|forget)\\s+(all\\s+)?(the\\s+)?(previous|prior|above)\\s+(instructions|rules)"
                    + "|reveal\\s+(your\\s+)?(system\\s+)?prompt|</?customer_message>",
            Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank() || text.length() > MAX_LENGTH + 100) {
            return failure("Message is empty or too long.");
        }
        // The prompt template wraps the text in <customer_message> once; strip that before scanning.
        String inner = text.replaceFirst("^\\s*<customer_message>", "").replaceFirst("</customer_message>\\s*$", "");
        if (SUSPICIOUS.matcher(inner).find()) {
            return failure("Message was rejected by the safety filter.");
        }
        return success();
    }
}
