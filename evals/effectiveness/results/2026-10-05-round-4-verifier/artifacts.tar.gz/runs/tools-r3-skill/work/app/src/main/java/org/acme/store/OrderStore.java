package org.acme.store;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.acme.dto.Order;
import org.acme.dto.Order.ShippingStatus;
import org.acme.dto.RefundRequest;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderStore {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderStore() {
        List.of(
                new Order("A1001", "Mechanical keyboard", ShippingStatus.SHIPPED, "DHL", "DHL-778812",
                        LocalDate.now().plusDays(3)),
                new Order("A1002", "USB-C dock", ShippingStatus.DELIVERED, "UPS", "UPS-123450",
                        LocalDate.now().minusDays(2)),
                new Order("A1003", "27-inch monitor", ShippingStatus.PROCESSING, "n/a", "n/a",
                        LocalDate.now().plusDays(7)))
                .forEach(o -> orders.put(o.id(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orders.get(orderId.trim().toUpperCase()));
    }

    /** Opens a refund; an already-open refund for the same order is returned instead of duplicated. */
    public RefundRequest openRefund(String orderId, String reason) {
        String id = orderId.trim().toUpperCase();
        return refunds.computeIfAbsent(id,
                k -> new RefundRequest("R" + refundSeq.incrementAndGet(), k, reason, "OPEN"));
    }
}
