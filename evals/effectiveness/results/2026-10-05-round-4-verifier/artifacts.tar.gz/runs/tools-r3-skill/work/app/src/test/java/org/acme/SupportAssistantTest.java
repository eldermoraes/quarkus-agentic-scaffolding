package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.SupportAssistant;
import org.acme.store.OrderStore;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderStore store;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void refundIsIdempotentPerOrder() {
        var first = store.openRefund("A1002", "damaged");
        assertTrue(first.refundId().startsWith("R"));
        assertNotNull(store.findOrder("a1002").orElse(null));
    }
}
