package org.acme.rest;

import org.acme.ai.OrderAssistant;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/** REST edge for the order assistant. Blank or over-long input is rejected before any model call. */
@Path("/assistant")
public class AssistantResource {

    public record AssistantRequest(String customerId, String question) {}

    public record AssistantResponse(String answer) {}

    private static final int MAX_QUESTION_CHARS = 4_000;
    private static final int MAX_CUSTOMER_ID_CHARS = 64;

    @Inject
    OrderAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread // blocks for the model round-trip and every tool round-trip
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.customerId() == null || request.customerId().isBlank()) {
            throw new BadRequestException("customerId must not be empty");
        }
        if (request.customerId().length() > MAX_CUSTOMER_ID_CHARS) {
            throw new BadRequestException("customerId exceeds " + MAX_CUSTOMER_ID_CHARS + " characters");
        }
        if (request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be empty");
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            throw new BadRequestException("question exceeds " + MAX_QUESTION_CHARS + " characters");
        }
        return new AssistantResponse(assistant.answer(request.customerId().trim(), request.question()));
    }
}
