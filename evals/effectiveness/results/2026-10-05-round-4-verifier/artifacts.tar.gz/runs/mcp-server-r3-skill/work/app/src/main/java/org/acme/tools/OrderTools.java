package org.acme.tools;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/*
 * Order lookups backed by an in-memory map. This one bean backs both consumers: the assistant's
 * model (these @Tool methods) and remote MCP clients (org.acme.mcp.OrderMcpServer delegates here).
 */
@ApplicationScoped
public class OrderTools {

    private static final int MAX_RECENT = 20;

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add("A1001", "C-1", "DELIVERED", now.minus(30, ChronoUnit.DAYS), "59.90");
        add("A1002", "C-1", "SHIPPED", now.minus(3, ChronoUnit.DAYS), "120.00");
        add("A1003", "C-1", "PROCESSING", now.minus(1, ChronoUnit.DAYS), "15.50");
        add("B2001", "C-2", "CANCELLED", now.minus(10, ChronoUnit.DAYS), "300.00");
        add("B2002", "C-2", "SHIPPED", now.minus(2, ChronoUnit.DAYS), "42.00");
    }

    private void add(String id, String customerId, String status, Instant placedAt, String total) {
        orders.put(id, new Order(id, customerId, status, placedAt, new BigDecimal(total)));
    }

    @Tool("Gets the current status of an order by its order id")
    @RunOnVirtualThread // a real store is a DB or REST call: keep blocking I/O off the event loop
    public OrderStatus getOrderStatus(@P("The order id, e.g. A1001") String orderId) {
        Order order = orderId == null ? null : orders.get(orderId.trim());
        return new OrderStatus(orderId, order == null ? "NOT_FOUND" : order.status());
    }

    @Tool("Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. C-1") String customerId,
            @P("Maximum number of orders to return (1-20)") int limit) {
        if (customerId == null) {
            return List.of();
        }
        int bounded = Math.max(1, Math.min(limit, MAX_RECENT));
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId.trim()))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(bounded)
                .toList();
    }
}
