package org.acme.dto;

/** Result of a status lookup; {@code status} is {@code NOT_FOUND} for an unknown order id. */
public record OrderStatus(String orderId, String status) {}
