package org.acme;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.acme.ai.OrderAssistant;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        // Booting builds the AI-service proxy; no model call happens here.
        assertNotNull(assistant);
    }

    @Test
    void toolsLookUpOrders() {
        assertEquals("SHIPPED", tools.getOrderStatus("A1002").status());
        assertEquals("NOT_FOUND", tools.getOrderStatus("nope").status());
        assertEquals("A1003", tools.listRecentOrders("C-1", 5).getFirst().id());
    }

    @Test
    void blankQuestionIsRejectedBeforeModelCall() {
        given().contentType("application/json")
                .body("{\"customerId\":\"C-1\",\"question\":\"  \"}")
                .when().post("/assistant")
                .then().statusCode(400);
    }
}
