package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;

/*
 * MCP server: offers the order operations to remote MCP clients over Streamable HTTP at /mcp.
 * io.quarkiverse.mcp.server.Tool is for REMOTE clients; the assistant's own model uses the
 * dev.langchain4j @Tool methods on the same OrderTools bean. In production, put /mcp behind the
 * application's access layer (HTTP auth policy or a gateway).
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    // Explicit names: the default (method name) would collide with the LangChain4j tools on OrderTools.
    @Tool(name = "get_order_status", description = "Gets the current status of an order by its order id")
    @RunOnVirtualThread
    public OrderStatus getOrderStatus(
            @ToolArg(description = "The order id, e.g. A1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(name = "list_recent_orders", description = "Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. C-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return (1-20)", required = false,
                    defaultValue = "5") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
