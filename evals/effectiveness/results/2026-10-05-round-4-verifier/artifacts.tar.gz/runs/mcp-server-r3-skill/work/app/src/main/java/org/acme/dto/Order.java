package org.acme.dto;

import java.math.BigDecimal;
import java.time.Instant;

/** An order held in the in-memory store. */
public record Order(String id, String customerId, String status, Instant placedAt, BigDecimal total) {}
