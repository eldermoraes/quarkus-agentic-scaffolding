# order-tools

Quarkus + LangChain4j (Ollama) app with order-lookup operations backed by an in-memory map
(`OrderRepository`, seeded with `ORD-1001..1003` for `CUST-1` and `ORD-2001..2002` for `CUST-2`).

## Features

- **MCP server** (Streamable HTTP, `/mcp`): tools `get_order_status(orderId)` and
  `list_recent_orders(customerId, limit)` (`org.acme.mcp.OrderMcpServer`).
- **`POST /assistant`**: body `{"customerId": "CUST-1", "question": "Where is order ORD-1002?"}`;
  an LLM assistant (`OrderAssistant`, model `main`) answers using the same operations as tools
  (`org.acme.tools.OrderTools`).
- RFC 9457 problem responses, OpenAPI at `/q/openapi`.

## Run

Requires Ollama (`ollama serve`, `ollama pull qwen3:4b`).

```
./mvnw quarkus:dev
```

Tests boot the app without calling a model: `./mvnw test`.

Production note: `/mcp` and `/assistant` ship open; put them behind auth before exposing them.
