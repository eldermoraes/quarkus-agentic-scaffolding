package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;
import org.acme.tools.OrderTools.OrderStatusResult;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;

/*
 * MCP server: offers the order-lookup operations to remote MCP clients over Streamable HTTP
 * at /mcp. In production, put /mcp behind the application's access layer (see the note in
 * application.properties). io.quarkiverse.mcp.server.Tool offers a method to REMOTE MCP clients;
 * dev.langchain4j.agent.tool.Tool (OrderTools) offers it to this app's own model.
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(name = "get_order_status", description = "Gets the current status of an order by its id")
    @RunOnVirtualThread
    public OrderStatusResult getOrderStatus(
            @ToolArg(name = "orderId", description = "The order id, e.g. ORD-1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(name = "list_recent_orders", description = "Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @ToolArg(name = "customerId", description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(name = "limit", description = "Maximum number of orders to return (1-20)",
                    required = false, defaultValue = "5") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
