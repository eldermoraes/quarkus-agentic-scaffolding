package org.acme.rest;

import org.acme.ai.OrderAssistant;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/*
 * REST edge for the OrderAssistant. The call blocks for every model and tool round-trip, so it
 * runs on a virtual thread (CLAUDE.md §2). Blank or over-long input is rejected before any model
 * call; escaping exceptions become RFC 9457 problem responses via quarkus-http-problem.
 */
@Path("/assistant")
public class AssistantResource {

    public record AssistantRequest(String customerId, String question) {}

    public record AssistantResponse(String answer) {}

    private static final int MAX_FIELD_CHARS = 2_000;

    @Inject
    OrderAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be empty");
        }
        if (request.question().length() > MAX_FIELD_CHARS
                || (request.customerId() != null && request.customerId().length() > MAX_FIELD_CHARS)) {
            throw new BadRequestException("input exceeds " + MAX_FIELD_CHARS + " characters");
        }
        String customerId = request.customerId() == null || request.customerId().isBlank()
                ? "unknown" : request.customerId();
        return new AssistantResponse(assistant.answer(customerId, request.question()));
    }
}
