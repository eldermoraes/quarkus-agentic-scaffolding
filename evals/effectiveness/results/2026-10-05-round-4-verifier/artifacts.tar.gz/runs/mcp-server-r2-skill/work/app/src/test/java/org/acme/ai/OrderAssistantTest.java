package org.acme.ai;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

/** Wiring smoke tests: none of these call the model, so no Ollama is needed. */
@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void toolsReadTheInMemoryStore() {
        assertEquals("SHIPPED", tools.getOrderStatus("ORD-1002").status());
        assertEquals(false, tools.getOrderStatus("NOPE").found());
        var recent = tools.listRecentOrders("CUST-1", 2);
        assertEquals(2, recent.size());
        assertTrue(recent.get(0).placedAt().isAfter(recent.get(1).placedAt()));
    }

    @Test
    void blankQuestionIsRejectedBeforeTheModel() {
        given().contentType("application/json").body("{\"question\":\" \"}")
                .when().post("/assistant")
                .then().statusCode(400);
    }
}
