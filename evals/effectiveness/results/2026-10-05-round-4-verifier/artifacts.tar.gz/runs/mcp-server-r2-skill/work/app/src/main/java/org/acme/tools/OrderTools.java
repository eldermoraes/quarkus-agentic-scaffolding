package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.service.OrderRepository;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/*
 * Order-lookup operations. One implementation backs both consumers:
 *   - the assistant's own model, via @RegisterAiService(tools = OrderTools.class)
 *   - remote MCP clients, via org.acme.mcp.OrderMcpServer, which delegates here.
 */
@ApplicationScoped
public class OrderTools {

    private static final int MAX_RECENT = 20;

    /** Typed result so the model receives structured, unambiguous output. */
    public record OrderStatusResult(boolean found, String orderId, String status) {}

    @Inject
    OrderRepository repository;

    @Tool("Gets the current status of an order by its id, e.g. ORD-1001")
    @RunOnVirtualThread // a real lookup hits a DB or REST client: keep blocking I/O off the event loop
    public OrderStatusResult getOrderStatus(@P("The order id") String orderId) {
        return repository.findById(orderId)
                .map(o -> new OrderStatusResult(true, o.id(), o.status().name()))
                .orElseGet(() -> new OrderStatusResult(false, orderId, "NOT_FOUND"));
    }

    @Tool("Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return (1-20)") int limit) {
        return repository.findRecentByCustomer(customerId, Math.min(Math.max(limit, 1), MAX_RECENT));
    }
}
