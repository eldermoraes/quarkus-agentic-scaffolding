package org.acme.service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.Order.OrderStatus;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store, seeded with sample data. Replace with a Panache repository for real data. */
@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, 59.90, now.minus(30, ChronoUnit.DAYS)));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, 120.00, now.minus(3, ChronoUnit.DAYS)));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PROCESSING, 18.50, now.minus(1, ChronoUnit.DAYS)));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.CANCELLED, 75.25, now.minus(10, ChronoUnit.DAYS)));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.DELIVERED, 240.00, now.minus(20, ChronoUnit.DAYS)));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return id == null ? Optional.empty() : Optional.ofNullable(orders.get(id.trim().toUpperCase()));
    }

    /** Most recent orders first, at most {@code limit}. */
    public List<Order> findRecentByCustomer(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        String wanted = customerId.trim();
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(wanted))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(limit, 0))
                .toList();
    }
}
