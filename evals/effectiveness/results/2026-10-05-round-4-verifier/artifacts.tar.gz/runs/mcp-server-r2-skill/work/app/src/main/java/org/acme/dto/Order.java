package org.acme.dto;

import java.time.Instant;

/** An order held in the in-memory store. */
public record Order(String id, String customerId, OrderStatus status, double total, Instant placedAt) {

    public enum OrderStatus { PROCESSING, SHIPPED, DELIVERED, CANCELLED }
}
