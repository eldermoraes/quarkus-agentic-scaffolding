package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guardrail for every entry method that receives externally originated text.
 * Keep MAX_INPUT_CHARS in step with the REST edge limit.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    // Slightly above the REST limit: the prompt wraps the ticket in delimiters and instructions.
    private static final int MAX_INPUT_CHARS = 5_000;

    /**
     * A closing tag smuggled inside the text would end the delimited region early and let the
     * rest read as instructions, so the delimiter markup is rejected outright.
     */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?ticket>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(text).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        // Honest heuristic — real projects tune this (allow-lists, a classifier model, ...).
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
