package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: boots the app and injects the AI service; no model call is made. */
@QuarkusTest
class TicketClassifierTest {

    @Inject
    TicketClassifier classifier;

    @Test
    void aiServiceIsWired() {
        assertNotNull(classifier);
    }
}
