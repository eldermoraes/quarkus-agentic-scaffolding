package org.acme.dto;

/** Closed set of ticket categories returned by the classifier. */
public enum Category {
    BILLING,
    TECHNICAL,
    OTHER
}
