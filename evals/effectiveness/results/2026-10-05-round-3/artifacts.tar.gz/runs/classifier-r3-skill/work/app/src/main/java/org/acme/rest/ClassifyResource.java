package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.TicketClassifier;
import org.acme.dto.Category;

/**
 * REST edge for the ticket classifier. Blank or over-long input is rejected before any model
 * call; anything that escapes becomes an RFC 9457 problem response (quarkus-http-problem).
 */
@Path("/classify")
public class ClassifyResource {

    /** Request body. */
    public record ClassifyRequest(String ticket) {}

    /** Response body. */
    public record ClassifyResponse(Category category) {}

    private static final int MAX_TICKET_CHARS = 4_000;

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ClassifyResponse classify(ClassifyRequest request) {
        if (request == null || request.ticket() == null || request.ticket().isBlank()) {
            throw new BadRequestException("ticket must not be empty");
        }
        if (request.ticket().length() > MAX_TICKET_CHARS) {
            throw new BadRequestException("ticket exceeds " + MAX_TICKET_CHARS + " characters");
        }
        return new ClassifyResponse(classifier.classify(request.ticket()));
    }
}
