package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.tools.SupportTools;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: boots the app without calling the model. */
@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    SupportTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void shippingStatusLookup() {
        assertEquals("IN_TRANSIT", tools.getShippingStatus("a-1002").status());
        assertFalse(tools.getShippingStatus("Z-0").found());
    }

    @Test
    void refundIsOpenedOnceThenRejected() {
        assertTrue(tools.openRefundRequest("A-1003", "damaged").opened());
        assertFalse(tools.openRefundRequest("A-1003", "damaged").opened());
        assertFalse(tools.openRefundRequest("A-1004", "changed mind").opened());
    }
}
