package org.acme.tools;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/** In-memory orders and refund requests. Replace with a Panache repository for real data. */
@ApplicationScoped
public class OrderStore {

    public enum ShippingStatus { PROCESSING, SHIPPED, IN_TRANSIT, DELIVERED, CANCELLED }

    public record Order(String orderId, ShippingStatus status, String carrier, String trackingNumber,
            LocalDate estimatedDelivery, double total) {}

    public record RefundRequest(String refundId, String orderId, String reason, String state) {}

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final List<RefundRequest> refunds = new CopyOnWriteArrayList<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderStore() {
        LocalDate today = LocalDate.now();
        put(new Order("A-1001", ShippingStatus.PROCESSING, null, null, today.plusDays(5), 49.90));
        put(new Order("A-1002", ShippingStatus.IN_TRANSIT, "DHL", "DHL123456", today.plusDays(2), 129.00));
        put(new Order("A-1003", ShippingStatus.DELIVERED, "UPS", "UPS987654", today.minusDays(3), 19.99));
        put(new Order("A-1004", ShippingStatus.CANCELLED, null, null, null, 75.00));
    }

    private void put(Order order) {
        orders.put(order.orderId(), order);
    }

    public Optional<Order> find(String orderId) {
        return Optional.ofNullable(orderId).map(id -> orders.get(id.trim().toUpperCase()));
    }

    public RefundRequest openRefund(String orderId, String reason) {
        RefundRequest refund = new RefundRequest("R-" + refundSeq.incrementAndGet(),
                orderId.trim().toUpperCase(), reason, "OPEN");
        refunds.add(refund);
        return refund;
    }

    public boolean hasOpenRefund(String orderId) {
        String id = orderId.trim().toUpperCase();
        return refunds.stream().anyMatch(r -> r.orderId().equals(id));
    }
}
