package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.acme.tools.OrderStore.Order;
import org.acme.tools.OrderStore.RefundRequest;

/**
 * Function-calling tools for the support assistant, wired via
 * {@code @RegisterAiService(tools = SupportTools.class)}. Results are small typed records so the
 * model receives unambiguous output; "not found" is a normal result, not an exception.
 */
@ApplicationScoped
public class SupportTools {

    public record ShippingInfo(boolean found, String orderId, String status, String carrier,
            String trackingNumber, String estimatedDelivery) {}

    public record RefundResult(boolean opened, String refundId, String message) {}

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of an order by its order id (for example A-1002)")
    @RunOnVirtualThread // a real lookup is blocking I/O; keep it off the event loop
    public ShippingInfo getShippingStatus(@P("The order id, for example A-1002") String orderId) {
        return store.find(orderId)
                .map(o -> new ShippingInfo(true, o.orderId(), o.status().name(), o.carrier(),
                        o.trackingNumber(),
                        o.estimatedDelivery() == null ? null : o.estimatedDelivery().toString()))
                .orElse(new ShippingInfo(false, orderId, "UNKNOWN", null, null, null));
    }

    @Tool("Opens a refund request for an order. Only call it after the customer has clearly asked for a refund and given a reason")
    @RunOnVirtualThread
    public RefundResult openRefundRequest(@P("The order id, for example A-1002") String orderId,
            @P("The customer's reason for the refund") String reason) {
        Order order = store.find(orderId).orElse(null);
        if (order == null) {
            return new RefundResult(false, null, "No order found with id " + orderId);
        }
        if (order.status() == OrderStore.ShippingStatus.CANCELLED) {
            return new RefundResult(false, null, "Order " + order.orderId() + " is already cancelled");
        }
        if (store.hasOpenRefund(order.orderId())) {
            return new RefundResult(false, null, "A refund request is already open for " + order.orderId());
        }
        RefundRequest refund = store.openRefund(order.orderId(), reason);
        return new RefundResult(true, refund.refundId(), "Refund request opened for " + order.orderId());
    }
}
