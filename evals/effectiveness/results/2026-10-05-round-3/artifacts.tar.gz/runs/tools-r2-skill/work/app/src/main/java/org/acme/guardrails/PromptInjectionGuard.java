package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guardrail for entry methods that receive customer text. The prompt wraps that text in
 * a single {@code <message>…</message>} pair; any further delimiter markup inside it would end
 * the delimited region early, so it is rejected.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    private static final Pattern OPEN = Pattern.compile("<message>", Pattern.CASE_INSENSITIVE);
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(message|ticket|problem|request|question|text)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 200) { // prompt wrapper adds a little text
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // Drop the template's own outer delimiter pair (first open, last close), then look for more.
        String inner = text;
        var open = OPEN.matcher(inner);
        if (open.find()) {
            inner = inner.substring(open.end());
            int close = inner.toLowerCase().lastIndexOf("</message>");
            if (close >= 0) {
                inner = inner.substring(0, close);
            }
        }
        if (DELIMITER_MARKUP.matcher(inner).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (inner.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
