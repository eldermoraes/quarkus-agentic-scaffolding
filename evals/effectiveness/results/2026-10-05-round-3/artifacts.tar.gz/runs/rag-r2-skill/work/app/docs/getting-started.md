# Getting Started with Acme Widgets

Acme Widgets is a small library for building dashboards.

## Installation

Add the `acme-widgets` dependency to your build file and run `acme init`
to generate the default configuration in `acme.yaml`.

## Configuration

The default port is 9090. Change it with the `server.port` key in `acme.yaml`.
Logs are written to `logs/acme.log` and rotated daily.

## Support

Report problems at support@acme.example. Support hours are 09:00-17:00 UTC on weekdays.
