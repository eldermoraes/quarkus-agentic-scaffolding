# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It offers fast startup time and low memory usage, and supports both imperative
and reactive programming models.

## Dev Mode

Run `mvn quarkus:dev` to start live coding. Changes to source files are
recompiled automatically on the next request, and the Dev UI is available at
`/q/dev-ui`.

## Native Executables

Quarkus can compile an application to a native executable using GraalVM with
`mvn package -Dnative`. Native executables start in milliseconds.
