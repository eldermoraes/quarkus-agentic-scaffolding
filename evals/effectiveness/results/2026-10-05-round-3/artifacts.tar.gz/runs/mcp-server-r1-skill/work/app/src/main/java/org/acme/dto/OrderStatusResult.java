package org.acme.dto;

/** Result of a status lookup; {@code found=false} means the id is unknown (status is then null). */
public record OrderStatusResult(String orderId, boolean found, OrderStatus status) {}
