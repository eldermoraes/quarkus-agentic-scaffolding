package org.acme.dto;

import java.time.Instant;

/** An order as returned by the lookup operations. */
public record Order(String id, String customerId, OrderStatus status, double total, Instant placedAt) {}
