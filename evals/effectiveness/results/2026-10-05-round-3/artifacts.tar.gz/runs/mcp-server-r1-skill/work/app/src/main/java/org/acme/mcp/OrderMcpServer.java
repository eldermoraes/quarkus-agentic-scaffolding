package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.dto.OrderStatusResult;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;

/**
 * Offers the order lookups to remote MCP clients over Streamable HTTP at {@code /mcp}.
 * Delegates to {@link OrderTools} so the REST assistant and MCP clients share one implementation.
 * The endpoint ships open; in production put /mcp and /mcp/* behind the application's access layer.
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(description = "Gets the current status of an order by its id (e.g. ORD-1001)")
    public OrderStatusResult getOrderStatus(
            @ToolArg(description = "The order id") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(description = "Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id (e.g. CUST-1)") String customerId,
            @ToolArg(description = "Maximum number of orders to return (default 5, max 20)", required = false) Integer limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
