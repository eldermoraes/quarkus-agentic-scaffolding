package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Guards entry methods that receive customer text. The prompt wraps that text in
 * {@code <question>...</question>}; the guard inspects only the span between the first opening
 * and the last closing tag (the prompt's own tags), so a closing tag smuggled inside the text
 * is rejected instead of ending the delimited region early.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 2_000;

    private static final String OPEN = "<question>";
    private static final String CLOSE = "</question>";
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(question|ticket|problem|request|text)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int start = text.indexOf(OPEN);
        int end = text.lastIndexOf(CLOSE);
        String span = (start >= 0 && end > start) ? text.substring(start + OPEN.length(), end) : text;

        if (span.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(span).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (span.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
