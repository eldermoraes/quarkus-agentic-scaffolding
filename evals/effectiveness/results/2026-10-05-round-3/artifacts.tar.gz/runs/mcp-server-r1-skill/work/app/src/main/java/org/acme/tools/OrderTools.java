package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.dto.OrderStatusResult;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Order lookups for our own model (langchain4j {@code @Tool}). The MCP server
 * ({@link org.acme.mcp.OrderMcpServer}) delegates here, so one implementation backs both.
 * Lookups are in-memory and non-blocking, so no virtual-thread hop is needed; add
 * {@code @RunOnVirtualThread} if this is ever backed by a database or REST client.
 */
@ApplicationScoped
public class OrderTools {

    static final int DEFAULT_LIMIT = 5;
    static final int MAX_LIMIT = 20;

    @Inject
    OrderRepository repository;

    @Tool("Gets the current status of an order by its id (e.g. ORD-1001)")
    public OrderStatusResult getOrderStatus(@P("The order id") String orderId) {
        Order order = repository.findById(orderId);
        return order == null
                ? new OrderStatusResult(orderId, false, null)
                : new OrderStatusResult(order.id(), true, order.status());
    }

    @Tool("Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(
            @P("The customer id (e.g. CUST-1)") String customerId,
            @P("Maximum number of orders to return (default 5, max 20)") Integer limit) {
        int effective = limit == null ? DEFAULT_LIMIT : Math.max(1, Math.min(limit, MAX_LIMIT));
        return repository.recentForCustomer(customerId, effective);
    }
}
