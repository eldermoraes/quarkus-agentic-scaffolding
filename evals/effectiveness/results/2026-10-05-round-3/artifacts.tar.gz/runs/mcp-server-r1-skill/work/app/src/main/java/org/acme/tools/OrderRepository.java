package org.acme.tools;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store, seeded with a few demo orders. */
@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, 59.90, now.minus(30, ChronoUnit.DAYS)));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, 120.00, now.minus(3, ChronoUnit.DAYS)));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PROCESSING, 15.25, now.minus(1, ChronoUnit.DAYS)));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.PENDING, 310.00, now.minus(2, ChronoUnit.HOURS)));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.CANCELLED, 42.00, now.minus(10, ChronoUnit.DAYS)));
    }

    public void add(Order order) {
        orders.put(order.id(), order);
    }

    public Order findById(String id) {
        return id == null ? null : orders.get(id.strip().toUpperCase());
    }

    /** Most recent first. */
    public List<Order> recentForCustomer(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        String wanted = customerId.strip();
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(wanted))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(limit)
                .toList();
    }
}
