package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.dto.OrderStatus;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

/** Wiring smoke test: boots the app and exercises the tools; never calls the model. */
@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void statusLookup() {
        var found = tools.getOrderStatus("ORD-1002");
        assertTrue(found.found());
        assertEquals(OrderStatus.SHIPPED, found.status());
        assertFalse(tools.getOrderStatus("NOPE").found());
    }

    @Test
    void recentOrdersNewestFirstAndLimited() {
        var orders = tools.listRecentOrders("CUST-1", 2);
        assertEquals(2, orders.size());
        assertEquals("ORD-1003", orders.get(0).id());
        assertTrue(tools.listRecentOrders("UNKNOWN", null).isEmpty());
    }
}
