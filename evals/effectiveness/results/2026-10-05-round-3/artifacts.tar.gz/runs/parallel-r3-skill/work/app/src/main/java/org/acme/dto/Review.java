package org.acme.dto;

import java.util.List;

/** One reviewer's analysis of the brief. */
public record Review(String verdict, List<String> strengths, List<String> concerns) {}
