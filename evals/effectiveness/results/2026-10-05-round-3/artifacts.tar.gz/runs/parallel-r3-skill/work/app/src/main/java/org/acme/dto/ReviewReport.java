package org.acme.dto;

/** Combined report: both reviews side by side. */
public record ReviewReport(Review technical, Review business) {}
