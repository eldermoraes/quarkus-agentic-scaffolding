package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.acme.dto.Review;
import org.acme.dto.ReviewReport;

/** Runs both reviewers concurrently; @Output combines their reviews into one report. */
public interface BriefReviewAgent {

    @ParallelAgent(outputKey = "report", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport assemble(AgenticScope scope) {
        return new ReviewReport(
                (Review) scope.readState("technicalReview"),
                (Review) scope.readState("businessReview"));
    }
}
