package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.dto.ReviewReport;
import org.acme.guardrails.PromptInjectionGuard;
import org.acme.workflow.BriefReviewAgent;

/**
 * REST edge for the parallel brief-review workflow. The workflow blocks for the model round-trips,
 * so the method runs on a virtual thread. Blank or over-long briefs are rejected before any model
 * call; anything that escapes becomes an RFC 9457 problem response (quarkus-http-problem).
 */
@Path("/review")
public class ReviewResource {

    /** Request body. */
    public record ReviewRequest(String brief) {}

    @Inject
    BriefReviewAgent agent;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ReviewReport review(ReviewRequest request) {
        if (request == null || request.brief() == null || request.brief().isBlank()) {
            throw new BadRequestException("brief must not be empty");
        }
        if (request.brief().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("brief exceeds " + PromptInjectionGuard.MAX_INPUT_CHARS + " characters");
        }
        return agent.review(request.brief());
    }
}
