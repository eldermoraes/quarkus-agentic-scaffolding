package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    @Inject
    BriefReviewWorkflow workflow;

    @POST
    @RunOnVirtualThread
    public ReviewReport review(BriefRequest request) {
        if (request == null || request.brief() == null || request.brief().isBlank()) {
            throw new BadRequestException("brief is required");
        }
        if (request.brief().length() > BriefInputGuardrail.MAX_LENGTH) {
            throw new BadRequestException("brief is too long");
        }
        return workflow.review(request.brief());
    }
}
