package org.acme;

/** Request body for POST /review. */
public record BriefRequest(String brief) {
}
