package org.acme;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** In-memory order and refund data. */
@ApplicationScoped
public class OrderRepository {

    public record Order(String id, String status, String carrier, String trackingNumber, LocalDate estimatedDelivery) {}

    public record RefundRequest(String refundId, String orderId, String reason, String status) {}

    private final Map<String, Order> orders = new ConcurrentHashMap<>(Map.of(
            "A1001", new Order("A1001", "SHIPPED", "DHL", "DHL-778812", LocalDate.now().plusDays(2)),
            "A1002", new Order("A1002", "DELIVERED", "UPS", "UPS-445590", LocalDate.now().minusDays(3)),
            "A1003", new Order("A1003", "PROCESSING", "n/a", "n/a", LocalDate.now().plusDays(6))));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(String::trim).map(String::toUpperCase).map(orders::get);
    }

    public RefundRequest openRefund(String orderId, String reason) {
        String id = "R-" + refundSeq.incrementAndGet();
        RefundRequest refund = new RefundRequest(id, orderId, reason, "OPEN");
        refunds.put(id, refund);
        return refund;
    }

    public List<RefundRequest> refunds() {
        return List.copyOf(refunds.values());
    }
}
