package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderRepository repository;

    @Tool("Looks up the shipping status of an order by its order id (for example A1001)")
    public String getShippingStatus(@P("The order id") String orderId) {
        return repository.findOrder(orderId)
                .map(o -> "Order %s: status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s"
                        .formatted(o.id(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an existing order. Only call after the customer confirmed the order id and gave a reason")
    public String openRefundRequest(@P("The order id") String orderId, @P("The customer's reason for the refund") String reason) {
        if (repository.findOrder(orderId).isEmpty()) {
            return "Cannot open refund: no order found with id " + orderId;
        }
        var refund = repository.openRefund(orderId.trim().toUpperCase(), reason);
        return "Refund request %s opened for order %s with status %s".formatted(refund.refundId(), refund.orderId(), refund.status());
    }
}
