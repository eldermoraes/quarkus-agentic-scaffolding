package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    SupportTools tools;

    @Test
    void wiringSmokeTest() {
        assertNotNull(assistant);
    }

    @Test
    void toolsUseInMemoryData() {
        assertTrue(tools.getShippingStatus("A1001").contains("SHIPPED"));
        assertTrue(tools.openRefundRequest("A1002", "damaged").contains("OPEN"));
    }
}
