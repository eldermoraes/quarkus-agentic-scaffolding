package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/classify")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ClassifyResource {

    @Inject
    TicketClassifier classifier;

    @POST
    @RunOnVirtualThread
    public ClassificationResponse classify(TicketRequest request) {
        return new ClassificationResponse(classifier.classify(request.text()));
    }
}
