package org.acme;

public record ClassificationResponse(Category category) {
}
