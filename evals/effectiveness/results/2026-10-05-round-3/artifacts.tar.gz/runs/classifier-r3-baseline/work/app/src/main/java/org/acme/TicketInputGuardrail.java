package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TicketInputGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 8000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return failure("Ticket text must not be empty");
        }
        if (text.length() > MAX_LENGTH) {
            return failure("Ticket text is too long");
        }
        return success();
    }
}
