package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.TicketClassifier;
import org.acme.dto.Category;
import org.acme.guardrails.TicketInjectionGuard;

/** REST edge: POST /classify with the raw ticket text as a plain-text body. */
@Path("/classify")
public class ClassifyResource {

    public record ClassifyResponse(Category category) {}

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ClassifyResponse classify(String ticket) {
        if (ticket == null || ticket.isBlank()) {
            throw new BadRequestException("ticket must not be empty");
        }
        if (ticket.length() > TicketInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("ticket exceeds " + TicketInjectionGuard.MAX_INPUT_CHARS + " characters");
        }
        return new ClassifyResponse(classifier.classify(ticket));
    }
}
