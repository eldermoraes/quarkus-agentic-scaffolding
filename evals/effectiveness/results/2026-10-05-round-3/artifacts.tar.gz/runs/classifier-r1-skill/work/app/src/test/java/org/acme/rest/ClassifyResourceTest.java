package org.acme.rest;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ClassifyResourceTest {

    @Test
    void blankTicketIsRejectedBeforeAnyModelCall() {
        given().contentType("text/plain").body("   ")
                .when().post("/classify")
                .then().statusCode(400);
    }
}
