package org.acme.dto;

/** Closed set of ticket categories the classifier may return. */
public enum Category {
    BILLING,
    TECHNICAL,
    OTHER
}
