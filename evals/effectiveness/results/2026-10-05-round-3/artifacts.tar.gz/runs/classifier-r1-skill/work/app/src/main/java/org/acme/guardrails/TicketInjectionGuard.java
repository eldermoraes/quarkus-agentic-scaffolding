package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guard for externally originated ticket text. The rendered prompt already contains the
 * one ticket-open / ticket-close pair that the AI service adds, so any additional delimiter
 * markup came from the ticket itself and could close the data span early; it is rejected.
 */
@ApplicationScoped
public class TicketInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    private static final Pattern OPEN = Pattern.compile("<ticket>", Pattern.CASE_INSENSITIVE);
    private static final Pattern CLOSE = Pattern.compile("</ticket>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (count(OPEN, text) != 1 || count(CLOSE, text) != 1) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }

    private static long count(Pattern pattern, String text) {
        return pattern.matcher(text).results().count();
    }
}
