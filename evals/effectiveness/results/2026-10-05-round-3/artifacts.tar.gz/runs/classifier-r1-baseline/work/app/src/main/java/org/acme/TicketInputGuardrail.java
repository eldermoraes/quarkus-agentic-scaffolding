package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TicketInputGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 10_000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return fatal("Ticket text must not be empty");
        }
        if (text.length() > MAX_LENGTH) {
            return fatal("Ticket text is too long");
        }
        // The message is "<ticket>...</ticket>"; the body must not forge delimiters.
        String body = text.substring("<ticket>".length(), Math.max("<ticket>".length(), text.length() - "</ticket>".length()));
        if (body.contains("<ticket>") || body.contains("</ticket>")) {
            return fatal("Ticket text must not contain ticket delimiters");
        }
        return success();
    }
}
