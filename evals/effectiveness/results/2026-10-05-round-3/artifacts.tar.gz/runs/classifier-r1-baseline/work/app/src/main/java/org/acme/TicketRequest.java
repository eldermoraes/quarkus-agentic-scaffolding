package org.acme;

public record TicketRequest(String text) {
}
