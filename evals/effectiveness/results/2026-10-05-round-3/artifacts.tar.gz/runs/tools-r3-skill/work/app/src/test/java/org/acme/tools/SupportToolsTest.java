package org.acme.tools;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportToolsTest {

    @Inject
    SupportTools tools;

    @Test
    void knownOrderReturnsStatus() {
        var info = tools.getShippingStatus("1002");
        assertTrue(info.found());
        assertEquals("IN_TRANSIT", info.status());
    }

    @Test
    void unknownOrderIsNotFound() {
        assertFalse(tools.getShippingStatus("9999").found());
        assertFalse(tools.openRefundRequest("9999", "x").opened());
    }

    @Test
    void refundIsOpenedOnceAndIdempotent() {
        var first = tools.openRefundRequest("1001", "Damaged");
        var second = tools.openRefundRequest("1001", "Damaged again");
        assertTrue(first.opened());
        assertEquals(first.refundId(), second.refundId());
    }
}
