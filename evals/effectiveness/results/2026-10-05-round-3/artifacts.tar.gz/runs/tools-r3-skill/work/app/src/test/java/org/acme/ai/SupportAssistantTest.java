package org.acme.ai;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

/** Wiring smoke tests: no model call, so no running Ollama is needed. */
@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void blankMessageIsRejectedBeforeModelCall() {
        given().contentType("application/json")
                .body("{\"conversationId\":\"c1\",\"message\":\"  \"}")
                .when().post("/chat")
                .then().statusCode(400);
    }
}
