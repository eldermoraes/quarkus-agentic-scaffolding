package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.SupportAssistant;
import org.acme.guardrails.PromptInjectionGuard;

/** REST edge: blank or over-long input is rejected before any model call. */
@Path("/chat")
public class ChatResource {

    public record ChatRequest(String conversationId, String message) {}

    public record ChatResponse(String conversationId, String answer) {}

    private static final int MAX_ID_CHARS = 100;

    @Inject
    SupportAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ChatResponse chat(ChatRequest request) {
        if (request == null || request.conversationId() == null || request.conversationId().isBlank()) {
            throw new BadRequestException("conversationId must not be empty");
        }
        if (request.conversationId().length() > MAX_ID_CHARS) {
            throw new BadRequestException("conversationId exceeds " + MAX_ID_CHARS + " characters");
        }
        if (request.message() == null || request.message().isBlank()) {
            throw new BadRequestException("message must not be empty");
        }
        if (request.message().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("message exceeds " + PromptInjectionGuard.MAX_INPUT_CHARS + " characters");
        }
        return new ChatResponse(request.conversationId(),
                assistant.chat(request.conversationId(), request.message()));
    }
}
