package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.acme.service.OrderStore;

/** Function-calling tools the support assistant may invoke. */
@ApplicationScoped
public class SupportTools {

    /** Structured tool result; {@code found=false} tells the model the order id is unknown. */
    public record ShippingInfo(boolean found, String orderId, String item, String status,
                               String carrier, String trackingNumber) {}

    public record RefundResult(boolean opened, String refundId, String orderId, String state, String message) {}

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of a customer's order by its order id")
    @RunOnVirtualThread
    public ShippingInfo getShippingStatus(@P("The order id, e.g. 1001") String orderId) {
        return store.findOrder(orderId)
                .map(o -> new ShippingInfo(true, o.orderId(), o.item(), o.status().name(), o.carrier(), o.trackingNumber()))
                .orElse(new ShippingInfo(false, orderId, null, null, null, null));
    }

    @Tool("Opens a refund request for an order. Call only after the customer has clearly asked for a refund and given the order id and a reason")
    @RunOnVirtualThread
    public RefundResult openRefundRequest(@P("The order id to refund") String orderId,
                                          @P("The customer's reason for the refund") String reason) {
        return store.openRefund(orderId, reason)
                .map(r -> new RefundResult(true, r.refundId(), r.orderId(), r.state(),
                        "Refund request registered; it will be reviewed by the support team."))
                .orElse(new RefundResult(false, null, orderId, null, "No order found with that id."));
    }
}
