package org.acme.service;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** In-memory order and refund data. Replace with a repository for real persistence. */
@ApplicationScoped
public class OrderStore {

    public enum ShippingStatus { PROCESSING, SHIPPED, IN_TRANSIT, DELIVERED, CANCELLED }

    public record Order(String orderId, String item, double amount, ShippingStatus status,
                        String carrier, String trackingNumber) {}

    public record RefundRequest(String refundId, String orderId, String reason, String state,
                                Instant createdAt) {}

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();

    public OrderStore() {
        List.of(
                new Order("1001", "Wireless headphones", 79.90, ShippingStatus.DELIVERED, "UPS", "1Z999AA10123456784"),
                new Order("1002", "Mechanical keyboard", 129.00, ShippingStatus.IN_TRANSIT, "FedEx", "794644790138"),
                new Order("1003", "USB-C hub", 45.50, ShippingStatus.PROCESSING, "", ""),
                new Order("1004", "Laptop stand", 39.99, ShippingStatus.CANCELLED, "", ""))
                .forEach(o -> orders.put(o.orderId(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(String::strip).map(orders::get);
    }

    /** Opens a refund; an order that already has a refund returns that existing request. */
    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        return findOrder(orderId).map(order -> refunds.computeIfAbsent(order.orderId(),
                id -> new RefundRequest("RF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                        id, reason, "OPEN", Instant.now())));
    }
}
