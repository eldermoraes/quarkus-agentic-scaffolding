package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Rejects customer text that could break out of the {@code <customer_message>} delimiters or
 * carries an obvious injection marker. The guard sees the rendered prompt, so it inspects only
 * the span between the outermost delimiters.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 2_000;

    private static final String OPEN = "<customer_message>";
    private static final String CLOSE = "</customer_message>";
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?\\s*customer_message\\s*>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String rendered = userMessage.singleText();
        int start = rendered.indexOf(OPEN);
        int end = rendered.lastIndexOf(CLOSE);
        String text = (start >= 0 && end > start) ? rendered.substring(start + OPEN.length(), end) : rendered;

        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(text).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
