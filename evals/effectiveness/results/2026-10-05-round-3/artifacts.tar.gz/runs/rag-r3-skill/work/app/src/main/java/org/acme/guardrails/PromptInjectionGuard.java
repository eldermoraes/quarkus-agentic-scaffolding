package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guardrail for entry methods that receive externally originated text.
 * Keep MAX_INPUT_CHARS in step with the limit enforced at the REST edge.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    /** A closing tag smuggled into the text would end the delimited region early. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(question)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 64) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // The prompt template itself contributes exactly one <question>...</question> pair.
        String inner = text.replaceFirst("(?is)^\\s*<question>", "").replaceFirst("(?is)</question>\\s*$", "");
        if (DELIMITER_MARKUP.matcher(inner).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
