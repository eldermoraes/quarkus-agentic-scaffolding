# Acme Cloud — Getting Started

## Creating an account

Open the Acme Cloud console and choose **Sign up**. Confirm your email address and
you will land on the dashboard with a free trial project.

## Resetting your password

Go to **Settings > Security** and click **Reset password**. A reset link is emailed to you
and stays valid for 30 minutes.

## Deploying your first application

Run `acme deploy` from the project folder. The CLI builds the application, uploads it, and
prints the public URL. A deployment that returns HTTP 503 usually means the health check
at `/health` is failing; check the application logs with `acme logs --follow`.

## Support

Free-tier support is available through the community forum. Paid plans include email
support with a response time of one business day.
