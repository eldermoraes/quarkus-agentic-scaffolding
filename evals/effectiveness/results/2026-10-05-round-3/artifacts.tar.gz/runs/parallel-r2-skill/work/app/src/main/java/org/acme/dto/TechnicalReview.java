package org.acme.dto;

import java.util.List;

public record TechnicalReview(String verdict, List<String> risks, String summary) {}
