package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.dto.BriefInput;
import org.acme.dto.ReviewReport;
import org.acme.workflow.BriefReviewAgent;

/*
 * REST edge for the parallel brief review. The workflow blocks for the model round-trips, so
 * the method runs on a virtual thread. Blank or over-long input is rejected before any model
 * call; keep the limit in step with PromptInjectionGuard.MAX_INPUT_CHARS. Escaping exceptions
 * become RFC 9457 problem responses via quarkus-http-problem.
 */
@Path("/review")
public class ReviewResource {

    private static final int MAX_BRIEF_CHARS = 8_000;

    @Inject
    BriefReviewAgent workflow;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ReviewReport review(BriefInput input) {
        if (input == null || input.brief() == null || input.brief().isBlank()) {
            throw new BadRequestException("brief must not be empty");
        }
        if (input.brief().length() > MAX_BRIEF_CHARS) {
            throw new BadRequestException("brief exceeds " + MAX_BRIEF_CHARS + " characters");
        }
        return workflow.review(input.brief());
    }
}
