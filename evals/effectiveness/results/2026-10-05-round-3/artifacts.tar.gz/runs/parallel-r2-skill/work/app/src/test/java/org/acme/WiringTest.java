package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.acme.workflow.BriefReviewAgent;
import org.junit.jupiter.api.Test;

/** Smoke test: the container boots and the agents wire, without calling a model. */
@QuarkusTest
class WiringTest {

    @Inject
    TechnicalReviewer technical;

    @Inject
    BusinessReviewer business;

    @Inject
    BriefReviewAgent workflow;

    @Test
    void agentsAreWired() {
        assertNotNull(technical);
        assertNotNull(business);
        assertNotNull(workflow);
    }
}
