package org.acme.dto;

import java.util.List;

public record BusinessReview(String verdict, List<String> opportunities, String summary) {}
