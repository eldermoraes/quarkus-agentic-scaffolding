package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Input guard for entry agents that receive the externally authored brief. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    /** Kept in step with the REST edge limit in ReviewResource. */
    private static final int MAX_INPUT_CHARS = 8_000;

    /** A closing tag smuggled inside the brief would end the delimited region early. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?brief>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        // The prompt template contributes exactly one opening and one closing tag.
        if (DELIMITER_MARKUP.matcher(text).results().count() > 2) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
