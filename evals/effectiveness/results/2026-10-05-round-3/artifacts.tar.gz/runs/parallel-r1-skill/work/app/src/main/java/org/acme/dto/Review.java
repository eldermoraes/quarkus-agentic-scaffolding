package org.acme.dto;

import java.util.List;

/** One reviewer's structured analysis of a product brief. */
public record Review(String summary, List<String> strengths, List<String> risks, int score) {
}
