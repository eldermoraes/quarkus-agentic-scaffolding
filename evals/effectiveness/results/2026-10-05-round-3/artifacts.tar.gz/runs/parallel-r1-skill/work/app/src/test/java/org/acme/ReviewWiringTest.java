package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.acme.ai.BusinessReviewer;
import org.acme.ai.ReviewWorkflow;
import org.acme.ai.TechnicalReviewer;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class ReviewWiringTest {

    @Inject
    TechnicalReviewer technicalReviewer;

    @Inject
    BusinessReviewer businessReviewer;

    @Inject
    ReviewWorkflow workflow;

    @Test
    void servicesAreWired() {
        assertNotNull(technicalReviewer);
        assertNotNull(businessReviewer);
        assertNotNull(workflow);
    }
}
