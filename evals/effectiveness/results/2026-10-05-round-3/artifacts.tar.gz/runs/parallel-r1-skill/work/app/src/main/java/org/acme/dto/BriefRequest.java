package org.acme.dto;

public record BriefRequest(String brief) {
}
