package org.acme.dto;

/** Combined report assembled from the technical and business reviews. */
public record ReviewReport(Review technical, Review business, int overallScore) {
}
