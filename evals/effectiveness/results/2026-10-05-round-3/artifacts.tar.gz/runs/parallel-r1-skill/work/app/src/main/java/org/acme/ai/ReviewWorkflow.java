package org.acme.ai;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.acme.dto.Review;
import org.acme.dto.ReviewReport;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.declarative.ParallelExecutor;
import dev.langchain4j.service.V;

/** Runs the technical and business reviewers in parallel and combines their reviews. */
public interface ReviewWorkflow {

    @ParallelAgent(name = "briefReview", outputKey = "report",
            subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @ParallelExecutor
    static Executor executor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Output
    static ReviewReport assemble(Review technicalReview, Review businessReview) {
        int overall = Math.round((technicalReview.score() + businessReview.score()) / 2f);
        return new ReviewReport(technicalReview, businessReview, overall);
    }
}
