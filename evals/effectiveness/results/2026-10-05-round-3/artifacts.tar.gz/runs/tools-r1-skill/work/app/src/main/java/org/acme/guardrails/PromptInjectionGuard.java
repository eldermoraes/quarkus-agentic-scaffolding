package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    /** A smuggled closing tag would end the delimited region early, so reserved markup is rejected. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(customer_message)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 100) { // slack for the prompt template wrapper
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(stripWrapper(text)).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }

    /** The template's own outer tags are legitimate; only inspect what the customer wrote. */
    private static String stripWrapper(String text) {
        String t = text.strip();
        String open = "<customer_message>";
        String close = "</customer_message>";
        if (t.startsWith(open) && t.endsWith(close)) {
            return t.substring(open.length(), t.length() - close.length());
        }
        return t;
    }
}
