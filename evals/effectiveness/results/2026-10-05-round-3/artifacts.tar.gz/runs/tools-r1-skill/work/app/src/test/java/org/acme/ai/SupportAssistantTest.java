package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        // No model call: booting Quarkus builds the AI-service proxy.
        assertNotNull(assistant);
    }

    @Test
    void shippingStatusTool() {
        assertEquals("IN_TRANSIT", tools.getShippingStatus("a1002").status());
        assertFalse(tools.getShippingStatus("nope").found());
    }

    @Test
    void refundToolIsIdempotentPerOrder() {
        var first = tools.openRefundRequest("A1001", "damaged");
        var second = tools.openRefundRequest("A1001", "damaged again");
        assertTrue(first.opened());
        assertEquals(first.refundId(), second.refundId());
        assertFalse(tools.openRefundRequest("ZZZ", "x").opened());
    }
}
