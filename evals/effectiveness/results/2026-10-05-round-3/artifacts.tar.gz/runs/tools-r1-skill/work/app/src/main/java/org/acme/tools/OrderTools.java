package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.acme.orders.OrderStore;
import org.acme.orders.OrderStore.Order;

@ApplicationScoped
public class OrderTools {

    /** Typed tool result; found=false means the order id is unknown. */
    public record ShippingInfo(boolean found, String orderId, String item, String status,
            String carrier, String trackingNumber, String estimatedDelivery) {}

    public record RefundResult(boolean opened, String refundId, String message) {}

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of an order by its order id (e.g. A1002)")
    @RunOnVirtualThread
    public ShippingInfo getShippingStatus(@P("The order id, e.g. A1002") String orderId) {
        return store.findOrder(orderId)
                .map(o -> new ShippingInfo(true, o.orderId(), o.item(), o.status().name(), o.carrier(),
                        o.trackingNumber(), o.estimatedDelivery().toString()))
                .orElseGet(() -> new ShippingInfo(false, orderId, null, null, null, null, null));
    }

    @Tool("Opens a refund request for an order. Only call after the customer asked for a refund and gave a reason")
    @RunOnVirtualThread
    public RefundResult openRefundRequest(@P("The order id, e.g. A1001") String orderId,
            @P("The customer's reason for the refund") String reason) {
        Order order = store.findOrder(orderId).orElse(null);
        if (order == null) {
            return new RefundResult(false, null, "Order not found");
        }
        if (order.status() == OrderStore.ShippingStatus.CANCELLED) {
            return new RefundResult(false, null, "Order is already cancelled");
        }
        var refund = store.openRefund(order, reason);
        return new RefundResult(true, refund.refundId(), "Refund request " + refund.refundId() + " is " + refund.state());
    }
}
