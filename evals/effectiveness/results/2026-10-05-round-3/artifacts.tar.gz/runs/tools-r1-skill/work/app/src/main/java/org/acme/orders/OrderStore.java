package org.acme.orders;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** In-memory order and refund data. */
@ApplicationScoped
public class OrderStore {

    public enum ShippingStatus { PROCESSING, SHIPPED, IN_TRANSIT, DELIVERED, CANCELLED }

    public record Order(String orderId, String item, ShippingStatus status, String carrier,
            String trackingNumber, LocalDate estimatedDelivery) {}

    public record RefundRequest(String refundId, String orderId, String reason, String state) {}

    private final Map<String, Order> orders = new ConcurrentHashMap<>(Map.of(
            "A1001", new Order("A1001", "Wireless headphones", ShippingStatus.DELIVERED, "UPS", "1Z999AA10123456784", LocalDate.of(2026, 9, 28)),
            "A1002", new Order("A1002", "Mechanical keyboard", ShippingStatus.IN_TRANSIT, "FedEx", "794644790132", LocalDate.of(2026, 10, 8)),
            "A1003", new Order("A1003", "USB-C dock", ShippingStatus.PROCESSING, "n/a", "n/a", LocalDate.of(2026, 10, 12))));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(id -> orders.get(id.trim().toUpperCase()));
    }

    public RefundRequest openRefund(Order order, String reason) {
        // One open refund per order: return the existing request instead of duplicating it.
        return refunds.computeIfAbsent(order.orderId(), id ->
                new RefundRequest("R" + refundSeq.incrementAndGet(), id, reason, "OPEN"));
    }

    public List<RefundRequest> refunds() {
        return List.copyOf(refunds.values());
    }
}
