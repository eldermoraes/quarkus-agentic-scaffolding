package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.service.OrderRepository;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Order operations as LangChain4j tools for the assistant. The MCP server (OrderMcpServer)
 * delegates here too, so one implementation backs both surfaces.
 */
@ApplicationScoped
public class OrderTools {

    private static final int DEFAULT_LIMIT = 5;
    private static final int MAX_LIMIT = 20;

    /** Result of a status lookup; {@code found=false} when the id is unknown. */
    public record OrderStatusResult(boolean found, String orderId, String status) {}

    @Inject
    OrderRepository repository;

    @Tool("Gets the status of an order by its order id")
    @RunOnVirtualThread // a real lookup hits a DB or REST client — keep it off the event loop
    public OrderStatusResult getOrderStatus(@P("The order id, e.g. ORD-1001") String orderId) {
        return repository.findById(orderId)
                .map(o -> new OrderStatusResult(true, o.id(), o.status().name()))
                .orElse(new OrderStatusResult(false, orderId, null));
    }

    @Tool("Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return (default 5, max 20)") Integer limit) {
        int effective = limit == null || limit < 1 ? DEFAULT_LIMIT : Math.min(limit, MAX_LIMIT);
        return repository.findRecentByCustomer(customerId, effective);
    }
}
