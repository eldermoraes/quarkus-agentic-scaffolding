package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects oversized input, smuggled delimiter markup, and obvious injection markers. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    /** A closing tag smuggled inside the text would end the delimited region early. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?(question)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 200) { // template wrapper adds a little text
            return failure("Input exceeds the character limit.");
        }
        // The template's own <question> tags are legitimate: count them, reject any extras.
        if (DELIMITER_MARKUP.matcher(text).results().count() > 2) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
