package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        // No model call: booting Quarkus builds the AI-service proxy.
        assertNotNull(assistant);
    }

    @Test
    void toolsLookUpOrders() {
        assertEquals("SHIPPED", tools.getOrderStatus("ORD-1002").status());
        assertFalse(tools.getOrderStatus("NOPE").found());
        assertEquals("ORD-1003", tools.listRecentOrders("CUST-1", 2).getFirst().id());
    }
}
