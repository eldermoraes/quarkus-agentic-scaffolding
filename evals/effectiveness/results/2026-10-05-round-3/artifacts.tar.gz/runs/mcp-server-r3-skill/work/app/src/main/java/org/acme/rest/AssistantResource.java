package org.acme.rest;

import org.acme.ai.OrderAssistant;
import org.acme.guardrails.PromptInjectionGuard;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/** REST edge for the OrderAssistant. Blank or over-long input is rejected before any model call. */
@Path("/assistant")
public class AssistantResource {

    public record AssistantRequest(String question) {}

    public record AssistantResponse(String answer) {}

    @Inject
    OrderAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread // blocks for the model and every tool round-trip
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be empty");
        }
        if (request.question().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("question exceeds " + PromptInjectionGuard.MAX_INPUT_CHARS + " characters");
        }
        return new AssistantResponse(assistant.answer(request.question()));
    }
}
