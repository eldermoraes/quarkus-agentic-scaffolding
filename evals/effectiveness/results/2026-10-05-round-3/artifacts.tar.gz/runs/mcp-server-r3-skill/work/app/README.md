# order-tools

Quarkus + LangChain4j (Ollama) app with order-lookup operations backed by an in-memory map
(demo data: `CUST-1`, `CUST-2`; orders `ORD-1001`…`ORD-2002`).

- **MCP server** (Streamable HTTP, `/mcp`): tools `get_order_status` and `list_recent_orders`.
- **REST** `POST /assistant` with `{"question": "..."}`: an LLM assistant (model `qwen3:4b` via Ollama,
  `ollama pull qwen3:4b`) answers using the same operations (`OrderTools`) as tools.
- Swagger UI / OpenAPI at `/q/swagger-ui` in dev mode.

```
curl -X POST localhost:8080/assistant -H 'Content-Type: application/json' \
  -d '{"question":"What is the status of order ORD-1002?"}'
```

Run: `./mvnw quarkus:dev`. Tests (`./mvnw test`) need no running model.

Note: the endpoints ship unauthenticated. Before exposing them, add `quarkus-oidc` and protect
`/mcp`, `/mcp/*` and `/assistant`; the order tools take any customer id as input.
