package org.acme.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.Order.OrderStatus;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store, seeded with demo data. Swap for a Panache repository in a real app. */
@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, now.minus(30, ChronoUnit.DAYS), new BigDecimal("59.90")));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, now.minus(3, ChronoUnit.DAYS), new BigDecimal("120.00")));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PROCESSING, now.minus(1, ChronoUnit.DAYS), new BigDecimal("15.25")));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.CANCELLED, now.minus(10, ChronoUnit.DAYS), new BigDecimal("300.00")));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.SHIPPED, now.minus(2, ChronoUnit.DAYS), new BigDecimal("42.00")));
    }

    public void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(orders.get(id));
    }

    /** Most recent orders first, at most {@code limit}. */
    public List<Order> findRecentByCustomer(String customerId, int limit) {
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(limit)
                .toList();
    }
}
