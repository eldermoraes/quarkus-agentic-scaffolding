package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;

/*
 * MCP server — offers the order operations to remote MCP clients over Streamable HTTP at /mcp.
 * In production, put /mcp behind the application's access layer (HTTP auth policies or a gateway).
 * io.quarkiverse.mcp.server.Tool offers a method to remote MCP clients; the LangChain4j @Tool
 * in OrderTools offers it to our own model. Both delegate to the same OrderTools bean.
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(name = "get_order_status", description = "Gets the status of an order by its order id")
    @RunOnVirtualThread
    public OrderTools.OrderStatusResult getOrderStatus(
            @ToolArg(description = "The order id, e.g. ORD-1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(name = "list_recent_orders", description = "Lists a customer's most recent orders, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return (default 5, max 20)", required = false) Integer limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
