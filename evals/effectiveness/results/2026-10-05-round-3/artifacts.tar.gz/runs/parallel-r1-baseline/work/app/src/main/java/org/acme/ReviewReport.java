package org.acme;

/** Combined result of the parallel technical and business reviews. */
public record ReviewReport(String technicalReview, String businessReview) {
}
