package org.acme;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.declarative.ParallelExecutor;
import dev.langchain4j.service.V;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/** Runs both reviewers in parallel and merges their outputs into one report. */
public interface BriefReviewWorkflow {

    @ParallelAgent(outputKey = "report", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @ParallelExecutor
    static Executor executor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Output
    static ReviewReport combine(@V("technicalReview") String technicalReview,
            @V("businessReview") String businessReview) {
        return new ReviewReport(technicalReview, businessReview);
    }
}
