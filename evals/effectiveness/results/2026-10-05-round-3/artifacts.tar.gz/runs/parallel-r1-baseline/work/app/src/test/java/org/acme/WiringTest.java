package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class WiringTest {

    @Inject
    BriefReviewWorkflow workflow;

    @Inject
    TechnicalReviewer technicalReviewer;

    @Test
    void servicesAreWired() {
        assertNotNull(workflow);
        assertNotNull(technicalReviewer);
    }
}
