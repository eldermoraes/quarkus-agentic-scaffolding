package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty or oversized briefs before they reach the model. */
@ApplicationScoped
public class BriefGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 20_000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return failure("The product brief is empty");
        }
        if (text.length() > MAX_LENGTH) {
            return failure("The product brief exceeds " + MAX_LENGTH + " characters");
        }
        return success();
    }
}
