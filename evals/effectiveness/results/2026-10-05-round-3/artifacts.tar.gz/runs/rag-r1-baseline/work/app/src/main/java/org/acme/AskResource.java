package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/ask")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AskResource {

    public record AskRequest(@NotBlank String question) {
    }

    public record AskResponse(String answer) {
    }

    @Inject
    DocsAssistant assistant;

    @POST
    @RunOnVirtualThread
    public AskResponse ask(@Valid AskRequest request) {
        return new AskResponse(assistant.answer(request.question()));
    }
}
