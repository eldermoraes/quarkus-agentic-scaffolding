# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It offers fast startup times and low memory consumption, which makes it a good
fit for microservices, serverless functions and cloud deployments.

## Dev Mode

Running `mvn quarkus:dev` starts live coding: code changes are recompiled and
reloaded automatically without restarting the application. The Dev UI is
available at `/q/dev-ui`.

## Native Builds

Quarkus applications can be compiled to a native executable with GraalVM using
`mvn package -Dnative`. Native binaries start in milliseconds.

## LangChain4j

The Quarkus LangChain4j extensions integrate large language models through
declarative AI services annotated with `@RegisterAiService`.
