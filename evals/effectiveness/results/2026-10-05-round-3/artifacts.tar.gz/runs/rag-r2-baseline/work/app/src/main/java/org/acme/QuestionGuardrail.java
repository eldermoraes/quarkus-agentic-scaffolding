package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty or oversized questions before they reach the model. */
@ApplicationScoped
public class QuestionGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 2000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return fatal("The question must not be empty");
        }
        if (text.length() > MAX_LENGTH) {
            return fatal("The question is too long");
        }
        return success();
    }
}
