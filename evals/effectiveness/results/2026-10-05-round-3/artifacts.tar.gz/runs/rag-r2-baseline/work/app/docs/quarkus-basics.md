# Quarkus Basics

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It offers fast startup times and low memory consumption.

## Dev Mode

Run `mvn quarkus:dev` to start live coding. Changes to source files are
picked up automatically on the next request, without restarting the JVM.

## Extensions

Extensions add capabilities such as REST endpoints, persistence, and
messaging. Add one with `mvn quarkus:add-extension -Dextensions=rest-jackson`.

## Configuration

Settings live in `src/main/resources/application.properties`. Profiles such as
`%dev` and `%test` override values per environment.
