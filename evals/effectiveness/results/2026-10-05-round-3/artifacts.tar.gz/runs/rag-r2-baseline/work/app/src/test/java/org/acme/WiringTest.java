package org.acme;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class WiringTest {

    @Inject
    DocsAssistant assistant;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void blankQuestionIsRejected() {
        given().contentType("application/json").body("{\"question\":\" \"}")
                .when().post("/ask")
                .then().statusCode(400);
    }
}
