package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderService orders;

    @Test
    void wired() {
        assertNotNull(assistant);
    }

    @Test
    void inMemoryData() {
        assertNotNull(orders.findOrder("1001").orElseThrow());
        assertNotNull(orders.openRefund("1001", "damaged").orElseThrow());
    }
}
