package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderService orders;

    @Tool("Look up the shipping status of an order by its order id")
    @RunOnVirtualThread
    public String getShippingStatus(@P("The order id, e.g. 1001") String orderId) {
        return orders.findOrder(orderId)
                .map(o -> "Order %s: status=%s, carrier=%s, estimatedDelivery=%s"
                        .formatted(o.id(), o.status(), o.carrier(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Open a refund request for an order. Only call after the customer clearly asks for a refund")
    @RunOnVirtualThread
    public String openRefundRequest(@P("The order id") String orderId,
            @P("The customer's reason for the refund") String reason) {
        return orders.openRefund(orderId, reason)
                .map(r -> "Refund request %s opened for order %s (status %s)"
                        .formatted(r.refundId(), r.orderId(), r.status()))
                .orElse("Cannot open refund: no order found with id " + orderId);
    }
}
