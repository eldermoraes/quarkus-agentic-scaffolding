package org.acme;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order and refund data. */
@ApplicationScoped
public class OrderService {

    public record Order(String id, String status, String carrier, LocalDate estimatedDelivery, double total) {
    }

    public record RefundRequest(String refundId, String orderId, String reason, String status) {
    }

    private final Map<String, Order> orders = new ConcurrentHashMap<>(Map.of(
            "1001", new Order("1001", "SHIPPED", "DHL", LocalDate.now().plusDays(2), 59.90),
            "1002", new Order("1002", "DELIVERED", "UPS", LocalDate.now().minusDays(3), 120.00),
            "1003", new Order("1003", "PROCESSING", "N/A", LocalDate.now().plusDays(7), 15.50)));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orders.get(orderId));
    }

    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        if (!orders.containsKey(orderId)) {
            return Optional.empty();
        }
        var refund = new RefundRequest(UUID.randomUUID().toString(), orderId, reason, "OPEN");
        refunds.put(refund.refundId(), refund);
        return Optional.of(refund);
    }
}
