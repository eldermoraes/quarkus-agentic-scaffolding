package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class OrderToolsTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderService orders;

    @Test
    void wiring() {
        assertNotNull(assistant);
    }

    @Test
    void lookups() {
        assertEquals("SHIPPED", orders.getOrder("A-1002").orElseThrow().status());
        assertEquals("A-1003", orders.listRecentOrders("C-1", 2).get(0).id());
        assertEquals(2, orders.listRecentOrders("C-1", 2).size());
    }
}
