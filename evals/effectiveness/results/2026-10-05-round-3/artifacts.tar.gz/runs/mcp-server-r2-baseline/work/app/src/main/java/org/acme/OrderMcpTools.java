package org.acme;

import java.util.List;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.quarkiverse.mcp.server.ToolCallException;
import jakarta.inject.Inject;

/** Exposes the order operations to remote MCP clients (streamable HTTP at /mcp). */
public class OrderMcpTools {

    @Inject
    OrderService orders;

    @Tool(description = "Get the status and details of an order by its id")
    Order getOrderStatus(@ToolArg(description = "Order id, e.g. A-1001") String orderId) {
        return orders.getOrder(orderId)
                .orElseThrow(() -> new ToolCallException("Order not found: " + orderId));
    }

    @Tool(description = "List the most recent orders of a customer, newest first")
    List<Order> listRecentOrders(
            @ToolArg(description = "Customer id, e.g. C-1") String customerId,
            @ToolArg(description = "Maximum number of orders (1-50)", defaultValue = "5") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
