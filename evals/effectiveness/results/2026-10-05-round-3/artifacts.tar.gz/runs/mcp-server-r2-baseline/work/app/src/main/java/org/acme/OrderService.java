package org.acme;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService() {
        Instant now = Instant.now();
        add(new Order("A-1001", "C-1", "DELIVERED", 59.90, now.minus(20, ChronoUnit.DAYS)));
        add(new Order("A-1002", "C-1", "SHIPPED", 120.00, now.minus(3, ChronoUnit.DAYS)));
        add(new Order("A-1003", "C-1", "PROCESSING", 15.50, now.minus(1, ChronoUnit.DAYS)));
        add(new Order("A-2001", "C-2", "CANCELLED", 80.00, now.minus(10, ChronoUnit.DAYS)));
        add(new Order("A-2002", "C-2", "SHIPPED", 42.25, now.minus(2, ChronoUnit.DAYS)));
    }

    private void add(Order o) {
        orders.put(o.id(), o);
    }

    public Optional<Order> getOrder(String id) {
        return Optional.ofNullable(orders.get(id));
    }

    public List<Order> listRecentOrders(String customerId, int limit) {
        int max = Math.max(1, Math.min(limit, 50));
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(max)
                .toList();
    }
}
