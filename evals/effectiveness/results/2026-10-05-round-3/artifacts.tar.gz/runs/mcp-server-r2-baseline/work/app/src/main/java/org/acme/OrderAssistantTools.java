package org.acme;

import java.util.List;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** The same order operations, exposed as tools to the LLM assistant. */
@ApplicationScoped
public class OrderAssistantTools {

    @Inject
    OrderService orders;

    @Tool("Get the status and details of an order by its id")
    @RunOnVirtualThread
    public String getOrderStatus(@P("Order id, e.g. A-1001") String orderId) {
        return orders.getOrder(orderId).map(Order::toString).orElse("Order not found: " + orderId);
    }

    @Tool("List the most recent orders of a customer, newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(@P("Customer id, e.g. C-1") String customerId,
            @P("Maximum number of orders (1-50)") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
