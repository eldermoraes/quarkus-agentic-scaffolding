package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    SupportTools tools;

    @Test
    void wired() {
        assertNotNull(assistant);
    }

    @Test
    void toolsWork() {
        assertTrue(tools.getShippingStatus("a1002").contains("IN_TRANSIT"));
        assertTrue(tools.openRefundRequest("A1001", "damaged").contains("OPEN"));
        assertTrue(tools.openRefundRequest("ZZZ", "x").contains("not opened"));
    }
}
