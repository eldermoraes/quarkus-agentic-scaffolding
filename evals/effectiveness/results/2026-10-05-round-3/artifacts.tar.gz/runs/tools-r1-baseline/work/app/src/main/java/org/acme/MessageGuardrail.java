package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty or oversized customer input before it reaches the model. */
@ApplicationScoped
public class MessageGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 2000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank() || text.length() > MAX_LENGTH + 100) {
            return failure("Message must be between 1 and " + MAX_LENGTH + " characters");
        }
        return success();
    }
}
