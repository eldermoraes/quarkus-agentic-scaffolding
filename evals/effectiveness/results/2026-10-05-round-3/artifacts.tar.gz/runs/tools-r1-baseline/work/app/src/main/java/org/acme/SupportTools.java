package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of an order by its order id (e.g. A1001)")
    public String getShippingStatus(@P("The order id") String orderId) {
        return store.findOrder(orderId)
                .map(Object::toString)
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an existing order. Only call after the customer confirmed the order id and the reason")
    public String openRefundRequest(@P("The order id") String orderId, @P("Why the customer wants a refund") String reason) {
        if (store.findOrder(orderId).isEmpty()) {
            return "No order found with id " + orderId + "; refund not opened";
        }
        return store.openRefund(orderId, reason).toString();
    }
}
