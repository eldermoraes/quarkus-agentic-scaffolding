package org.acme;

import jakarta.enterprise.context.ApplicationScoped;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderStore {

    public record ShippingStatus(String orderId, String status, String carrier, String trackingNumber, String estimatedDelivery) {
    }

    public record RefundRequest(String refundId, String orderId, String reason, String status) {
    }

    private final Map<String, ShippingStatus> orders = new ConcurrentHashMap<>(Map.of(
            "A1001", new ShippingStatus("A1001", "DELIVERED", "DHL", "DHL123456", "2026-09-28"),
            "A1002", new ShippingStatus("A1002", "IN_TRANSIT", "UPS", "UPS987654", "2026-10-08"),
            "A1003", new ShippingStatus("A1003", "PROCESSING", "n/a", "n/a", "2026-10-12")));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicLong refundSeq = new AtomicLong(1000);

    public Optional<ShippingStatus> findOrder(String orderId) {
        return Optional.ofNullable(orders.get(orderId.trim().toUpperCase()));
    }

    public RefundRequest openRefund(String orderId, String reason) {
        String id = "R" + refundSeq.incrementAndGet();
        RefundRequest refund = new RefundRequest(id, orderId.trim().toUpperCase(), reason, "OPEN");
        refunds.put(id, refund);
        return refund;
    }
}
