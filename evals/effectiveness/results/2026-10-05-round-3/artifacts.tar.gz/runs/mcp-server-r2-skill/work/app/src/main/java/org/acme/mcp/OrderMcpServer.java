package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;

/*
 * MCP server: offers the order lookups to remote MCP clients over Streamable HTTP at /mcp.
 * Delegates to OrderTools so one implementation backs both MCP clients and the /assistant model.
 * This endpoint ships open for local dev; in production put /mcp behind the application's
 * access layer (HTTP auth policies or a gateway) — it exposes customer order data.
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    // Explicit MCP names: the shared feature-method namespace rejects a second tool called
    // getOrderStatus (the LangChain4j @Tool on OrderTools already uses that name).
    @Tool(name = "order_status", description = "Gets the status of an order by its id (for example ORD-1001). Returns null when the order does not exist")
    @RunOnVirtualThread
    public Order getOrderStatus(@ToolArg(description = "The order id, for example ORD-1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(name = "recent_orders", description = "Lists a customer's most recent orders (at most 5), newest first")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(@ToolArg(description = "The customer id, for example CUST-1") String customerId) {
        return orders.listRecentOrders(customerId);
    }
}
