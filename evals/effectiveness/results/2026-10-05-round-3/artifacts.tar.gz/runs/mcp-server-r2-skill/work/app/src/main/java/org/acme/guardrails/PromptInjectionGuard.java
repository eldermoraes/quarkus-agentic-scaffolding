package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/*
 * Input guard for externally originated text. The guard sees the rendered user message, which
 * already contains the prompt template's own <question> delimiters, so it inspects only the
 * span between the first opening and the last closing delimiter: markup smuggled inside that
 * span would close the region early and let the rest read as instructions.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 2_000;

    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?question>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int start = text.indexOf("<question>");
        int end = text.lastIndexOf("</question>");
        String question = start >= 0 && end > start ? text.substring(start + "<question>".length(), end) : text;

        if (question.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(question).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        // Honest heuristic — real projects tune this (allow-lists, a classifier model, ...).
        if (question.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
