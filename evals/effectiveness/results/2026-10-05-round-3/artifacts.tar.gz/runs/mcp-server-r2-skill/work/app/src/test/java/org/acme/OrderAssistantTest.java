package org.acme;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.acme.ai.OrderAssistant;
import org.acme.dto.Order.OrderStatus;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

/** Wiring and deterministic tests; none of them calls the model. */
@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void statusLookup() {
        assertEquals(OrderStatus.SHIPPED, tools.getOrderStatus("ord-1002").status());
        assertNull(tools.getOrderStatus("ORD-9999"));
    }

    @Test
    void recentOrdersAreNewestFirst() {
        var orders = tools.listRecentOrders("CUST-1");
        assertEquals(3, orders.size());
        assertEquals("ORD-1003", orders.get(0).id());
        assertEquals(0, tools.listRecentOrders("nobody").size());
    }

    @Test
    void blankQuestionIsRejectedBeforeTheModel() {
        given().contentType("application/json").body("{\"question\":\"  \"}")
                .when().post("/assistant")
                .then().statusCode(400);
    }
}
