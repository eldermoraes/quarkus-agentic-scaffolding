package org.acme.tools;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.Order.OrderStatus;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;

/*
 * Order lookups backed by an in-memory map. This one bean backs both consumers: the
 * LangChain4j @Tool methods below are offered to our own model (OrderAssistant), and
 * org.acme.mcp.OrderMcpServer delegates to the same methods for remote MCP clients.
 */
@ApplicationScoped
public class OrderTools {

    static final int MAX_RECENT = 5;

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderTools() {
        Instant now = Instant.now();
        seed("ORD-1001", "CUST-1", OrderStatus.DELIVERED, now.minus(30, ChronoUnit.DAYS), "59.90");
        seed("ORD-1002", "CUST-1", OrderStatus.SHIPPED, now.minus(3, ChronoUnit.DAYS), "120.00");
        seed("ORD-1003", "CUST-1", OrderStatus.PENDING, now.minus(1, ChronoUnit.HOURS), "15.50");
        seed("ORD-2001", "CUST-2", OrderStatus.PAID, now.minus(2, ChronoUnit.DAYS), "249.99");
        seed("ORD-2002", "CUST-2", OrderStatus.CANCELLED, now.minus(10, ChronoUnit.DAYS), "35.00");
    }

    private void seed(String id, String customerId, OrderStatus status, Instant placedAt, String total) {
        orders.put(id, new Order(id, customerId, status, placedAt, new BigDecimal(total)));
    }

    @Tool("Gets the status of an order by its id (for example ORD-1001). Returns null when the order does not exist")
    @RunOnVirtualThread // a real lookup hits a DB or REST client: keep blocking I/O off the event loop
    public Order getOrderStatus(@P("The order id, for example ORD-1001") String orderId) {
        return orderId == null ? null : orders.get(orderId.trim().toUpperCase());
    }

    @Tool("Lists a customer's most recent orders (at most 5), newest first. Returns an empty list for an unknown customer")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(@P("The customer id, for example CUST-1") String customerId) {
        if (customerId == null) {
            return List.of();
        }
        String id = customerId.trim().toUpperCase();
        return orders.values().stream()
                .filter(o -> o.customerId().equals(id))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(MAX_RECENT)
                .toList();
    }
}
