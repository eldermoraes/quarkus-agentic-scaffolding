# order-tools

Quarkus + LangChain4j app (Ollama) with in-memory order lookups exposed two ways:

- **MCP server** (Streamable HTTP at `/mcp`): tools `order_status(orderId)` and `recent_orders(customerId)`.
- **`POST /assistant`** `{"question": "Where is order ORD-1002?"}` → `{"answer": "..."}`: an LLM assistant
  (`OrderAssistant`, model `main`) that calls the same lookups (`OrderTools`) as tools.

Seed data: customers `CUST-1` (ORD-1001..1003) and `CUST-2` (ORD-2001..2002).

## Run

Needs a local Ollama with `ollama pull qwen3:4b`, then `./mvnw quarkus:dev`.
Swagger UI: `/q/swagger-ui`; metrics: `/q/metrics`. Tests (`./mvnw test`) do not call the model.

## Security note

`/assistant` and `/mcp` ship **unauthenticated** and expose any customer's orders by id. Put them
behind authentication/authorization (e.g. `quarkus-oidc` + HTTP auth policies) before exposing them
beyond local development.
