package org.acme;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ReviewWorkflowTest {

    @Inject
    ReviewWorkflow workflow;

    @Inject
    TechnicalReviewer technicalReviewer;

    @Test
    void servicesAreWired() {
        assertNotNull(workflow);
        assertNotNull(technicalReviewer);
    }

    @Test
    void blankBriefIsRejected() {
        given().contentType("application/json").body(new ReviewRequest("  "))
                .when().post("/review")
                .then().statusCode(400);
    }
}
