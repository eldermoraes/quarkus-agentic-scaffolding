package org.acme;

public record ReviewRequest(String brief) {
}
