package org.acme;

import java.time.Instant;

public record Order(String id, String customerId, OrderStatus status, double total, Instant placedAt) {
}
