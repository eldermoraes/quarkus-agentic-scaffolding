package org.acme;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, 59.90, now.minus(30, ChronoUnit.DAYS)));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, 120.00, now.minus(3, ChronoUnit.DAYS)));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PENDING, 15.25, now.minus(1, ChronoUnit.HOURS)));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.PAID, 310.40, now.minus(2, ChronoUnit.DAYS)));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.CANCELLED, 42.00, now.minus(10, ChronoUnit.DAYS)));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String orderId) {
        return Optional.ofNullable(orders.get(orderId));
    }

    public List<Order> recentForCustomer(String customerId, int limit) {
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(1, limit))
                .toList();
    }
}
