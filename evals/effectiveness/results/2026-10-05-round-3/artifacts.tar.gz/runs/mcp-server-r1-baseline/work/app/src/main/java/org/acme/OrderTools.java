package org.acme;

import java.util.List;

import dev.langchain4j.agent.tool.P;
import io.quarkiverse.mcp.server.ToolArg;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * The order operations, exposed both to remote MCP clients (io.quarkiverse.mcp.server.Tool)
 * and to the local assistant (dev.langchain4j.agent.tool.Tool) from one set of methods.
 */
@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @RunOnVirtualThread
    @io.quarkiverse.mcp.server.Tool(name = "get_order_status", description = "Get the status of an order by its id")
    @dev.langchain4j.agent.tool.Tool(name = "get_order_status", value = "Get the status of an order by its id")
    public String getOrderStatus(
            @ToolArg(description = "The order id, e.g. ORD-1001") @P("The order id, e.g. ORD-1001") String orderId) {
        return orders.findById(orderId)
                .map(o -> "Order %s is %s (total %.2f, placed %s)".formatted(o.id(), o.status(), o.total(), o.placedAt()))
                .orElse("No order found with id " + orderId);
    }

    @RunOnVirtualThread
    @io.quarkiverse.mcp.server.Tool(name = "list_recent_orders", description = "List the most recent orders of a customer, newest first")
    @dev.langchain4j.agent.tool.Tool(name = "list_recent_orders", value = "List the most recent orders of a customer, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") @P("The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return", defaultValue = "5") @P("Maximum number of orders to return") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
