package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderService orders;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void ordersAreLookedUp() {
        assertEquals(OrderStatus.SHIPPED, orders.findById("ORD-1002").orElseThrow().status());
        assertEquals("ORD-1003", orders.recentForCustomer("CUST-1", 5).getFirst().id());
    }
}
