package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Rejects oversized input, smuggled delimiter markup, and obvious prompt-injection markers. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    // The rendered prompt adds a little framing around the ticket text.
    private static final int FRAMING_CHARS = 200;

    // A closing tag inside the text would end the delimited region early. The rendered prompt
    // carries exactly one legitimate <ticket>...</ticket> pair; any other markup is smuggled.
    private static final Pattern TICKET_TAG = Pattern.compile("</?ticket>", Pattern.CASE_INSENSITIVE);
    private static final Pattern OTHER_DELIMITERS =
            Pattern.compile("</?(problem|request|question|text)>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + FRAMING_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (TICKET_TAG.matcher(text).results().count() > 2 || OTHER_DELIMITERS.matcher(text).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
