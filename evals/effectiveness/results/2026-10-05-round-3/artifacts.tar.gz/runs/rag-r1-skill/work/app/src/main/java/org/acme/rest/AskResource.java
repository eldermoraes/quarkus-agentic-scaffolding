package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.DocsAssistant;

@Path("/ask")
public class AskResource {

    public record AskRequest(String question) {}

    public record AskResponse(String answer) {}

    private static final int MAX_QUESTION_CHARS = 4_000;

    @Inject
    DocsAssistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public AskResponse ask(AskRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be empty");
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            throw new BadRequestException("question exceeds " + MAX_QUESTION_CHARS + " characters");
        }
        return new AskResponse(assistant.ask(request.question()));
    }
}
