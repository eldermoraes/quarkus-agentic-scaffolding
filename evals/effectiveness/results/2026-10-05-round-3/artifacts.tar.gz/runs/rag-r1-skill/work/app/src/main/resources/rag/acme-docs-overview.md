# Acme Docs Platform Overview

## What is Acme Docs?
Acme Docs is an internal documentation portal. Teams publish Markdown files, and the portal
makes them searchable and available to the question-answering service.

## Publishing a document
Put a Markdown file into the `rag` folder and restart the service. Documents are split into
segments and embedded in memory when the application starts.

## Support
For help, contact the platform team through the `#docs-platform` channel. Support hours are
Monday to Friday, 09:00 to 17:00 UTC.
