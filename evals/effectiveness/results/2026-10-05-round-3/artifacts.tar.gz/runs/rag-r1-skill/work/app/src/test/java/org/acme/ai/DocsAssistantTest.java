package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class DocsAssistantTest {

    @Inject
    DocsAssistant assistant;

    @Test
    void aiServiceIsWired() {
        // Wiring only: no model call happens, so no running Ollama is needed.
        assertNotNull(assistant);
    }
}
