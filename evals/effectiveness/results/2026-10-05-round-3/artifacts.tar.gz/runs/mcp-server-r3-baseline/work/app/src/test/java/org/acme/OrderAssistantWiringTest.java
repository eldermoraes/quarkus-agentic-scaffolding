package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderAssistantWiringTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderRepository repository;

    @Test
    void wired() {
        assertNotNull(assistant);
        assertEquals(OrderStatus.SHIPPED, repository.findById("ord-1002").orElseThrow().status());
        assertEquals("ORD-1003", repository.findRecentByCustomer("CUST-1", 5).getFirst().id());
    }
}
