package org.acme;

import java.util.List;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** The same order operations, exposed as LangChain4j tools to the assistant. */
@ApplicationScoped
public class OrderAiTools {

    @Inject
    OrderRepository repository;

    @Tool("Get the status of an order by its id, e.g. ORD-1001. Returns null when the order does not exist.")
    public Order getOrderStatus(@P("The order id") String orderId) {
        return repository.findById(orderId).orElse(null);
    }

    @Tool("List a customer's most recent orders, newest first.")
    public List<Order> listRecentOrders(@P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return") int limit) {
        return repository.findRecentByCustomer(customerId, limit);
    }
}
