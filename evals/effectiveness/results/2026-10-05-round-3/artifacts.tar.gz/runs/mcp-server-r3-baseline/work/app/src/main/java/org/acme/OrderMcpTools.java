package org.acme;

import java.util.List;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.quarkiverse.mcp.server.ToolCallException;
import jakarta.inject.Inject;

/** Order operations exposed to remote MCP clients (streamable HTTP at /mcp). */
public class OrderMcpTools {

    @Inject
    OrderRepository repository;

    @Tool(name = "get_order_status", description = "Get the status of an order by its id, e.g. ORD-1001.")
    public Order getOrderStatus(@ToolArg(description = "The order id") String orderId) {
        return repository.findById(orderId)
                .orElseThrow(() -> new ToolCallException("No order found with id " + orderId));
    }

    @Tool(name = "list_recent_orders", description = "List a customer's most recent orders, newest first.")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return", required = false, defaultValue = "5") int limit) {
        return repository.findRecentByCustomer(customerId, limit);
    }
}
