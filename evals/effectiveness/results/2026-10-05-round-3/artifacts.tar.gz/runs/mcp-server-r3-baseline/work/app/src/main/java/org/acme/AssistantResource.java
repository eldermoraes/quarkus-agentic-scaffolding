package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    public record Question(@NotBlank @Size(max = 1000) String question) {
    }

    public record Answer(String answer) {
    }

    @Inject
    OrderAssistant assistant;

    @POST
    @RunOnVirtualThread
    public Answer ask(@Valid Question request) {
        return new Answer(assistant.answer(request.question()));
    }
}
