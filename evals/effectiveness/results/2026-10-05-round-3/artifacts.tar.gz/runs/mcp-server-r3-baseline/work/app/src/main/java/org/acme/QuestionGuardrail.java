package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class QuestionGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 1000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        // the template adds the <question></question> wrapper on top of the raw text
        if (text == null || text.isBlank() || text.length() > MAX_LENGTH + 100) {
            return failure("Question must be non-empty and at most " + MAX_LENGTH + " characters");
        }
        return success();
    }
}
