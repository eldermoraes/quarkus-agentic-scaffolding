package org.acme;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store shared by the MCP tools, the AI tools and any other caller. */
@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderRepository() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, now.minus(30, ChronoUnit.DAYS), 59.90));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, now.minus(3, ChronoUnit.DAYS), 120.00));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PENDING, now.minus(1, ChronoUnit.HOURS), 15.25));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.PAID, now.minus(2, ChronoUnit.DAYS), 300.00));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.CANCELLED, now.minus(10, ChronoUnit.DAYS), 42.00));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return id == null ? Optional.empty() : Optional.ofNullable(orders.get(id.trim().toUpperCase()));
    }

    public List<Order> findRecentByCustomer(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(customerId.trim()))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(1, Math.min(limit, 50)))
                .toList();
    }
}
