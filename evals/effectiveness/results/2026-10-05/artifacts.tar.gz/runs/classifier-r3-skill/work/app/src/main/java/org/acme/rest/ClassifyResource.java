package org.acme.rest;

import org.acme.ai.TicketClassifier;
import org.acme.dto.ClassifyResponse;
import org.jboss.logging.Logger;
import org.jboss.resteasy.reactive.server.ServerExceptionMapper;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/classify")
@Consumes(MediaType.TEXT_PLAIN)
@Produces(MediaType.APPLICATION_JSON)
public class ClassifyResource {

    static final int MAX_TICKET_LENGTH = 5000;

    private static final Logger LOG = Logger.getLogger(ClassifyResource.class);

    @Inject
    TicketClassifier classifier;

    @POST
    public ClassifyResponse classify(String ticket) {
        if (ticket == null || ticket.isBlank()) {
            throw new BadRequestException("Ticket text must not be blank");
        }
        if (ticket.length() > MAX_TICKET_LENGTH) {
            throw new BadRequestException("Ticket text must not exceed " + MAX_TICKET_LENGTH + " characters");
        }
        return new ClassifyResponse(classifier.classify(ticket));
    }

    @ServerExceptionMapper
    public Response guardrailRejected(InputGuardrailException e) {
        LOG.warn("Ticket rejected by input guardrail", e);
        return Response.status(Response.Status.BAD_REQUEST).entity("{\"error\":\"Ticket rejected\"}").build();
    }
}
