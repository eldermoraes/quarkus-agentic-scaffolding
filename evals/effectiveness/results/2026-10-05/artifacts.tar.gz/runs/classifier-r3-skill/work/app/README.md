# ticket-classifier

Quarkus + LangChain4j service that classifies customer support tickets as `BILLING`, `TECHNICAL` or `OTHER` using an Ollama-hosted model.

## Endpoint

`POST /classify` — body is the raw ticket text (`text/plain`, max 5000 chars).

```
curl -X POST localhost:8080/classify -H 'Content-Type: text/plain' -d 'I was charged twice this month'
# {"category":"BILLING"}
```

Blank or over-long text, or text flagged by the prompt-injection guard, returns 400.

## Configuration

Requires a running Ollama (`OLLAMA_URL`, default `http://localhost:11434`) with the model in `OLLAMA_MODEL` (default `llama3.2`). Dev Services are disabled.

## Layout

- `ai/TicketClassifier` — AI service returning the `Category` enum
- `guardrails/PromptInjectionGuard` — input guardrail
- `rest/ClassifyResource` — the REST endpoint

Tests mock the AI service; no model is called. Run `./mvnw test`.
