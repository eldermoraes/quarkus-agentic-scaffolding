package org.acme.dto;

public record ClassifyResponse(Category category) {
}
