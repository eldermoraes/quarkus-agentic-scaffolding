package org.acme.rest;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

import org.acme.ai.TicketClassifier;
import org.acme.dto.Category;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
class ClassifyResourceTest {

    @InjectMock
    TicketClassifier classifier;

    @Test
    void classifiesTicket() {
        Mockito.when(classifier.classify("I was charged twice")).thenReturn(Category.BILLING);
        given().contentType("text/plain").body("I was charged twice")
                .when().post("/classify")
                .then().statusCode(200).body("category", is("BILLING"));
    }

    @Test
    void rejectsBlankTicket() {
        given().contentType("text/plain").body("  ")
                .when().post("/classify")
                .then().statusCode(400);
    }
}
