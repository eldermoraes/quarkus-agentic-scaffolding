package org.acme.guardrails;

import java.util.List;
import java.util.Locale;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects ticket text containing obvious attempts to override the classifier's instructions. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final List<String> MARKERS = List.of(
            "ignore previous instructions",
            "ignore all previous instructions",
            "ignore the above",
            "disregard your instructions",
            "reveal your system prompt",
            "you are now");

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText().toLowerCase(Locale.ROOT);
        for (String marker : MARKERS) {
            if (text.contains(marker)) {
                return failure("Ticket text looks like a prompt injection attempt");
            }
        }
        return success();
    }
}
