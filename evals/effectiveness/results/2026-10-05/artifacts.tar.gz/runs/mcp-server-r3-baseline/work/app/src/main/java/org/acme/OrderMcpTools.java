package org.acme;

import java.util.List;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.quarkiverse.mcp.server.ToolCallException;
import jakarta.inject.Inject;

/** Order operations exposed to remote MCP clients. */
public class OrderMcpTools {

    @Inject
    OrderService orders;

    @Tool(description = "Get the status of an order by its id")
    Order getOrderStatus(@ToolArg(description = "The order id, e.g. 1001") String orderId) {
        return orders.findById(orderId)
                .orElseThrow(() -> new ToolCallException("Order not found: " + orderId));
    }

    @Tool(description = "List the most recent orders of a customer, newest first")
    List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. alice") String customerId,
            @ToolArg(description = "Maximum number of orders to return", defaultValue = "5") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
