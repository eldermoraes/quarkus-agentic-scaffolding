package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class OrderServiceTest {

    private final OrderService service = new OrderService();

    @Test
    void findsOrderById() {
        assertEquals("SHIPPED", service.findById("1002").orElseThrow().status());
        assertTrue(service.findById("nope").isEmpty());
    }

    @Test
    void listsRecentOrdersNewestFirst() {
        var orders = service.recentForCustomer("alice", 2);
        assertEquals(2, orders.size());
        assertEquals("1003", orders.get(0).id());
        assertEquals("1002", orders.get(1).id());
    }
}
