package org.acme;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService() {
        Instant now = Instant.now();
        add(new Order("1001", "alice", "DELIVERED", now.minus(30, ChronoUnit.DAYS), 59.90));
        add(new Order("1002", "alice", "SHIPPED", now.minus(3, ChronoUnit.DAYS), 120.00));
        add(new Order("1003", "alice", "PROCESSING", now.minus(1, ChronoUnit.DAYS), 15.50));
        add(new Order("1004", "bob", "CANCELLED", now.minus(10, ChronoUnit.DAYS), 99.99));
        add(new Order("1005", "bob", "DELIVERED", now.minus(5, ChronoUnit.DAYS), 42.00));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(orders.get(id));
    }

    public List<Order> recentForCustomer(String customerId, int limit) {
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(1, limit))
                .toList();
    }
}
