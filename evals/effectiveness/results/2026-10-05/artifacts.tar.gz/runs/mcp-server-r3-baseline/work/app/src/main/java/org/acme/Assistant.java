package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;
import io.quarkiverse.langchain4j.ToolBox;

@RegisterAiService
public interface Assistant {

    @SystemMessage("""
            You are a customer support assistant for an online shop.
            Use the available tools to look up order information. Never invent
            order data; if a tool finds nothing, say so.
            """)
    @ToolBox(OrderAiTools.class)
    String answer(@UserMessage String question);
}
