package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
public class AssistantResource {

    public record Question(String question) {
    }

    public record Answer(String answer) {
    }

    @Inject
    Assistant assistant;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Answer ask(Question q) {
        return new Answer(assistant.answer(q.question()));
    }
}
