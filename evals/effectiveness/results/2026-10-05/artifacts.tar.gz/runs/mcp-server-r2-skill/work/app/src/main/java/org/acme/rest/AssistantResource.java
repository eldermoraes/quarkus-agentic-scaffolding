package org.acme.rest;

import org.acme.ai.OrderAssistant;
import org.acme.dto.AssistantRequest;
import org.acme.dto.AssistantResponse;
import org.jboss.logging.Logger;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response.Status;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    private static final Logger LOG = Logger.getLogger(AssistantResource.class);
    static final int MAX_QUESTION_CHARS = 2_000;

    @Inject
    OrderAssistant assistant;

    @POST
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new WebApplicationException("question must not be blank", Status.BAD_REQUEST);
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            throw new WebApplicationException("question is too long", Status.BAD_REQUEST);
        }
        try {
            return new AssistantResponse(assistant.answer(request.question()));
        } catch (InputGuardrailException e) {
            LOG.warnf("Question rejected by input guardrail: %s", e.getMessage());
            throw new WebApplicationException("question was rejected", Status.BAD_REQUEST);
        } catch (RuntimeException e) {
            LOG.error("Assistant call failed", e);
            throw new WebApplicationException("The assistant is unavailable", Status.SERVICE_UNAVAILABLE);
        }
    }
}
