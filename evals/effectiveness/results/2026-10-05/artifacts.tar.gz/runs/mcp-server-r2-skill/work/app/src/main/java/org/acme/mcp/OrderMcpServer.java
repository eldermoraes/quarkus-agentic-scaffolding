package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;

/*
 * Offers the order operations to remote MCP clients over Streamable HTTP at /mcp.
 * In production, put /mcp behind the application's normal access layer (HTTP auth or a gateway).
 * io.quarkiverse.mcp.server.Tool is for remote clients; the LangChain4j @Tool lives on OrderTools.
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(description = "Gets the current status of an order by its order id (for example ORD-1001)")
    public OrderStatus getOrderStatus(
            @ToolArg(description = "The order id, for example ORD-1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(description = "Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, for example CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return (1-20)", required = false,
                    defaultValue = "5") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
