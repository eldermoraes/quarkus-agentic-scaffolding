package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.acme.ai.OrderAssistant;
import org.acme.dto.Order;
import org.acme.dto.OrderStatus;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderToolsTest {

    @Inject
    OrderTools tools;

    @Inject
    OrderAssistant assistant;

    @Test
    void assistantIsWired() {
        // No model call: proves CDI wiring and AI-service augmentation only.
        assertNotNull(assistant);
    }

    @Test
    void statusOfKnownAndUnknownOrder() {
        assertEquals("SHIPPED", tools.getOrderStatus("ORD-1002").status());
        assertEquals(OrderStatus.NOT_FOUND, tools.getOrderStatus("nope").status());
    }

    @Test
    void recentOrdersAreNewestFirstAndLimited() {
        List<Order> orders = tools.listRecentOrders("CUST-1", 2);
        assertEquals(List.of("ORD-1003", "ORD-1002"), orders.stream().map(Order::id).toList());
        assertTrue(tools.listRecentOrders("unknown", 5).isEmpty());
    }
}
