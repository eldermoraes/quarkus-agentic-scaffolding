package org.acme.dto;

import java.time.Instant;

/** An order held in the in-memory store. */
public record Order(String id, String customerId, String status, double total, Instant placedAt) {
}
