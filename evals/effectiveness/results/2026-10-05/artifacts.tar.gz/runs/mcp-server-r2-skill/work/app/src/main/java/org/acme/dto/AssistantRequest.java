package org.acme.dto;

public record AssistantRequest(String question) {
}
