package org.acme.tools;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Order lookups backed by an in-memory map. The same bean backs both the LangChain4j tools used by
 * the assistant and the MCP tools offered to remote clients (see {@code OrderMcpServer}).
 */
@ApplicationScoped
public class OrderTools {

    static final int MAX_RECENT = 20;

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderTools() {
        Instant now = Instant.now();
        seed(new Order("ORD-1001", "CUST-1", "DELIVERED", 59.90, now.minus(30, ChronoUnit.DAYS)));
        seed(new Order("ORD-1002", "CUST-1", "SHIPPED", 129.00, now.minus(3, ChronoUnit.DAYS)));
        seed(new Order("ORD-1003", "CUST-1", "PROCESSING", 15.50, now.minus(1, ChronoUnit.DAYS)));
        seed(new Order("ORD-2001", "CUST-2", "CANCELLED", 249.99, now.minus(10, ChronoUnit.DAYS)));
        seed(new Order("ORD-2002", "CUST-2", "DELIVERED", 42.00, now.minus(5, ChronoUnit.DAYS)));
    }

    private void seed(Order order) {
        orders.put(order.id(), order);
    }

    @Tool("Gets the current status of an order by its order id (for example ORD-1001)")
    public OrderStatus getOrderStatus(@P("The order id, for example ORD-1001") String orderId) {
        Order order = orderId == null ? null : orders.get(orderId.trim());
        return order == null
                ? new OrderStatus(orderId, OrderStatus.NOT_FOUND)
                : new OrderStatus(order.id(), order.status());
    }

    @Tool("Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(
            @P("The customer id, for example CUST-1") String customerId,
            @P("Maximum number of orders to return (1-20)") int limit) {
        if (customerId == null) {
            return List.of();
        }
        int bounded = Math.max(1, Math.min(limit, MAX_RECENT));
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId.trim()))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(bounded)
                .toList();
    }
}
