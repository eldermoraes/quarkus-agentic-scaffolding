package org.acme.dto;

/** Result of a status lookup; {@code status} is {@code NOT_FOUND} for an unknown id. */
public record OrderStatus(String orderId, String status) {

    public static final String NOT_FOUND = "NOT_FOUND";
}
