package org.acme.dto;

import java.util.List;

/** Output of one reviewer: a short assessment, its key concerns and a verdict. */
public record ReviewFindings(String summary, List<String> concerns, String verdict) {}
