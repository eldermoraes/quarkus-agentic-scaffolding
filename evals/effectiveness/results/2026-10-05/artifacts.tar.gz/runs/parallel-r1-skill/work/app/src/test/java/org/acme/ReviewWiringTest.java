package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.workflow.ReviewWorkflow;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: builds the CDI container without calling a model. */
@QuarkusTest
class ReviewWiringTest {

    @Inject
    ReviewWorkflow workflow;

    @Test
    void workflowIsWired() {
        assertNotNull(workflow);
    }
}
