package org.acme.dto;

public record ReviewReport(ReviewFindings technical, ReviewFindings business, String overallVerdict) {}
