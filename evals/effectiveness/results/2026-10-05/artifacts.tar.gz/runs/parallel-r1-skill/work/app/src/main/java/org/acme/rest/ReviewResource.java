package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;
import org.acme.dto.BriefRequest;
import org.acme.dto.ReviewReport;
import org.acme.guardrails.BriefInjectionGuard;
import org.acme.workflow.ReviewWorkflow;
import org.jboss.logging.Logger;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    private static final Logger LOG = Logger.getLogger(ReviewResource.class);

    @Inject
    ReviewWorkflow workflow;

    @POST
    @RunOnVirtualThread
    public ReviewReport review(BriefRequest request) {
        String brief = request == null ? null : request.brief();
        if (brief == null || brief.isBlank()) {
            throw error(Response.Status.BAD_REQUEST, "Brief must not be empty.");
        }
        if (brief.length() > BriefInjectionGuard.MAX_INPUT_CHARS) {
            throw error(Response.Status.BAD_REQUEST,
                    "Brief exceeds the " + BriefInjectionGuard.MAX_INPUT_CHARS + "-character limit.");
        }
        try {
            return workflow.review(brief);
        } catch (Exception e) {
            // Log in full, return nothing internal.
            LOG.error("Review failed", e);
            throw error(Response.Status.BAD_GATEWAY, "Review failed. Please try again.");
        }
    }

    private static WebApplicationException error(Response.Status status, String message) {
        return new WebApplicationException(Response.status(status)
                .type(MediaType.APPLICATION_JSON)
                .entity(Map.of("error", message)).build());
    }
}
