package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.acme.dto.ReviewFindings;
import org.acme.dto.ReviewReport;

/** Runs both reviewers concurrently and combines their findings into one report. */
public interface ReviewWorkflow {

    @ParallelAgent(outputKey = "report", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport assemble(AgenticScope scope) {
        ReviewFindings technical = (ReviewFindings) scope.readState("technical");
        ReviewFindings business = (ReviewFindings) scope.readState("business");
        return new ReviewReport(technical, business, overall(technical, business));
    }

    private static String overall(ReviewFindings technical, ReviewFindings business) {
        String t = technical == null ? null : technical.verdict();
        String b = business == null ? null : business.verdict();
        if ("NO_GO".equals(t) || "NO_GO".equals(b)) {
            return "NO_GO";
        }
        if ("GO".equals(t) && "GO".equals(b)) {
            return "GO";
        }
        return "GO_WITH_CHANGES";
    }
}
