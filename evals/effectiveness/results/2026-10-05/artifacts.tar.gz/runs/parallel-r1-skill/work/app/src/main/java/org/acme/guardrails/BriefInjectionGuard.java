package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Input guardrail for the entry agents: the brief is externally authored free text. */
@ApplicationScoped
public class BriefInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 8_000;

    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?brief>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS + 64) {
            return failure("Input exceeds the character limit.");
        }
        // The prompt template adds exactly one <brief>...</brief> pair; any other delimiter is smuggled.
        String inner = text.strip().replaceFirst("^<brief>", "").replaceFirst("</brief>$", "");
        if (DELIMITER_MARKUP.matcher(inner).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
