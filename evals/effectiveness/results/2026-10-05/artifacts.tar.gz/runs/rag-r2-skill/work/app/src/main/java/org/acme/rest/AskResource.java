package org.acme.rest;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.ai.DocsAssistant;
import org.acme.dto.AskRequest;
import org.acme.dto.AskResponse;
import org.jboss.logging.Logger;
import org.jboss.resteasy.reactive.server.ServerExceptionMapper;

@Path("/ask")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AskResource {

    private static final Logger LOG = Logger.getLogger(AskResource.class);

    @Inject
    DocsAssistant assistant;

    @POST
    public AskResponse ask(AskRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new jakarta.ws.rs.BadRequestException("'question' must not be blank");
        }
        return new AskResponse(assistant.answer(request.question()));
    }

    @ServerExceptionMapper
    public Response rejected(InputGuardrailException e) {
        LOG.warn("Question rejected by input guardrail", e);
        return Response.status(Response.Status.BAD_REQUEST)
                .entity(new AskResponse("Question rejected."))
                .build();
    }
}
