# Acme Widget Service — Getting Started

## Overview

The Acme Widget Service lets teams create, list, and retire widgets through a REST API.

## Authentication

Every request must send an `X-Api-Key` header. Keys are issued from the admin console
and expire after 90 days. Requests without a valid key receive `401 Unauthorized`.

## Rate limits

Each key may make 100 requests per minute. Exceeding the limit returns `429 Too Many Requests`
with a `Retry-After` header.

## Support

Contact support@acme.example for help. Support hours are 09:00–17:00 UTC, Monday to Friday.
