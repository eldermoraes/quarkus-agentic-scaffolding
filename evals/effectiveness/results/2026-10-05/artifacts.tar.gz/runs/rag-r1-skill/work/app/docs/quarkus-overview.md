# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It is designed for fast startup times and low memory consumption.

## Dev Mode

Run `mvn quarkus:dev` to start dev mode. It provides live reload: code changes are
applied on the next request without restarting the application. The Dev UI is
available at `/q/dev` while dev mode is running.

## Extensions

Quarkus functionality is added through extensions, for example `quarkus-rest` for
REST endpoints and `quarkus-langchain4j-ollama` for talking to Ollama models.

## Native Executables

Build a native executable with `mvn package -Dnative`. Native executables start in
milliseconds and use far less memory than a regular JVM process.
