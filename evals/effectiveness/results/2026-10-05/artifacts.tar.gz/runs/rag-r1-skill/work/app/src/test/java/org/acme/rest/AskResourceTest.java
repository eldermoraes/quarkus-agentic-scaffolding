package org.acme.rest;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import java.util.Map;
import org.junit.jupiter.api.Test;

@QuarkusTest
class AskResourceTest {

    @Test
    void blankQuestionIsRejected() {
        given().contentType("application/json").body(Map.of("question", ""))
                .when().post("/ask")
                .then().statusCode(400);
    }
}
