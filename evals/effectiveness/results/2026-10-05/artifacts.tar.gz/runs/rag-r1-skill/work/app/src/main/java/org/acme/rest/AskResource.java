package org.acme.rest;

import dev.langchain4j.guardrail.InputGuardrailException;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.ai.DocsAssistant;
import org.acme.dto.AskRequest;
import org.acme.dto.AskResponse;
import org.jboss.logging.Logger;

@Path("/ask")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AskResource {

    private static final Logger LOG = Logger.getLogger(AskResource.class);

    @Inject
    DocsAssistant assistant;

    @POST
    @RunOnVirtualThread
    public Response ask(@Valid AskRequest request) {
        try {
            return Response.ok(new AskResponse(assistant.ask(request.question()))).build();
        } catch (InputGuardrailException e) {
            LOG.debug("Question rejected by input guardrail", e);
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(new AskResponse("Question rejected.")).build();
        } catch (RuntimeException e) {
            LOG.error("Failed to answer question", e);
            return Response.serverError().entity(new AskResponse("Unable to answer right now.")).build();
        }
    }
}
