# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.

## Dev Mode

Run `mvn quarkus:dev` to start live coding. Changes to source files are
picked up automatically without restarting the application.

## Dev Services

Dev Services automatically start containers for databases and other
backing services during development and tests, without any configuration.

## Native Executables

Quarkus applications can be compiled to native executables with GraalVM,
giving very fast startup time and low memory usage.
