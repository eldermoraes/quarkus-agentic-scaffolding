package org.acme.tools;

import org.acme.service.OrderService;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @Tool("Looks up the shipping status of an order by its order id")
    public String getShippingStatus(@P("The order id, e.g. 1001") String orderId) {
        return orders.findOrder(orderId)
                .map(o -> "Order %s: status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s".formatted(
                        o.id(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("Order not found: " + orderId);
    }

    @Tool("Opens a refund request for an order. Only call after the customer explicitly asked for a refund and gave a reason")
    public String openRefundRequest(@P("The order id") String orderId,
            @P("The customer's reason for the refund") String reason) {
        return orders.openRefund(orderId, reason)
                .map(r -> "Refund request %s opened for order %s (status=%s)".formatted(r.refundId(), r.orderId(),
                        r.status()))
                .orElse("Order not found: " + orderId);
    }
}
