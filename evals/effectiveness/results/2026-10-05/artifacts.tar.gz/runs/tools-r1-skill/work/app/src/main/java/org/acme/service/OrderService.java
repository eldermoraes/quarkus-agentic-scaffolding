package org.acme.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.acme.dto.Order;
import org.acme.dto.RefundRequest;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderService() {
        List.of(
                new Order("1001", "alice", "SHIPPED", "DHL", "DHL123456", LocalDate.now().plusDays(2), 59.90),
                new Order("1002", "bob", "PROCESSING", null, null, LocalDate.now().plusDays(6), 120.00),
                new Order("1003", "carol", "DELIVERED", "UPS", "UPS987654", LocalDate.now().minusDays(3), 25.50))
                .forEach(o -> orders.put(o.id(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orders.get(orderId));
    }

    /** Opens a refund request; returns empty if the order does not exist. Idempotent per order. */
    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        if (!orders.containsKey(orderId)) {
            return Optional.empty();
        }
        return Optional.of(refunds.computeIfAbsent(orderId,
                id -> new RefundRequest("R-" + refundSeq.incrementAndGet(), id, reason, "OPEN")));
    }
}
