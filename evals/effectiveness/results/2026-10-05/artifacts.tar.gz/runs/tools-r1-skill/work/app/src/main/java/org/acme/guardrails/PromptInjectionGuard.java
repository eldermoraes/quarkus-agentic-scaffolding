package org.acme.guardrails;

import java.util.List;
import java.util.Locale;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Cheap heuristic screen for obvious prompt-injection attempts in customer text. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final List<String> MARKERS = List.of(
            "ignore previous instructions", "ignore all previous", "disregard your instructions",
            "reveal your system prompt", "you are now");

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText().toLowerCase(Locale.ROOT);
        for (String m : MARKERS) {
            if (text.contains(m)) {
                return failure("Message rejected by input guardrail");
            }
        }
        return success();
    }
}
