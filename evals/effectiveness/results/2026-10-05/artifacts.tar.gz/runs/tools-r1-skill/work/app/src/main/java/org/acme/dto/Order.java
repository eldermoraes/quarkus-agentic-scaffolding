package org.acme.dto;

import java.time.LocalDate;

public record Order(String id, String customer, String status, String carrier, String trackingNumber,
        LocalDate estimatedDelivery, double total) {
}
