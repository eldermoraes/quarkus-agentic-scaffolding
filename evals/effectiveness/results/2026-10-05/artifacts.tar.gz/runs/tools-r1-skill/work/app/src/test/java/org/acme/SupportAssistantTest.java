package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.SupportAssistant;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void wiring() {
        assertNotNull(assistant);
    }

    @Test
    void shippingStatus() {
        assertTrue(tools.getShippingStatus("1001").contains("SHIPPED"));
        assertTrue(tools.getShippingStatus("nope").contains("not found"));
    }

    @Test
    void refund() {
        assertTrue(tools.openRefundRequest("1003", "damaged").contains("opened"));
        assertTrue(tools.openRefundRequest("nope", "x").contains("not found"));
    }
}
