package org.acme;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** In-memory order and refund data. */
@ApplicationScoped
public class OrderService {

    public record Order(String id, String status, String carrier, String trackingNumber, String estimatedDelivery,
            double total) {
    }

    public record RefundRequest(String refundId, String orderId, String reason, String status) {
    }

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicLong refundSeq = new AtomicLong(1000);

    public OrderService() {
        List.of(
                new Order("1001", "SHIPPED", "DHL", "DHL123456", "2026-10-08", 59.90),
                new Order("1002", "DELIVERED", "UPS", "UPS987654", "2026-10-01", 120.00),
                new Order("1003", "PROCESSING", "N/A", "N/A", "2026-10-12", 25.50))
                .forEach(o -> orders.put(o.id(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(String::trim).map(orders::get);
    }

    /** Opens a refund; returns empty when the order does not exist. Repeated requests return the existing one. */
    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        return findOrder(orderId).map(order -> refunds.computeIfAbsent(order.id(),
                id -> new RefundRequest("RF-" + refundSeq.incrementAndGet(), id, reason, "OPEN")));
    }
}
