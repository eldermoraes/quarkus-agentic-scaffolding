package org.acme;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class OrderToolsTest {

    private final OrderTools tools = new OrderTools();

    OrderToolsTest() {
        tools.orders = new OrderService();
    }

    @Test
    void shippingStatusForKnownOrder() {
        assertTrue(tools.getShippingStatus("1001").contains("SHIPPED"));
    }

    @Test
    void shippingStatusForUnknownOrder() {
        assertTrue(tools.getShippingStatus("9999").contains("No order found"));
    }

    @Test
    void refundOpenedOnceForKnownOrder() {
        String first = tools.openRefundRequest("1002", "damaged");
        assertTrue(first.contains("opened"));
        assertTrue(tools.openRefundRequest("1002", "again").contains(first.split(" ")[2]));
    }

    @Test
    void refundRejectedForUnknownOrder() {
        assertTrue(tools.openRefundRequest("9999", "x").contains("not opened"));
    }
}
