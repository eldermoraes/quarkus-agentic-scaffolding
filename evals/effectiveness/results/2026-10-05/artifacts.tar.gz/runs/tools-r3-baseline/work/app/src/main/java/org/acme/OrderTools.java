package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @Tool("Looks up the shipping status of an order (status, carrier, tracking number, estimated delivery)")
    public String getShippingStatus(@P("The order id, e.g. 1001") String orderId) {
        return orders.findOrder(orderId)
                .map(o -> "Order %s: status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s"
                        .formatted(o.id(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an order. Only call when the customer explicitly asks for a refund.")
    public String openRefundRequest(@P("The order id, e.g. 1001") String orderId,
            @P("The reason for the refund given by the customer") String reason) {
        return orders.openRefund(orderId, reason)
                .map(r -> "Refund request %s opened for order %s with status %s".formatted(r.refundId(), r.orderId(),
                        r.status()))
                .orElse("No order found with id " + orderId + "; refund not opened");
    }
}
