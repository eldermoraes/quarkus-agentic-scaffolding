package org.acme;

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService(tools = OrderTools.class)
public interface SupportAssistant {

    @SystemMessage("""
            You are a friendly customer support assistant for an online store.
            Use the available tools to look up an order's shipping status and to open refund requests.
            Never invent order data: if you need an order id, ask the customer for it.
            Only open a refund request after the customer clearly asks for a refund and gives the order id and a reason.
            Keep answers short and polite.
            """)
    String chat(@MemoryId String conversationId, @UserMessage String message);
}
