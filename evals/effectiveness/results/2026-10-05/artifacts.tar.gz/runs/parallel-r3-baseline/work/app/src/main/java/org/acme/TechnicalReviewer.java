package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface TechnicalReviewer {

    @SystemMessage("""
            You are a senior software architect reviewing a product brief.
            Assess technical feasibility, architecture, key risks, dependencies and effort.
            Be concise: use short bullet points and end with a one-line verdict.
            """)
    @UserMessage("Product brief:\n{brief}")
    String review(String brief);
}
