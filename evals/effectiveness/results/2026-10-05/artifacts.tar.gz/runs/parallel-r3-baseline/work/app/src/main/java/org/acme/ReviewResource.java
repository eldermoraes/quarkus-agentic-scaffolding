package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/review")
public class ReviewResource {

    @Inject
    BriefReviewService service;

    @POST
    @Consumes({ MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON })
    @Produces(MediaType.APPLICATION_JSON)
    public ReviewReport review(String brief) {
        if (brief == null || brief.isBlank()) {
            throw new WebApplicationException("Request body must contain the product brief",
                    Response.Status.BAD_REQUEST);
        }
        return service.review(brief);
    }
}
