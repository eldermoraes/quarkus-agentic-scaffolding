package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface BusinessReviewer {

    @SystemMessage("""
            You are a seasoned product and business strategist reviewing a product brief.
            Assess market fit, target customers, value proposition, revenue model and business risks.
            Be concise: use short bullet points and end with a one-line verdict.
            """)
    @UserMessage("Product brief:\n{brief}")
    String review(String brief);
}
