package org.acme;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Orchestrates the workflow: both reviewer agents run in parallel on the same brief,
 * then their outputs are combined into a single report.
 */
@ApplicationScoped
public class BriefReviewService {

    @Inject
    TechnicalReviewer technicalReviewer;

    @Inject
    BusinessReviewer businessReviewer;

    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

    public ReviewReport review(String brief) {
        CompletableFuture<String> technical =
                CompletableFuture.supplyAsync(() -> technicalReviewer.review(brief), executor);
        CompletableFuture<String> business =
                CompletableFuture.supplyAsync(() -> businessReviewer.review(brief), executor);

        try {
            CompletableFuture.allOf(technical, business).join();
        } catch (CompletionException e) {
            throw new IllegalStateException("Review failed: " + e.getCause().getMessage(), e.getCause());
        }

        String technicalReview = technical.join();
        String businessReview = business.join();
        return new ReviewReport(technicalReview, businessReview, combine(technicalReview, businessReview));
    }

    static String combine(String technicalReview, String businessReview) {
        return """
                # Product Brief Review

                ## Technical Review
                %s

                ## Business Review
                %s
                """.formatted(technicalReview.strip(), businessReview.strip());
    }

    @PreDestroy
    void shutdown() {
        executor.shutdown();
    }
}
