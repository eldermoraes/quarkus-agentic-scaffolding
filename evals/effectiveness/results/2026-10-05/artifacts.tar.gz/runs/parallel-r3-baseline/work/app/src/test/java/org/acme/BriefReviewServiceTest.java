package org.acme;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class BriefReviewServiceTest {

    @Test
    void combineContainsBothReviews() {
        String report = BriefReviewService.combine(" tech ", " biz ");
        assertTrue(report.contains("## Technical Review\ntech"));
        assertTrue(report.contains("## Business Review\nbiz"));
    }
}
