package org.acme.dto;

public record AssistantRequest(String customerId, String question) {}
