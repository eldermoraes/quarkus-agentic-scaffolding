package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;

/** Offers the order operations to remote MCP clients over Streamable HTTP at /mcp. */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(description = "Gets the status of an order by its id; null if not found")
    public Order getOrderStatus(@ToolArg(description = "The order id, e.g. ORD-1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(description = "Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders (1-20)", defaultValue = "5") int limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
