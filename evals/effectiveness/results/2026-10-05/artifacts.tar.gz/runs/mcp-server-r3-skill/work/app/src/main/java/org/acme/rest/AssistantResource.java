package org.acme.rest;

import org.acme.ai.OrderAssistant;
import org.acme.dto.AssistantRequest;
import org.acme.dto.AssistantResponse;
import org.jboss.logging.Logger;

import dev.langchain4j.guardrail.InputGuardrailException;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    private static final Logger LOG = Logger.getLogger(AssistantResource.class);

    @Inject
    OrderAssistant assistant;

    @POST
    @RunOnVirtualThread
    public Response ask(AssistantRequest request) {
        if (request == null || isBlank(request.customerId()) || isBlank(request.question())) {
            return error(Response.Status.BAD_REQUEST, "customerId and question are required");
        }
        try {
            return Response.ok(new AssistantResponse(
                    assistant.answer(request.customerId(), request.question()))).build();
        } catch (InputGuardrailException e) {
            return error(Response.Status.BAD_REQUEST, "The question was rejected");
        } catch (RuntimeException e) {
            LOG.error("Assistant call failed", e);
            return error(Response.Status.BAD_GATEWAY, "The assistant is unavailable");
        }
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    private static Response error(Response.Status status, String message) {
        return Response.status(status).entity(new AssistantResponse(message)).build();
    }
}
