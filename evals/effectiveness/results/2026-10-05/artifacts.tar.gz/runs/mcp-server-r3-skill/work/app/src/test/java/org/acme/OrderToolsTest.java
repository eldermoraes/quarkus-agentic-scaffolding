package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.acme.ai.OrderAssistant;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderToolsTest {

    @Inject
    OrderTools tools;

    @Inject
    OrderAssistant assistant; // wiring smoke test: no model call

    @Test
    void statusLookup() {
        assertEquals("SHIPPED", tools.getOrderStatus("ORD-1002").status());
        assertNull(tools.getOrderStatus("nope"));
    }

    @Test
    void recentOrdersNewestFirst() {
        var list = tools.listRecentOrders("CUST-1", 2);
        assertEquals(2, list.size());
        assertEquals("ORD-1003", list.get(0).id());
    }

    @Test
    void assistantWired() {
        assertNotNull(assistant);
    }
}
