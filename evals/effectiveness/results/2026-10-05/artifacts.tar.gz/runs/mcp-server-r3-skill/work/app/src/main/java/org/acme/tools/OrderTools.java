package org.acme.tools;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Order lookups backed by an in-memory map. One implementation serves both the
 * LangChain4j assistant (@Tool below) and remote MCP clients (see OrderMcpServer).
 */
@ApplicationScoped
public class OrderTools {

    private static final int MAX_LIMIT = 20;

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderTools() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", "DELIVERED", now.minus(30, ChronoUnit.DAYS), 59.90));
        add(new Order("ORD-1002", "CUST-1", "SHIPPED", now.minus(3, ChronoUnit.DAYS), 120.00));
        add(new Order("ORD-1003", "CUST-1", "PROCESSING", now.minus(1, ChronoUnit.DAYS), 15.50));
        add(new Order("ORD-2001", "CUST-2", "CANCELLED", now.minus(10, ChronoUnit.DAYS), 300.00));
        add(new Order("ORD-2002", "CUST-2", "SHIPPED", now.minus(2, ChronoUnit.DAYS), 42.00));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    @Tool("Gets the status of an order by its id (e.g. ORD-1001). Returns the order, or null if not found.")
    public Order getOrderStatus(@P("The order id") String orderId) {
        return Optional.ofNullable(orderId).map(orders::get).orElse(null);
    }

    @Tool("Lists the most recent orders of a customer (e.g. CUST-1), newest first")
    public List<Order> listRecentOrders(
            @P("The customer id") String customerId,
            @P("Maximum number of orders to return (1-20)") int limit) {
        int effective = Math.max(1, Math.min(limit, MAX_LIMIT));
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(effective)
                .toList();
    }
}
