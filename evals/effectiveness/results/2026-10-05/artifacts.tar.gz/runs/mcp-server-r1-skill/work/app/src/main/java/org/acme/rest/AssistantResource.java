package org.acme.rest;

import org.acme.ai.OrderAssistant;
import org.jboss.logging.Logger;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    private static final Logger LOG = Logger.getLogger(AssistantResource.class);
    private static final int MAX_QUESTION_CHARS = 2_000;

    public record AssistantRequest(String question) {}

    public record AssistantResponse(String answer) {}

    @Inject
    OrderAssistant assistant;

    @POST
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new WebApplicationException("question must not be blank", Response.Status.BAD_REQUEST);
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            throw new WebApplicationException("question is too long", Response.Status.BAD_REQUEST);
        }
        try {
            return new AssistantResponse(assistant.answer(request.question()));
        } catch (InputGuardrailException e) {
            LOG.warn("Assistant input rejected by guardrail", e);
            throw new WebApplicationException("question was rejected", Response.Status.BAD_REQUEST);
        }
    }
}
