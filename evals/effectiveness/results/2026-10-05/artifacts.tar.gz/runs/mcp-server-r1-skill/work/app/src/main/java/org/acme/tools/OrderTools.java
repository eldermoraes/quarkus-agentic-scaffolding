package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.service.OrderService;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** Order lookups offered to our own model (the /assistant AI service). */
@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @Tool("Gets the status of an order by its id. Returns a not-found message if the id is unknown.")
    public String getOrderStatus(@P("The order id, e.g. ORD-1001") String orderId) {
        return orders.findById(orderId)
                .map(o -> "Order %s: status=%s, total=%s, placedAt=%s".formatted(o.id(), o.status(), o.total(), o.placedAt()))
                .orElse("Order not found: " + orderId);
    }

    @Tool("Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(@P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return (1-50)") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
