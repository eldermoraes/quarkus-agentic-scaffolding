package org.acme.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record Order(String id, String customerId, OrderStatus status, BigDecimal total, Instant placedAt) {

    public enum OrderStatus {
        PENDING, PROCESSING, SHIPPED, DELIVERED, CANCELLED
    }
}
