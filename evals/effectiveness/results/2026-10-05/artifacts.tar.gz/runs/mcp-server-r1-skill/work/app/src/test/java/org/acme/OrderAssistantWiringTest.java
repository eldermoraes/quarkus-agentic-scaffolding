package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.OrderAssistant;
import org.acme.service.OrderService;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: no model call, no Ollama needed. */
@QuarkusTest
class OrderAssistantWiringTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderService orders;

    @Test
    void assistantIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void ordersLookup() {
        assertTrue(orders.findById("ORD-1002").isPresent());
        var recent = orders.recentForCustomer("CUST-1", 2);
        assertEquals(2, recent.size());
        assertEquals("ORD-1003", recent.get(0).id());
    }
}
