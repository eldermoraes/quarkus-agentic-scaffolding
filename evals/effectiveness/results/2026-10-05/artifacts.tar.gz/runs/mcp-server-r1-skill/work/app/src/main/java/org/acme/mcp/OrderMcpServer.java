package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;

/*
 * Offers the order operations to remote MCP clients over Streamable HTTP at /mcp.
 * Delegates to OrderTools so one implementation backs both the MCP server and /assistant.
 * In production, put /mcp behind the application's access layer (auth policy or gateway).
 */
public class OrderMcpServer {

    @Inject
    OrderTools orderTools;

    @Tool(description = "Gets the status of an order by its id")
    public String getOrderStatus(@ToolArg(description = "The order id, e.g. ORD-1001") String orderId) {
        return orderTools.getOrderStatus(orderId);
    }

    @Tool(description = "Lists a customer's most recent orders, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return (1-50)", required = false, defaultValue = "5") int limit) {
        return orderTools.listRecentOrders(customerId, limit);
    }
}
