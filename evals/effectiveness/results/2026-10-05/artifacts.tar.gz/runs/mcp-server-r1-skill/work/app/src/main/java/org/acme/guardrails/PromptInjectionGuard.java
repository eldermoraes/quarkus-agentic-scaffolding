package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Validates the rendered user message. The prompt template itself contributes exactly one
 * opening and one closing {@code <question>} tag; any additional delimiter markup comes from
 * the caller's text and would let it escape the delimited region, so it is rejected.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final int MAX_INPUT_CHARS = 4_000;

    private static final Pattern DELIMITER_MARKUP = Pattern.compile("</?question>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(text).results().count() != 2) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
