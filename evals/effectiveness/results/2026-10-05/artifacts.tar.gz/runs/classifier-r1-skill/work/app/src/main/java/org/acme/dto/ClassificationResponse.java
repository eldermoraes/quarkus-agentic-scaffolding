package org.acme.dto;

public record ClassificationResponse(Category category) {
}
