package org.acme.rest;

import dev.langchain4j.guardrail.GuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.ai.TicketClassifier;
import org.acme.dto.ClassificationResponse;
import org.acme.dto.TicketRequest;
import org.acme.guardrails.PromptInjectionGuard;
import org.jboss.logging.Logger;
import org.jboss.resteasy.reactive.server.ServerExceptionMapper;

@Path("/classify")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ClassifyResource {

    private static final Logger LOG = Logger.getLogger(ClassifyResource.class);

    @Inject
    TicketClassifier classifier;

    @POST
    public ClassificationResponse classify(TicketRequest request) {
        if (request == null || request.text() == null || request.text().isBlank()) {
            throw new BadRequestException("Ticket text must not be blank.");
        }
        if (request.text().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("Ticket text is too long.");
        }
        return new ClassificationResponse(classifier.classify(request.text()));
    }

    @ServerExceptionMapper
    public Response guardrailRejected(GuardrailException e) {
        LOG.warn("Ticket rejected by guardrail", e);
        return Response.status(Response.Status.BAD_REQUEST)
                .entity("Ticket rejected.")
                .type(MediaType.TEXT_PLAIN)
                .build();
    }
}
