package org.acme.dto;

public record TicketRequest(String text) {
}
