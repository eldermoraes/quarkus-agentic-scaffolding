package org.acme.rest;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ClassifyResourceTest {

    @Test
    void blankTicketIsRejected() {
        given().contentType("application/json").body("{\"text\":\"  \"}")
                .when().post("/classify")
                .then().statusCode(400);
    }
}
