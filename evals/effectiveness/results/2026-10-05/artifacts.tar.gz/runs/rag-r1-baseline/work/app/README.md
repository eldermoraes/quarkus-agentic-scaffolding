# docs-qa

RAG question answering over the Markdown files in `docs/` (Quarkus + LangChain4j, Ollama chat model, in-process embeddings via Easy RAG).

Run (requires a local Ollama with `llama3.2` pulled): `mvn quarkus:dev`

Ask a question: POST `/ask` with a JSON body such as `{"question": "What is the rate limit?"}`; the response is `{"answer": "..."}`.

Documents are ingested at startup from `quarkus.langchain4j.easy-rag.path` (default `docs`).
