package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/ask")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AskResource {

    public record AskRequest(String question) {
    }

    public record AskResponse(String answer) {
    }

    @Inject
    DocsAssistant assistant;

    @POST
    public AskResponse ask(AskRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new WebApplicationException("'question' is required", Response.Status.BAD_REQUEST);
        }
        return new AskResponse(assistant.answer(request.question()));
    }
}
