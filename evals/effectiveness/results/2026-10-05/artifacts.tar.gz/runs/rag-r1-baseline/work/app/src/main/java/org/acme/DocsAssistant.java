package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;
import jakarta.enterprise.context.ApplicationScoped;

@RegisterAiService
@ApplicationScoped
public interface DocsAssistant {

    @SystemMessage("""
            You answer questions using only the provided documentation excerpts.
            If the excerpts do not contain the answer, say you don't know.
            Keep answers concise.
            """)
    String answer(@UserMessage String question);
}
