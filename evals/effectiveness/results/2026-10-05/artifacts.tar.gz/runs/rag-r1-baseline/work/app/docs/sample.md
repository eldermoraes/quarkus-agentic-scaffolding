# Acme Widget Service

The Acme Widget Service stores and serves widgets over a REST API.

## Authentication

Clients authenticate with an API key sent in the `X-Api-Key` header. Keys are issued from the admin console and expire after 90 days.

## Rate limits

Each API key may make 100 requests per minute. Requests above the limit receive HTTP 429 and should be retried after the number of seconds in the `Retry-After` header.

## Support

Support is available on weekdays from 09:00 to 17:00 UTC at support@acme.example.
