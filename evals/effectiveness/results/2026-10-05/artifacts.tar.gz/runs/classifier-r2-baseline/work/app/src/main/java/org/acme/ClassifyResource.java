package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;

@Path("/classify")
public class ClassifyResource {

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public ClassificationResult classify(String ticket) {
        if (ticket == null || ticket.isBlank()) {
            throw new WebApplicationException("Ticket text must not be empty", 400);
        }
        return new ClassificationResult(classifier.classify(ticket));
    }

    public record ClassificationResult(Category category) {
    }
}
