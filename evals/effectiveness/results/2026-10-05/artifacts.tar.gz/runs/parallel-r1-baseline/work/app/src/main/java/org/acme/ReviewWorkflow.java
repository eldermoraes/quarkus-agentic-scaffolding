package org.acme;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class ReviewWorkflow {

    @Inject
    TechnicalReviewer technicalReviewer;

    @Inject
    BusinessReviewer businessReviewer;

    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

    /** Runs both reviewers in parallel and merges their output into one report. */
    public ReviewReport review(String brief) {
        CompletableFuture<String> technical = CompletableFuture.supplyAsync(() -> technicalReviewer.review(brief), executor);
        CompletableFuture<String> business = CompletableFuture.supplyAsync(() -> businessReviewer.review(brief), executor);
        CompletableFuture.allOf(technical, business).join();
        String t = technical.join();
        String b = business.join();
        return new ReviewReport(brief, t, b, combine(t, b));
    }

    static String combine(String technical, String business) {
        return """
                # Product Brief Review

                ## Technical Review

                %s

                ## Business Review

                %s
                """.formatted(technical.strip(), business.strip());
    }

    @PreDestroy
    void shutdown() {
        executor.shutdown();
    }
}
