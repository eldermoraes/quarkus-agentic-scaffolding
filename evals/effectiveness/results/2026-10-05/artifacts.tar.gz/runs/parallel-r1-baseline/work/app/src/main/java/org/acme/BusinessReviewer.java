package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface BusinessReviewer {

    @SystemMessage("""
            You are a seasoned product and business strategist acting as a business reviewer of product briefs.
            Assess market fit, target customers, value proposition, revenue model, competition,
            go-to-market, and business risks. Be concise and concrete.
            Answer with short sections: Summary, Strengths, Risks, Recommendations.
            """)
    @UserMessage("Review this product brief from a business perspective:\n\n{brief}")
    String review(String brief);
}
