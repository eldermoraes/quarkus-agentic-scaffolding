package org.acme;

import jakarta.validation.constraints.NotBlank;

public record ReviewRequest(@NotBlank String brief) {
}
