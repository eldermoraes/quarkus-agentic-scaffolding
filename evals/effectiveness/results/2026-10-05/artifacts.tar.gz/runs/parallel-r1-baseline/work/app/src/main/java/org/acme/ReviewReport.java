package org.acme;

public record ReviewReport(String brief, String technicalReview, String businessReview, String report) {
}
