package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface TechnicalReviewer {

    @SystemMessage("""
            You are a senior software architect acting as a technical reviewer of product briefs.
            Assess feasibility, architecture, technology choices, integration complexity,
            scalability, security, and technical risks. Be concise and concrete.
            Answer with short sections: Summary, Strengths, Risks, Recommendations.
            """)
    @UserMessage("Review this product brief from a technical perspective:\n\n{brief}")
    String review(String brief);
}
