package org.acme.dto;

import java.time.LocalDate;

public record Order(String id, String item, ShippingStatus status, String carrier,
        String trackingNumber, LocalDate estimatedDelivery) {

    public enum ShippingStatus { PROCESSING, SHIPPED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED }
}
