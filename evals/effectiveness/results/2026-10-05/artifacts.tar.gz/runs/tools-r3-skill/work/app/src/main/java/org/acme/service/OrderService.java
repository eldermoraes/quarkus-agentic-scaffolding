package org.acme.service;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.acme.dto.Order;
import org.acme.dto.Order.ShippingStatus;
import org.acme.dto.RefundRequest;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();

    public OrderService() {
        List.of(
                new Order("ORD-1001", "Mechanical keyboard", ShippingStatus.SHIPPED, "DHL", "DHL123456", LocalDate.now().plusDays(3)),
                new Order("ORD-1002", "USB-C dock", ShippingStatus.DELIVERED, "UPS", "UPS987654", LocalDate.now().minusDays(2)),
                new Order("ORD-1003", "27-inch monitor", ShippingStatus.PROCESSING, null, null, LocalDate.now().plusDays(7)),
                new Order("ORD-1004", "Webcam", ShippingStatus.CANCELLED, null, null, null))
                .forEach(o -> orders.put(o.id(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return orderId == null ? Optional.empty() : Optional.ofNullable(orders.get(orderId.trim().toUpperCase()));
    }

    /** Opens a refund; returns the existing one if the order already has an open request. */
    public RefundRequest openRefund(Order order, String reason) {
        return refunds.compute(order.id(), (id, existing) -> existing != null ? existing
                : new RefundRequest("RF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                        order.id(), reason, "OPEN"));
    }
}
