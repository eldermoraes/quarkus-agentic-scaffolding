package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Rejects oversized or obviously hostile customer messages before they reach the
 * tool-calling model. Honest heuristic only; tune for production.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final int MAX_INPUT_CHARS = 2_000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_INPUT_CHARS) {
            return failure("Message exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Message rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
