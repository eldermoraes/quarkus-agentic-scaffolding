package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.SupportAssistant;
import org.acme.tools.SupportTools;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportWiringTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    SupportTools tools;

    @Test
    void assistantIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void toolsWorkOnInMemoryData() {
        assertTrue(tools.getShippingStatus("ORD-1001").contains("SHIPPED"));
        assertTrue(tools.getShippingStatus("nope").contains("No order found"));
        String first = tools.openRefundRequest("ORD-1002", "arrived broken");
        assertTrue(first.contains("OPEN"));
        assertEquals(first, tools.openRefundRequest("ORD-1002", "arrived broken"));
        assertTrue(tools.openRefundRequest("ORD-1004", "x").contains("not eligible"));
    }
}
