package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.acme.dto.Order.ShippingStatus;
import org.acme.service.OrderService;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderService orders;

    @Tool("Looks up the shipping status of an order by its id (format ORD-1234).")
    public String getShippingStatus(@P("The order id, e.g. ORD-1001") String orderId) {
        return orders.findOrder(orderId)
                .map(o -> "Order %s (%s): status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s".formatted(
                        o.id(), o.item(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an order. Only call after the customer has confirmed the order id and given a reason.")
    public String openRefundRequest(@P("The order id, e.g. ORD-1001") String orderId,
            @P("The customer's reason for the refund") String reason) {
        if (reason == null || reason.isBlank()) {
            return "A reason is required to open a refund request.";
        }
        var order = orders.findOrder(orderId);
        if (order.isEmpty()) {
            return "No order found with id " + orderId;
        }
        if (order.get().status() == ShippingStatus.CANCELLED) {
            return "Order " + order.get().id() + " is cancelled and is not eligible for a refund.";
        }
        var refund = orders.openRefund(order.get(), reason.strip());
        return "Refund request %s is %s for order %s.".formatted(refund.refundId(), refund.state(), refund.orderId());
    }
}
