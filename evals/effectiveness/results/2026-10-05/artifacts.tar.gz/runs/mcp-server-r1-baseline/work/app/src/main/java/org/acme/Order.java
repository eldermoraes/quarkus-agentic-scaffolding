package org.acme;

import java.time.Instant;

public record Order(String id, String customerId, String status, double total, Instant createdAt) {
}
