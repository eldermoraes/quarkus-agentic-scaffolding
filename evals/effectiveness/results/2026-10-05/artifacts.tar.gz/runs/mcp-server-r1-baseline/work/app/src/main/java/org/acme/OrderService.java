package org.acme;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService() {
        Instant now = Instant.now();
        add(new Order("A1001", "C001", "DELIVERED", 59.90, now.minus(20, ChronoUnit.DAYS)));
        add(new Order("A1002", "C001", "SHIPPED", 120.00, now.minus(3, ChronoUnit.DAYS)));
        add(new Order("A1003", "C001", "PROCESSING", 15.50, now.minus(1, ChronoUnit.DAYS)));
        add(new Order("A2001", "C002", "CANCELLED", 300.00, now.minus(10, ChronoUnit.DAYS)));
        add(new Order("A2002", "C002", "DELIVERED", 42.00, now.minus(5, ChronoUnit.DAYS)));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> getOrder(String orderId) {
        return orderId == null ? Optional.empty() : Optional.ofNullable(orders.get(orderId.trim().toUpperCase()));
    }

    public List<Order> recentOrders(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        int max = Math.max(1, Math.min(limit, 50));
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(customerId.trim()))
                .sorted(Comparator.comparing(Order::createdAt).reversed())
                .limit(max)
                .toList();
    }
}
