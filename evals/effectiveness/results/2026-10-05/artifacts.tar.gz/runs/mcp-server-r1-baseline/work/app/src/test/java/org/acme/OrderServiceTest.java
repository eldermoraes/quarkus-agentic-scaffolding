package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class OrderServiceTest {

    private final OrderService service = new OrderService();

    @Test
    void findsOrderById() {
        assertEquals("SHIPPED", service.getOrder("a1002").orElseThrow().status());
        assertTrue(service.getOrder("nope").isEmpty());
    }

    @Test
    void listsRecentOrdersNewestFirst() {
        var orders = service.recentOrders("C001", 2);
        assertEquals(2, orders.size());
        assertEquals("A1003", orders.get(0).id());
    }
}
