package org.acme;

import java.util.List;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** The same order operations, exposed as LangChain4j tools for the assistant. */
@ApplicationScoped
public class OrderAssistantTools {

    @Inject
    OrderService orders;

    @Tool("Get the status of an order by its id. Returns a message if the order does not exist.")
    public String getOrderStatus(@P("The order id, e.g. A1001") String orderId) {
        return orders.getOrder(orderId)
                .map(Order::toString)
                .orElse("Order not found: " + orderId);
    }

    @Tool("List the most recent orders of a customer, newest first.")
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. C001") String customerId,
            @P("Maximum number of orders to return") int limit) {
        return orders.recentOrders(customerId, limit);
    }
}
