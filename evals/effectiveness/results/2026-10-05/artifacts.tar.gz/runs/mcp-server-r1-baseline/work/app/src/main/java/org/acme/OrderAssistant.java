package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService(tools = OrderAssistantTools.class)
public interface OrderAssistant {

    @SystemMessage("""
            You are a customer support assistant for an online store.
            Answer questions about orders using only the provided tools.
            If an order or customer cannot be found, say so. Never invent order data.
            """)
    String answer(@UserMessage String question);
}
