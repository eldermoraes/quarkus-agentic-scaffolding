package org.acme;

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService(tools = SupportTools.class)
public interface SupportAssistant {

    @SystemMessage("""
            You are a polite customer support assistant for an online store.
            You can check an order's shipping status and open refund requests using the provided tools.
            Always use the tools for order data; never invent order details.
            If the customer has not given an order id, ask for it.
            """)
    String chat(@MemoryId String conversationId, @UserMessage String message);
}
