package org.acme;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderService {

    public record Order(String id, String status, String carrier, String trackingNumber,
            LocalDate estimatedDelivery, double total) {
    }

    public record RefundRequest(String refundId, String orderId, String reason, String status) {
    }

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderService() {
        LocalDate today = LocalDate.now();
        orders.put("1001", new Order("1001", "SHIPPED", "DHL", "DHL123456", today.plusDays(2), 59.90));
        orders.put("1002", new Order("1002", "DELIVERED", "UPS", "UPS987654", today.minusDays(3), 120.00));
        orders.put("1003", new Order("1003", "PROCESSING", "N/A", "N/A", today.plusDays(7), 35.50));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(String::trim).map(orders::get);
    }

    /** Opens a refund; returns empty if the order does not exist. Idempotent per order. */
    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        return findOrder(orderId).map(o -> refunds.computeIfAbsent(o.id(),
                id -> new RefundRequest("RF-" + refundSeq.incrementAndGet(), id, reason, "OPEN")));
    }
}
