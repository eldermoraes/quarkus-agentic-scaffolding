package org.acme;

import java.util.List;

import dev.langchain4j.agent.tool.P;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

/**
 * Order lookup operations, exposed both as MCP tools (remote clients over HTTP)
 * and as LangChain4j tools (used by OrderAssistant).
 */
@Singleton
public class OrderTools {

    @Inject
    OrderRepository repository;

    @io.quarkiverse.mcp.server.Tool(name = "get_order_status", description = "Get the status of an order by its id")
    @dev.langchain4j.agent.tool.Tool("Get the status of an order by its id")
    public String getOrderStatus(
            @ToolArg(description = "The order id, e.g. A-1001") @P("The order id, e.g. A-1001") String orderId) {
        return repository.findById(orderId)
                .map(o -> "Order " + o.id() + " is " + o.status())
                .orElse("Order " + orderId + " not found");
    }

    @io.quarkiverse.mcp.server.Tool(name = "list_recent_orders", description = "List the most recent orders of a customer, newest first")
    @dev.langchain4j.agent.tool.Tool("List the most recent orders of a customer, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. C-1") @P("The customer id, e.g. C-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return", required = false) @P(value = "Maximum number of orders to return", required = false) Integer limit) {
        return repository.findRecentByCustomer(customerId, limit == null ? 5 : limit);
    }
}
