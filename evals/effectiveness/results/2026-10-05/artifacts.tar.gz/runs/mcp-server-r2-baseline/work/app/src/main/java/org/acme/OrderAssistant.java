package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService(tools = OrderTools.class)
public interface OrderAssistant {

    @SystemMessage("""
            You are a customer support assistant for an online store.
            Use the available tools to look up order information. Never invent order data.
            If an order or customer is not found, say so.
            """)
    String answer(@UserMessage String question);
}
