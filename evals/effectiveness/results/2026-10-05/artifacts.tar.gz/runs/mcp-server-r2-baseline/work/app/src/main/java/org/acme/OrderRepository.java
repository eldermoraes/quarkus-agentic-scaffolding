package org.acme;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderRepository() {
        Instant now = Instant.now();
        add(new Order("A-1001", "C-1", "DELIVERED", now.minus(30, ChronoUnit.DAYS), 59.90));
        add(new Order("A-1002", "C-1", "SHIPPED", now.minus(3, ChronoUnit.DAYS), 120.00));
        add(new Order("A-1003", "C-1", "PROCESSING", now.minus(1, ChronoUnit.DAYS), 15.50));
        add(new Order("A-2001", "C-2", "CANCELLED", now.minus(10, ChronoUnit.DAYS), 300.00));
        add(new Order("A-2002", "C-2", "SHIPPED", now.minus(2, ChronoUnit.DAYS), 42.00));
    }

    public void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(orders.get(id));
    }

    public List<Order> findRecentByCustomer(String customerId, int limit) {
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(limit, 0))
                .toList();
    }
}
