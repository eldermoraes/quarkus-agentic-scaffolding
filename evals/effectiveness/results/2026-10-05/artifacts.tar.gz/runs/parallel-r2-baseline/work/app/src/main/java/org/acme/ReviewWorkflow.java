package org.acme;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Runs the technical and business reviewers in parallel and merges their output.
 */
@ApplicationScoped
public class ReviewWorkflow {

    @Inject
    TechnicalReviewer technicalReviewer;

    @Inject
    BusinessReviewer businessReviewer;

    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

    public ReviewReport review(String brief) {
        CompletableFuture<String> technical =
                CompletableFuture.supplyAsync(() -> technicalReviewer.review(brief), executor);
        CompletableFuture<String> business =
                CompletableFuture.supplyAsync(() -> businessReviewer.review(brief), executor);
        return combine(technical.join(), business.join());
    }

    static ReviewReport combine(String technical, String business) {
        String report = """
                # Product Brief Review

                ## Technical Review
                %s

                ## Business Review
                %s
                """.formatted(technical, business);
        return new ReviewReport(technical, business, report);
    }

    @PreDestroy
    void shutdown() {
        executor.shutdown();
    }
}
