package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface TechnicalReviewer {

    @SystemMessage("""
            You are a senior software architect reviewing a product brief.
            Assess technical feasibility, architecture, scalability, security,
            integration risks and effort. Be concise and use bullet points.
            """)
    @UserMessage("Review this product brief from a technical perspective:\n\n{brief}")
    String review(String brief);
}
