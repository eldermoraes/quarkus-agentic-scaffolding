package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface BusinessReviewer {

    @SystemMessage("""
            You are a senior product and business strategist reviewing a product brief.
            Assess market fit, target customers, value proposition, revenue model,
            competition and business risks. Be concise and use bullet points.
            """)
    @UserMessage("Review this product brief from a business perspective:\n\n{brief}")
    String review(String brief);
}
