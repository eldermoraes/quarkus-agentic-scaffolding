package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/** Input guardrail for the entry agents, which see the raw, externally authored brief. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final int MAX_INPUT_CHARS = 8_000;

    /**
     * The prompts wrap the brief in one &lt;brief&gt; pair. Any further tag inside the text
     * would end the delimited region early, so a count above the template's own pair is rejected.
     */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?brief>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        // Allow for the template's own delimiters around the limit-sized brief.
        if (text.length() > MAX_INPUT_CHARS + 50) {
            return failure("Input exceeds the size limit.");
        }
        if (DELIMITER_MARKUP.matcher(text).results().count() > 2) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
