package org.acme.dto;

/** Combined report: both reviews plus a short rendered summary. */
public record ReviewReport(Review technical, Review business, String summary) {}
