package org.acme.rest;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;
import org.acme.dto.BriefInput;
import org.acme.workflow.BriefReviewAgent;
import org.jboss.logging.Logger;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    private static final Logger LOG = Logger.getLogger(ReviewResource.class);

    /** Edge limit on the raw brief; PromptInjectionGuard is the second line of defence. */
    static final int MAX_BRIEF_CHARS = 8_000;

    @Inject
    BriefReviewAgent agent;

    @POST
    public Response review(BriefInput input) {
        String brief = input == null ? null : input.brief();
        if (brief == null || brief.isBlank()) {
            return error(Response.Status.BAD_REQUEST, "Brief must not be empty.");
        }
        if (brief.length() > MAX_BRIEF_CHARS) {
            return error(Response.Status.BAD_REQUEST,
                    "Brief exceeds the " + MAX_BRIEF_CHARS + "-character limit.");
        }
        try {
            return Response.ok(agent.review(brief)).build();
        } catch (Exception e) {
            // Log in full, expose nothing: exception text can carry endpoints or prompt fragments.
            LOG.error("Brief review failed", e);
            return error(Response.Status.INTERNAL_SERVER_ERROR, "Review failed. Please try again.");
        }
    }

    private static Response error(Response.Status status, String message) {
        return Response.status(status).entity(Map.of("error", message)).build();
    }
}
