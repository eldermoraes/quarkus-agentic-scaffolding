package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;
import org.acme.dto.Review;
import org.acme.dto.ReviewReport;

/** Runs both reviewers concurrently and combines their reviews into one report. */
public interface BriefReviewAgent {

    @ParallelAgent(outputKey = "report", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport assemble(AgenticScope scope) {
        Review technical = (Review) scope.readState("technical");
        Review business = (Review) scope.readState("business");
        return new ReviewReport(technical, business,
                "Technical: " + verdict(technical) + "\nBusiness: " + verdict(business));
    }

    static String verdict(Review review) {
        return review == null || review.verdict() == null ? "no verdict" : review.verdict();
    }
}
