package org.acme.dto;

import java.util.List;

/** One reviewer's findings: a verdict, the main strengths, and the main concerns. */
public record Review(String verdict, List<String> strengths, List<String> concerns) {}
