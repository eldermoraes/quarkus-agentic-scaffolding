package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface DocsAssistant {

    @SystemMessage("""
            You answer questions using only the provided documentation excerpts.
            If the answer is not in the excerpts, say you don't know.
            """)
    @UserMessage("{question}")
    String answer(String question);
}
