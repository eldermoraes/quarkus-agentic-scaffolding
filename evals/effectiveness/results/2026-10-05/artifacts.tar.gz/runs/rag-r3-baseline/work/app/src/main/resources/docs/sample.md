# Acme Widget Service

The Acme Widget Service stores and serves widgets over a REST API.

## Limits

Each account may create up to 500 widgets. Requests are rate limited to 100 per minute.

## Support

Support is available on weekdays from 9:00 to 17:00 UTC at support@acme.example.
