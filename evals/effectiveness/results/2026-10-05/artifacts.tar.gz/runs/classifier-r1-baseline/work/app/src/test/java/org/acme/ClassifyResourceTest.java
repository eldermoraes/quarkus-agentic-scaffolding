package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import jakarta.ws.rs.WebApplicationException;
import org.junit.jupiter.api.Test;

class ClassifyResourceTest {

    @Test
    void delegatesToClassifier() {
        ClassifyResource resource = new ClassifyResource();
        resource.classifier = ticket -> Category.BILLING;
        assertEquals(Category.BILLING, resource.classify("I was charged twice").category());
    }

    @Test
    void rejectsBlankTicket() {
        ClassifyResource resource = new ClassifyResource();
        assertThrows(WebApplicationException.class, () -> resource.classify("  "));
    }
}
