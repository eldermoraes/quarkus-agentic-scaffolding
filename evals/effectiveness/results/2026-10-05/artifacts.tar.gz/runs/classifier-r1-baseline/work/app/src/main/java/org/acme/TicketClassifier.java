package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface TicketClassifier {

    @SystemMessage("""
            You classify customer support tickets into exactly one category:
            - BILLING: payments, invoices, charges, refunds, subscriptions, pricing.
            - TECHNICAL: bugs, errors, outages, performance, login or setup problems.
            - OTHER: anything that fits neither of the above.
            Respond with the category only.
            """)
    @UserMessage("Ticket: {ticket}")
    Category classify(String ticket);
}
