package org.acme;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService
public interface TicketClassifier {

    @SystemMessage("""
            You classify customer support tickets into exactly one category:
            - BILLING: payments, invoices, charges, refunds, subscriptions, pricing.
            - TECHNICAL: bugs, errors, outages, login problems, performance, how-to usage of the product.
            - OTHER: anything that fits neither of the above.
            Answer with only the category name.
            """)
    @UserMessage("Ticket:\n{ticket}")
    Category classify(String ticket);
}
