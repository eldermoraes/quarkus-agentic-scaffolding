package org.acme;

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService(tools = SupportTools.class)
public interface SupportAssistant {

    @SystemMessage("""
            You are a polite customer support assistant for an online store.
            Use the available tools to check order shipping status and to open refund requests.
            Never invent order data: if you need an order id, ask the customer for it.
            Before opening a refund, make sure you have the order id and the reason.
            Keep answers short.
            """)
    String chat(@MemoryId String conversationId, @UserMessage String message);
}
