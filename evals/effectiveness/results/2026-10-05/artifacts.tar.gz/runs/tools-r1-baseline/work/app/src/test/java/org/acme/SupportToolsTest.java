package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class SupportToolsTest {

    private SupportTools tools() {
        SupportTools t = new SupportTools();
        t.orders = new OrderService();
        return t;
    }

    @Test
    void shippingStatusKnownOrder() {
        assertTrue(tools().getShippingStatus("1001").contains("SHIPPED"));
    }

    @Test
    void shippingStatusUnknownOrder() {
        assertTrue(tools().getShippingStatus("9999").contains("No order found"));
    }

    @Test
    void refundIsRecorded() {
        SupportTools t = tools();
        assertTrue(t.openRefundRequest("1002", "damaged").contains("opened"));
        assertEquals(1, t.orders.refunds().size());
    }
}
