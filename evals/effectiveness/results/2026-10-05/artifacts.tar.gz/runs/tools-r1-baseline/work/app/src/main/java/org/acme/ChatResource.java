package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/chat")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ChatResource {

    public record ChatRequest(String conversationId, String message) {
    }

    public record ChatResponse(String conversationId, String reply) {
    }

    @Inject
    SupportAssistant assistant;

    @POST
    public Response chat(ChatRequest request) {
        if (request == null || isBlank(request.conversationId()) || isBlank(request.message())) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(new ChatResponse(null, "conversationId and message are required"))
                    .build();
        }
        String reply = assistant.chat(request.conversationId(), request.message());
        return Response.ok(new ChatResponse(request.conversationId(), reply)).build();
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
