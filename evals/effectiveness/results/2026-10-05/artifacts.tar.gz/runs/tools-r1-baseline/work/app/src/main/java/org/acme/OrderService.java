package org.acme;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderService {

    public record Order(String id, String status, String carrier, String estimatedDelivery, double total) {
    }

    public record RefundRequest(String refundId, String orderId, String reason, String status) {
    }

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final List<RefundRequest> refunds = new CopyOnWriteArrayList<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderService() {
        orders.put("1001", new Order("1001", "SHIPPED", "DHL", "2026-10-08", 59.90));
        orders.put("1002", new Order("1002", "DELIVERED", "UPS", "2026-10-01", 120.00));
        orders.put("1003", new Order("1003", "PROCESSING", "n/a", "2026-10-12", 15.50));
    }

    public Optional<Order> find(String orderId) {
        return Optional.ofNullable(orderId == null ? null : orders.get(orderId.trim()));
    }

    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        return find(orderId).map(order -> {
            RefundRequest r = new RefundRequest("R-" + refundSeq.incrementAndGet(), order.id(), reason, "OPEN");
            refunds.add(r);
            return r;
        });
    }

    public List<RefundRequest> refunds() {
        return List.copyOf(refunds);
    }
}
