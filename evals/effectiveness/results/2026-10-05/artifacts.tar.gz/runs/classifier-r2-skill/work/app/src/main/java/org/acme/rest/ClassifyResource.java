package org.acme.rest;

import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.regex.Pattern;
import org.acme.ai.TicketClassifier;
import org.acme.dto.ClassificationResponse;
import org.acme.dto.TicketRequest;
import org.jboss.logging.Logger;

@Path("/classify")
public class ClassifyResource {

    static final int MAX_TICKET_CHARS = 4_000;
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?ticket>", Pattern.CASE_INSENSITIVE);
    private static final Logger LOG = Logger.getLogger(ClassifyResource.class);

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ClassificationResponse classify(TicketRequest request) {
        String text = request == null ? null : request.text();
        if (text == null || text.isBlank()) {
            throw new BadRequestException("Ticket text must not be blank");
        }
        if (text.length() > MAX_TICKET_CHARS) {
            throw new BadRequestException("Ticket text exceeds " + MAX_TICKET_CHARS + " characters");
        }
        if (DELIMITER_MARKUP.matcher(text).find()) {
            throw new BadRequestException("Ticket text contains reserved markup");
        }
        try {
            return new ClassificationResponse(classifier.classify(text));
        } catch (RuntimeException e) {
            LOG.error("Classification failed", e);
            throw new WebApplicationException("Classification unavailable", Response.Status.BAD_GATEWAY);
        }
    }
}
