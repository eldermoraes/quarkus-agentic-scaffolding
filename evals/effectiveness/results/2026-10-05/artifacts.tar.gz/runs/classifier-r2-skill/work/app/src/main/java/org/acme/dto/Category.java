package org.acme.dto;

public enum Category {
    BILLING, TECHNICAL, OTHER
}
