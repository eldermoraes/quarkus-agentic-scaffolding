package org.acme;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.InjectMock;
import io.restassured.http.ContentType;
import org.acme.ai.TicketClassifier;
import org.acme.dto.Category;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.hamcrest.Matchers.equalTo;

@QuarkusTest
class ClassifyResourceTest {

    @InjectMock
    TicketClassifier classifier;

    @Test
    void classifiesTicket() {
        Mockito.when(classifier.classify("I was charged twice")).thenReturn(Category.BILLING);
        given().contentType(ContentType.JSON).body("{\"text\":\"I was charged twice\"}")
                .when().post("/classify")
                .then().statusCode(200).body("category", equalTo("BILLING"));
    }

    @Test
    void rejectsBlankTicket() {
        given().contentType(ContentType.JSON).body("{\"text\":\"  \"}")
                .when().post("/classify")
                .then().statusCode(400);
    }
}
