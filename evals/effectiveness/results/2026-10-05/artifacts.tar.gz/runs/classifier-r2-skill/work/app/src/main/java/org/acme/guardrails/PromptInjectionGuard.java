package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Rejects obviously hostile or oversized input before it reaches the model. Reserved
 * delimiter markup is rejected at the REST edge (see ClassifyResource), where the raw
 * ticket text is still separate from the prompt template.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    // Ticket limit (4000) plus room for the prompt template wrapper.
    private static final int MAX_MESSAGE_CHARS = 4_500;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_MESSAGE_CHARS) {
            return failure("Input is too long.");
        }
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
