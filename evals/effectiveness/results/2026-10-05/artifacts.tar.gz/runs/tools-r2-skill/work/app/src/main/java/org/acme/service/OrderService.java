package org.acme.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.RefundRequest;
import org.acme.dto.ShippingStatus;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();

    public OrderService() {
        LocalDate today = LocalDate.now();
        List.of(
                new Order("1001", "alice@example.com", "Wireless Headphones", ShippingStatus.IN_TRANSIT,
                        "DHL", "DHL123456", today.plusDays(2)),
                new Order("1002", "bob@example.com", "Mechanical Keyboard", ShippingStatus.DELIVERED,
                        "UPS", "UPS987654", today.minusDays(3)),
                new Order("1003", "carol@example.com", "USB-C Dock", ShippingStatus.PROCESSING,
                        null, null, today.plusDays(7)))
                .forEach(o -> orders.put(o.orderId(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(String::trim).map(orders::get);
    }

    /** Opens a refund for the order; returns the existing one if already open. */
    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        return findOrder(orderId).map(o -> refunds.computeIfAbsent(o.orderId(),
                id -> new RefundRequest("RF-" + UUID.randomUUID().toString().substring(0, 8),
                        id, reason, "OPEN")));
    }
}
