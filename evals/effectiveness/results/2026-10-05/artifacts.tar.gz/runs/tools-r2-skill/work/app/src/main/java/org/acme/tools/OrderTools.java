package org.acme.tools;

import org.acme.service.OrderService;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @Tool("Looks up the shipping status of an order by its order id")
    public String getShippingStatus(@P("The order id, e.g. 1001") String orderId) {
        return orders.findOrder(orderId)
                .map(o -> "Order %s (%s): status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s".formatted(
                        o.orderId(), o.item(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an order. Only call after the customer clearly asked for a refund")
    public String openRefundRequest(@P("The order id") String orderId,
            @P("The customer's reason for the refund") String reason) {
        return orders.openRefund(orderId, reason)
                .map(r -> "Refund request %s is %s for order %s".formatted(r.refundId(), r.status(), r.orderId()))
                .orElse("Cannot open refund: no order found with id " + orderId);
    }
}
