package org.acme.dto;

public enum ShippingStatus {
    PROCESSING, SHIPPED, IN_TRANSIT, DELIVERED, CANCELLED
}
