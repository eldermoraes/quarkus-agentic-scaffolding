package org.acme.dto;

import java.time.LocalDate;

public record Order(String orderId, String customerEmail, String item, ShippingStatus status,
        String carrier, String trackingNumber, LocalDate estimatedDelivery) {
}
