package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.SupportAssistant;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderToolsTest {

    @Inject
    OrderTools tools;

    @Inject
    SupportAssistant assistant;

    @Test
    void wiring() {
        assertNotNull(assistant);
    }

    @Test
    void shippingStatus() {
        assertTrue(tools.getShippingStatus("1001").contains("IN_TRANSIT"));
        assertTrue(tools.getShippingStatus("9999").contains("No order found"));
    }

    @Test
    void refund() {
        assertTrue(tools.openRefundRequest("1002", "damaged").contains("OPEN"));
        assertTrue(tools.openRefundRequest("9999", "x").contains("no order found"));
    }
}
