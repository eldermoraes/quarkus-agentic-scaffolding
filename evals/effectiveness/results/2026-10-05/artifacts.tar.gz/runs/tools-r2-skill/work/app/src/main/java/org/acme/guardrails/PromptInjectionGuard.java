package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects obvious prompt-injection attempts in customer text. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final Pattern SUSPICIOUS = Pattern.compile(
            "ignore (all |any )?(previous|prior|above) (instructions|prompts)|reveal (your )?system prompt",
            Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        if (SUSPICIOUS.matcher(userMessage.singleText()).find()) {
            return fatal("Message rejected by input guardrail");
        }
        return success();
    }
}
