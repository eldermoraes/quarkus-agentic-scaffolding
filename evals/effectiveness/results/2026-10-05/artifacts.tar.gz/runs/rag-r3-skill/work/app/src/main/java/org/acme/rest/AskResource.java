package org.acme.rest;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.rag.DocsAssistant;
import org.jboss.logging.Logger;

@Path("/ask")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AskResource {

    private static final Logger LOG = Logger.getLogger(AskResource.class);
    private static final int MAX_QUESTION_CHARS = 4_000;

    public record AskRequest(String question) {
    }

    public record AskResponse(String answer) {
    }

    public record ErrorResponse(String error) {
    }

    @Inject
    DocsAssistant assistant;

    @POST
    public Response ask(AskRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            return error(Response.Status.BAD_REQUEST, "The 'question' field is required.");
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            return error(Response.Status.BAD_REQUEST, "The question is too long.");
        }
        try {
            return Response.ok(new AskResponse(assistant.ask(request.question()))).build();
        } catch (InputGuardrailException e) {
            LOG.warn("Question rejected by input guardrail", e);
            return error(Response.Status.BAD_REQUEST, "The question was rejected.");
        } catch (RuntimeException e) {
            LOG.error("Failed to answer question", e);
            return error(Response.Status.INTERNAL_SERVER_ERROR, "Unable to answer the question right now.");
        }
    }

    private static Response error(Response.Status status, String message) {
        return Response.status(status).entity(new ErrorResponse(message)).build();
    }
}
