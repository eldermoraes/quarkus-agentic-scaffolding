# Quarkus LangChain4j Overview

## What is it?

The Quarkus LangChain4j extensions integrate Large Language Models (LLMs) into Quarkus
applications. AI services are declared as annotated Java interfaces, and Quarkus generates
the implementation at build time.

## Supported providers

Providers include Ollama, OpenAI, Azure OpenAI, Hugging Face and Mistral AI. Ollama runs
models locally, so prompts never leave the machine.

## Retrieval-augmented generation

Retrieval-augmented generation (RAG) lets a model answer from your own documents. The
documents are split into segments, converted into embeddings and stored in an embedding store.
At question time the most similar segments are retrieved and added to the prompt as context.
The Easy RAG extension ingests a folder of documents at startup into an in-memory store.

## Guardrails

Input guardrails validate the user message before it reaches the model; output guardrails
validate the model response and can ask the model to answer again.
