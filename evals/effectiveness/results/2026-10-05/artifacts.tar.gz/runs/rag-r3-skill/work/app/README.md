# docs-qa

RAG question answering over a local folder of Markdown files (Quarkus 3.40 + LangChain4j, Ollama).

- Documents: `docs/*.md` (override the folder with `DOCS_PATH`); ingested at startup by Easy RAG
  into an in-memory store using the in-process bge-small embedding model.
- Chat model: Ollama `qwen3:4b` (`ollama pull qwen3:4b`, `ollama serve`).

## Endpoint

```
curl -X POST localhost:8080/ask -H 'Content-Type: application/json' \
     -d '{"question": "What does Easy RAG do?"}'
# {"answer": "..."}
```

Blank or over-long questions, or ones rejected by the input guardrail, return 400 with `{"error": "..."}`.

## Run

```
./mvnw quarkus:dev
```
