package org.acme;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ReviewResourceTest {

    @Test
    void emptyBriefIsRejected() {
        given().contentType("text/plain").body(" ")
                .when().post("/review")
                .then().statusCode(400);
    }
}
