package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/review")
@Consumes(MediaType.TEXT_PLAIN)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    private static final int MAX_BRIEF_LENGTH = 10_000;

    @Inject
    ReviewWorkflow workflow;

    @POST
    public ReviewReport review(String brief) {
        if (brief == null || brief.isBlank()) {
            throw new BadRequestException("The product brief must not be empty");
        }
        if (brief.length() > MAX_BRIEF_LENGTH) {
            throw new BadRequestException("The product brief is too long");
        }
        return workflow.review(brief);
    }
}
