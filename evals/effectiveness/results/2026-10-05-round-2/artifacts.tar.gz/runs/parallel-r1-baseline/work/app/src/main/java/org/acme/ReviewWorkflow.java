package org.acme;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.service.V;

public interface ReviewWorkflow {

    @ParallelAgent(name = "briefReview", outputKey = "report", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport combine(@V("technicalReview") String technicalReview,
            @V("businessReview") String businessReview) {
        return new ReviewReport(technicalReview, businessReview);
    }
}
