package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.dto.OrderLookup;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/*
 * One implementation backing both surfaces: these LangChain4j @Tool methods are offered to the
 * /assistant model, and org.acme.mcp.OrderMcpServer delegates to them for remote MCP clients.
 * The lookups hit an in-memory map, so no @RunOnVirtualThread is needed; add it when this moves
 * to a database or REST client.
 */
@ApplicationScoped
public class OrderTools {

    static final int DEFAULT_LIMIT = 5;
    static final int MAX_LIMIT = 20;

    @Inject
    OrderStore store;

    @Tool("Gets the status of an order by its id")
    public OrderLookup getOrderStatus(@P("The order id, e.g. 1001") String orderId) {
        Order order = store.find(orderId);
        return order == null ? OrderLookup.notFound(orderId) : OrderLookup.of(order);
    }

    @Tool("Lists the most recent orders of a customer, newest first")
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. alice") String customerId,
            @P("Maximum number of orders to return (default 5, max 20)") Integer limit) {
        int effective = limit == null ? DEFAULT_LIMIT : Math.min(limit, MAX_LIMIT);
        return store.recentForCustomer(customerId, effective);
    }
}
