package org.acme.tools;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.Order.Status;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order storage seeded with sample data. */
@ApplicationScoped
public class OrderStore {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add(new Order("1001", "alice", Status.DELIVERED, now.minus(20, ChronoUnit.DAYS), List.of("Keyboard", "Mouse")));
        add(new Order("1002", "alice", Status.SHIPPED, now.minus(3, ChronoUnit.DAYS), List.of("Monitor")));
        add(new Order("1003", "alice", Status.PENDING, now.minus(1, ChronoUnit.DAYS), List.of("USB-C Cable")));
        add(new Order("2001", "bob", Status.PAID, now.minus(2, ChronoUnit.DAYS), List.of("Laptop Stand")));
        add(new Order("2002", "bob", Status.CANCELLED, now.minus(10, ChronoUnit.DAYS), List.of("Webcam")));
    }

    public void add(Order order) {
        orders.put(order.id(), order);
    }

    public Order find(String id) {
        return id == null ? null : orders.get(id.trim());
    }

    /** Most recent orders first, capped at {@code limit}. */
    public List<Order> recentForCustomer(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(customerId.trim()))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(Math.max(1, limit))
                .toList();
    }
}
