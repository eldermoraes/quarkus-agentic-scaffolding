package org.acme.dto;

import java.time.Instant;
import java.util.List;

public record Order(String id, String customerId, Status status, Instant placedAt, List<String> items) {

    public enum Status { PENDING, PAID, SHIPPED, DELIVERED, CANCELLED }
}
