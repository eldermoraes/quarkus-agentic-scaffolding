package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.dto.OrderLookup;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;

/*
 * MCP server — offers the order operations to remote MCP clients over Streamable HTTP at /mcp.
 * io.quarkiverse.mcp.server.Tool is for remote clients; dev.langchain4j.agent.tool.Tool (in
 * OrderTools) is for our own model. This class delegates so one implementation backs both.
 * In production, put /mcp behind the application's normal access layer (auth policy or gateway).
 */
public class OrderMcpServer {

    @Inject
    OrderTools orders;

    @Tool(name = "get_order_status", description = "Gets the status of an order by its id")
    public OrderLookup getOrderStatus(@ToolArg(description = "The order id, e.g. 1001") String orderId) {
        return orders.getOrderStatus(orderId);
    }

    @Tool(name = "list_recent_orders", description = "Lists the most recent orders of a customer, newest first")
    public List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. alice") String customerId,
            @ToolArg(description = "Maximum number of orders to return (default 5, max 20)", required = false) Integer limit) {
        return orders.listRecentOrders(customerId, limit);
    }
}
