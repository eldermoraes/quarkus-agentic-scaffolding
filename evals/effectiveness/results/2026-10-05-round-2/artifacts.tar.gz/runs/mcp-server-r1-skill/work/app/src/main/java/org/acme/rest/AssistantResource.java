package org.acme.rest;

import org.acme.ai.OrderAssistant;
import org.acme.dto.AssistantRequest;
import org.acme.dto.AssistantResponse;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    private static final int MAX_QUESTION_CHARS = 2_000;

    @Inject
    OrderAssistant assistant;

    @POST
    @RunOnVirtualThread // blocking model + tool round-trips stay off the event loop
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be blank");
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            throw new BadRequestException("question is too long");
        }
        return new AssistantResponse(assistant.answer(request.question()));
    }
}
