package org.acme.dto;

/** Typed tool result: the model (or MCP client) gets an unambiguous found/not-found signal. */
public record OrderLookup(boolean found, Order order, String message) {

    public static OrderLookup of(Order order) {
        return new OrderLookup(true, order, "OK");
    }

    public static OrderLookup notFound(String id) {
        return new OrderLookup(false, null, "No order found with id " + id);
    }
}
