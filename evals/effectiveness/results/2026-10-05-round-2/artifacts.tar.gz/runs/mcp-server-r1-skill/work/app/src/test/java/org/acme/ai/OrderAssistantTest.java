package org.acme.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderAssistantTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void aiServiceIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void statusLookup() {
        assertTrue(tools.getOrderStatus("1002").found());
        assertFalse(tools.getOrderStatus("nope").found());
    }

    @Test
    void recentOrdersNewestFirst() {
        var list = tools.listRecentOrders("alice", 2);
        assertEquals(2, list.size());
        assertEquals("1003", list.get(0).id());
    }
}
