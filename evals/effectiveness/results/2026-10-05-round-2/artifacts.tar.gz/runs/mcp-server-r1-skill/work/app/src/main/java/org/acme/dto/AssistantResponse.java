package org.acme.dto;

public record AssistantResponse(String answer) {}
