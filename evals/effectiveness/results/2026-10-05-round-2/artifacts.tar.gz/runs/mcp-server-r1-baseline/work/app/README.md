# order-tools

Quarkus + LangChain4j app with in-memory order lookups (`get order status by id`, `list recent orders for a customer`).

- **MCP server (streamable HTTP):** `http://localhost:8080/mcp` with tools `getOrderStatus` and `listRecentOrders` (`OrderMcpTools`).
- **REST:** `POST /assistant` with `{"question": "Where is order 1002?"}`. An Ollama-backed assistant (`OrderAssistant`) answers using the same operations as tools (`OrderAiTools`).
- Sample data: customers `alice` (orders 1001-1003) and `bob` (2001-2002).

## Configuration

Ollama endpoint and model are in `src/main/resources/application.properties` (default `http://localhost:11434`, model `llama3.2`). Dev Services are disabled.

## Build

```
./mvnw -B -ntp -DskipTests test-compile
./mvnw quarkus:dev
```
