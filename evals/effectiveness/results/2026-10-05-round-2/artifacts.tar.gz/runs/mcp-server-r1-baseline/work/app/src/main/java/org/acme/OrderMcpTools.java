package org.acme;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.inject.Inject;
import java.util.List;

/** Order operations exposed to remote MCP clients over HTTP. */
public class OrderMcpTools {

    @Inject
    OrderService orders;

    @Tool(description = "Get the status of an order by its id. Returns an error message if not found.")
    String getOrderStatus(@ToolArg(description = "The order id, e.g. 1001") String orderId) {
        return orders.findById(orderId)
                .map(o -> "Order %s is %s".formatted(o.id(), o.status()))
                .orElse("Order not found: " + orderId);
    }

    @Tool(description = "List the most recent orders for a customer, newest first.")
    List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. alice") String customerId,
            @ToolArg(description = "Maximum number of orders to return (1-50)", required = false, defaultValue = "5") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
