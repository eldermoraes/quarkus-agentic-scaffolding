package org.acme;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService() {
        Instant now = Instant.now();
        add(new Order("1001", "alice", "DELIVERED", 59.90, now.minus(30, ChronoUnit.DAYS)));
        add(new Order("1002", "alice", "SHIPPED", 120.00, now.minus(3, ChronoUnit.DAYS)));
        add(new Order("1003", "alice", "PROCESSING", 15.50, now.minus(1, ChronoUnit.DAYS)));
        add(new Order("2001", "bob", "CANCELLED", 42.00, now.minus(10, ChronoUnit.DAYS)));
        add(new Order("2002", "bob", "SHIPPED", 77.25, now.minus(2, ChronoUnit.DAYS)));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(id == null ? null : orders.get(id.trim()));
    }

    public List<Order> recentForCustomer(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        int max = Math.max(1, Math.min(limit, 50));
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(customerId.trim()))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(max)
                .toList();
    }
}
