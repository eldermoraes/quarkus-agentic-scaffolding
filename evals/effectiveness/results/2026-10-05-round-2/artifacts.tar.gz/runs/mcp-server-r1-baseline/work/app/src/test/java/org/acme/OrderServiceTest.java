package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class OrderServiceTest {

    private final OrderService service = new OrderService();

    @Test
    void findsOrderById() {
        assertEquals("SHIPPED", service.findById("1002").orElseThrow().status());
        assertTrue(service.findById("nope").isEmpty());
    }

    @Test
    void listsRecentOrdersNewestFirst() {
        var recent = service.recentForCustomer("alice", 2);
        assertEquals(2, recent.size());
        assertEquals("1003", recent.get(0).id());
    }
}
