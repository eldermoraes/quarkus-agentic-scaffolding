package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.List;

/** The same order operations, exposed as LangChain4j tools to the assistant. */
@ApplicationScoped
public class OrderAiTools {

    @Inject
    OrderService orders;

    @Tool("Get the status of an order by its id. Returns a message if not found.")
    public String getOrderStatus(@P("The order id, e.g. 1001") String orderId) {
        return orders.findById(orderId)
                .map(o -> "Order %s is %s".formatted(o.id(), o.status()))
                .orElse("Order not found: " + orderId);
    }

    @Tool("List the most recent orders for a customer, newest first.")
    public List<Order> listRecentOrders(@P("The customer id, e.g. alice") String customerId,
            @P("Maximum number of orders to return (1-50)") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
