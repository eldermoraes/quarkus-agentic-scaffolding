package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/chat")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ChatResource {

    public record ChatRequest(String conversationId, String message) {}

    public record ChatResponse(String conversationId, String reply) {}

    @Inject
    SupportAgent agent;

    @POST
    @RunOnVirtualThread
    public ChatResponse chat(ChatRequest request) {
        if (request == null || request.conversationId() == null || request.conversationId().isBlank()
                || request.message() == null || request.message().isBlank()) {
            throw new BadRequestException("conversationId and message are required");
        }
        return new ChatResponse(request.conversationId(), agent.chat(request.conversationId(), request.message()));
    }
}
