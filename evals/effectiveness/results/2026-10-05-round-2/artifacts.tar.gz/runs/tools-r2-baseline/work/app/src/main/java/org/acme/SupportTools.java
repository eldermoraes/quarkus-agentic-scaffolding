package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderService orders;

    @Tool("Look up the shipping status of an order by its order id")
    public String getShippingStatus(@P("The order id, e.g. 1001") String orderId) {
        return orders.findOrder(orderId)
                .map(o -> "Order %s (%s): %s, carrier %s, estimated delivery %s"
                        .formatted(o.id(), o.item(), o.state(), o.carrier(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Open a refund request for an order. Only call after the customer clearly asks for a refund")
    public String openRefundRequest(@P("The order id") String orderId, @P("Customer's reason for the refund") String reason) {
        return orders.openRefund(orderId, reason)
                .map(r -> "Refund request %s is %s for order %s".formatted(r.refundId(), r.status(), r.orderId()))
                .orElse("No order found with id " + orderId + "; refund not opened");
    }
}
