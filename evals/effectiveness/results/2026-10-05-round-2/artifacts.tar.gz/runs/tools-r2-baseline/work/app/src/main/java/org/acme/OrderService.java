package org.acme;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order and refund data. */
@ApplicationScoped
public class OrderService {

    public enum ShippingState { PROCESSING, SHIPPED, DELIVERED }

    public record Order(String id, String item, ShippingState state, String carrier, LocalDate estimatedDelivery) {}

    public record RefundRequest(String refundId, String orderId, String reason, String status) {}

    private final Map<String, Order> orders = new ConcurrentHashMap<>(Map.of(
            "1001", new Order("1001", "Wireless headphones", ShippingState.SHIPPED, "DHL", LocalDate.now().plusDays(2)),
            "1002", new Order("1002", "USB-C cable", ShippingState.DELIVERED, "UPS", LocalDate.now().minusDays(3)),
            "1003", new Order("1003", "Mechanical keyboard", ShippingState.PROCESSING, "n/a", LocalDate.now().plusDays(6))));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicLong refundSeq = new AtomicLong(1);

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orders.get(orderId));
    }

    public Optional<RefundRequest> openRefund(String orderId, String reason) {
        if (!orders.containsKey(orderId)) {
            return Optional.empty();
        }
        // One open refund per order: return the existing one if present.
        return Optional.of(refunds.computeIfAbsent(orderId, id ->
                new RefundRequest("R-" + refundSeq.getAndIncrement(), id, reason, "OPEN")));
    }
}
