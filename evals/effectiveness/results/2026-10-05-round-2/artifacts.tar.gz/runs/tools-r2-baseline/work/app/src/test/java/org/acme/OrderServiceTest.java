package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class OrderServiceTest {

    @Test
    void shippingAndRefund() {
        var svc = new OrderService();
        assertEquals(OrderService.ShippingState.SHIPPED, svc.findOrder("1001").orElseThrow().state());
        assertTrue(svc.findOrder("nope").isEmpty());
        assertEquals("OPEN", svc.openRefund("1002", "broken").orElseThrow().status());
        assertTrue(svc.openRefund("nope", "x").isEmpty());
    }
}
