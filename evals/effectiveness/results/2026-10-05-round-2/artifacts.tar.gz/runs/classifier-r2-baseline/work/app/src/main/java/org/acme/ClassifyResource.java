package org.acme;

import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/classify")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ClassifyResource {

    public record TicketRequest(@NotBlank String text) {
    }

    public record ClassifyResponse(Category category) {
    }

    @Inject
    TicketClassifier classifier;

    @POST
    public ClassifyResponse classify(@Valid TicketRequest request) {
        return new ClassifyResponse(classifier.classify(request.text()));
    }
}
