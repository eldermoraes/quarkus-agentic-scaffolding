package org.acme;

public enum Category {
    BILLING, TECHNICAL, OTHER
}
