package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects ticket text that tries to break out of the {@code <ticket>} delimiters. */
@ApplicationScoped
public class TicketInputGuardrail implements InputGuardrail {

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText().toLowerCase();
        // The template contributes exactly one opening and one closing tag.
        if (count(text, "<ticket>") > 1 || count(text, "</ticket>") > 1) {
            return failure("Ticket text must not contain <ticket> delimiters");
        }
        return success();
    }

    private static int count(String text, String token) {
        int n = 0;
        for (int i = text.indexOf(token); i >= 0; i = text.indexOf(token, i + token.length())) {
            n++;
        }
        return n;
    }
}
