package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.service.OrderService;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** Order operations offered to the assistant's model (LangChain4j tools). */
@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @Tool("Get the status and details of an order by its id, e.g. ORD-1001. Returns null if not found.")
    public Order getOrderStatus(@P("The order id") String orderId) {
        return orders.findById(orderId).orElse(null);
    }

    @Tool("List the most recent orders of a customer, newest first.")
    public List<Order> listRecentOrders(
            @P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return (1-50)") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
