package org.acme.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store backing both the MCP server tools and the assistant tools. */
@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, new BigDecimal("59.90"), now.minus(30, ChronoUnit.DAYS)));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, new BigDecimal("120.00"), now.minus(3, ChronoUnit.DAYS)));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PROCESSING, new BigDecimal("15.25"), now.minus(1, ChronoUnit.DAYS)));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.CANCELLED, new BigDecimal("300.00"), now.minus(10, ChronoUnit.DAYS)));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.SHIPPED, new BigDecimal("42.00"), now.minus(2, ChronoUnit.DAYS)));
    }

    public void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return id == null ? Optional.empty() : Optional.ofNullable(orders.get(id.trim().toUpperCase()));
    }

    /** Most recent orders first, capped at {@code limit} (clamped to 1..50). */
    public List<Order> recentForCustomer(String customerId, int limit) {
        int max = Math.max(1, Math.min(limit, 50));
        if (customerId == null) {
            return List.of();
        }
        String wanted = customerId.trim();
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(wanted))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(max)
                .toList();
    }
}
