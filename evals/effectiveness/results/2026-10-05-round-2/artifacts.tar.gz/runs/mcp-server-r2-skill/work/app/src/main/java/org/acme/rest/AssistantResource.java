package org.acme.rest;

import org.acme.ai.OrderAssistant;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    private static final int MAX_QUESTION_LENGTH = 1000;

    public record AssistantRequest(String customerId, String question) {
    }

    public record AssistantResponse(String answer) {
    }

    @Inject
    OrderAssistant assistant;

    @POST
    @RunOnVirtualThread
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || isBlank(request.customerId()) || isBlank(request.question())) {
            throw new BadRequestException("customerId and question are required");
        }
        if (request.question().length() > MAX_QUESTION_LENGTH) {
            throw new BadRequestException("question is too long");
        }
        return new AssistantResponse(assistant.answer(request.customerId(), request.question()));
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
