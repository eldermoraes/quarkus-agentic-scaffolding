package org.acme.mcp;

import java.util.List;

import org.acme.dto.Order;
import org.acme.tools.OrderTools;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import io.quarkiverse.mcp.server.ToolCallException;
import jakarta.inject.Inject;

/** Order operations offered to remote MCP clients (Streamable HTTP at /mcp). */
public class OrderMcpServer {

    @Inject
    OrderTools tools;

    @Tool(name = "get_order_status", description = "Get the status and details of an order by its id, e.g. ORD-1001.")
    Order getOrderStatus(@ToolArg(description = "The order id") String orderId) {
        Order order = tools.getOrderStatus(orderId);
        if (order == null) {
            throw new ToolCallException("Order not found: " + orderId);
        }
        return order;
    }

    @Tool(name = "list_recent_orders", description = "List the most recent orders of a customer, newest first.")
    List<Order> listRecentOrders(
            @ToolArg(description = "The customer id, e.g. CUST-1") String customerId,
            @ToolArg(description = "Maximum number of orders to return (1-50)", defaultValue = "5") int limit) {
        return tools.listRecentOrders(customerId, limit);
    }
}
