package org.acme.dto;

public enum OrderStatus {
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
