package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.OrderAssistant;
import org.acme.service.OrderService;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class OrderWiringTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderService orders;

    @Test
    void assistantIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void recentOrdersAreNewestFirst() {
        var list = orders.recentForCustomer("CUST-1", 2);
        assertEquals(2, list.size());
        assertEquals("ORD-1003", list.get(0).id());
        assertTrue(orders.findById("ORD-9999").isEmpty());
    }
}
