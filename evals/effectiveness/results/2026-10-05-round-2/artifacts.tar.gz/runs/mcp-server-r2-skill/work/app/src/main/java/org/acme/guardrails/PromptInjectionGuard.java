package org.acme.guardrails;

import java.util.regex.Pattern;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Cheap heuristic screen for instruction-override attempts in end-user text. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final Pattern SUSPICIOUS = Pattern.compile(
            "ignore (all |any )?(previous|prior|above) (instructions|rules)"
                    + "|disregard (the |your )?(system|previous) (prompt|instructions)"
                    + "|reveal (the |your )?system prompt"
                    + "|</?\\s*(question|system)\\s*>",
            Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (SUSPICIOUS.matcher(text).find()) {
            return failure("Message rejected by input guardrail");
        }
        return success();
    }
}
