package org.acme.dto;

import java.util.List;

public record TechnicalReview(String assessment, List<String> risks, String verdict) {}
