package org.acme.workflow;

import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.service.V;
import org.acme.ai.BusinessReviewer;
import org.acme.ai.TechnicalReviewer;

/** Runs both reviewers concurrently (declarative parallelism). */
public interface ParallelReviewers {

    @ParallelAgent(outputKey = "reviews", subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    Object run(@V("brief") String brief);
}
