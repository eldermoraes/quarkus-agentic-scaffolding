package org.acme.dto;

public record ReviewReport(TechnicalReview technical, BusinessReview business, String summary) {}
