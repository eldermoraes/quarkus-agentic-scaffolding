package org.acme.dto;

import java.util.List;

public record BusinessReview(String assessment, List<String> risks, String verdict) {}
