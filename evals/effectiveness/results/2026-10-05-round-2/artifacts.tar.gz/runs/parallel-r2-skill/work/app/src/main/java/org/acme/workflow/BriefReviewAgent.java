package org.acme.workflow;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.SequenceAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;
import org.acme.ai.ReportWriter;
import org.acme.dto.BusinessReview;
import org.acme.dto.ReviewReport;
import org.acme.dto.TechnicalReview;

/** Sequence: parallel reviews -> combined report. @Output assembles the result from the scope. */
public interface BriefReviewAgent {

    @SequenceAgent(outputKey = "report", subAgents = { ParallelReviewers.class, ReportWriter.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport assemble(AgenticScope scope) {
        return new ReviewReport(
                (TechnicalReview) scope.readState("technical"),
                (BusinessReview) scope.readState("business"),
                (String) scope.readState("summary"));
    }
}
