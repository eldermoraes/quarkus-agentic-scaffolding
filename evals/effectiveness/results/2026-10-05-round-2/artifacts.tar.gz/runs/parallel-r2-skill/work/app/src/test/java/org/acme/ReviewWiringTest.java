package org.acme;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.workflow.BriefReviewAgent;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: no model call, no running Ollama. */
@QuarkusTest
class ReviewWiringTest {

    @Inject
    BriefReviewAgent agent;

    @Test
    void workflowIsWired() {
        assertNotNull(agent);
    }

    @Test
    void blankBriefIsRejectedBeforeAnyModelCall() {
        given().contentType("application/json").body("{\"brief\":\"  \"}")
                .when().post("/review")
                .then().statusCode(400);
    }
}
