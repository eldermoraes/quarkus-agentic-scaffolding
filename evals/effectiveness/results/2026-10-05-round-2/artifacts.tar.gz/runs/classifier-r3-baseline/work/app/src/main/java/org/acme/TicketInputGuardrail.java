package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects blank or oversized ticket text before it reaches the model. */
@ApplicationScoped
public class TicketInputGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 10_000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return fatal("Ticket text must not be blank");
        }
        if (text.length() > MAX_LENGTH) {
            return fatal("Ticket text exceeds " + MAX_LENGTH + " characters");
        }
        return success();
    }
}
