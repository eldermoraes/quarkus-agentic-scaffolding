package org.acme;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store shared by the MCP tools and the assistant tools. */
@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService() {
        Instant now = Instant.now();
        add(new Order("A-1001", "C-1", "DELIVERED", new BigDecimal("59.90"), now.minus(30, ChronoUnit.DAYS)));
        add(new Order("A-1002", "C-1", "SHIPPED", new BigDecimal("120.00"), now.minus(3, ChronoUnit.DAYS)));
        add(new Order("A-1003", "C-1", "PROCESSING", new BigDecimal("15.25"), now.minus(1, ChronoUnit.DAYS)));
        add(new Order("A-2001", "C-2", "CANCELLED", new BigDecimal("42.00"), now.minus(10, ChronoUnit.DAYS)));
    }

    private void add(Order o) {
        orders.put(o.id(), o);
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(orders.get(id));
    }

    public List<Order> recentForCustomer(String customerId, int limit) {
        int max = Math.max(1, Math.min(limit, 50));
        return orders.values().stream()
                .filter(o -> o.customerId().equals(customerId))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(max)
                .toList();
    }
}
