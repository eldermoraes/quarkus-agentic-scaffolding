package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty, oversized, or delimiter-breaking customer input. */
@ApplicationScoped
public class PromptInjectionGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 2000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return failure("Question must not be empty");
        }
        if (text.length() > MAX_LENGTH) {
            return failure("Question too long");
        }
        if (text.toLowerCase().contains("</question>")) {
            return failure("Invalid question");
        }
        return success();
    }
}
