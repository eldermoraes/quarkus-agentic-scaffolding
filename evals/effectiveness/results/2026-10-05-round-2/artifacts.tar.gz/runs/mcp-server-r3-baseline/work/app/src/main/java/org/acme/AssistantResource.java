package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    public record Question(String question) {
    }

    public record Answer(String answer) {
    }

    @Inject
    OrderAssistant assistant;

    @POST
    @RunOnVirtualThread
    public Answer ask(Question q) {
        return new Answer(assistant.answer(q == null || q.question() == null ? "" : q.question()));
    }
}
