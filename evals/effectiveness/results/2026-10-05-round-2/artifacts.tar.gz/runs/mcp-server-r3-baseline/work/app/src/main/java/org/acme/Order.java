package org.acme;

import java.math.BigDecimal;
import java.time.Instant;

public record Order(String id, String customerId, String status, BigDecimal total, Instant placedAt) {
}
