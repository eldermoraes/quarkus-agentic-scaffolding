package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class OrderServiceTest {

    OrderService service = new OrderService();

    @Test
    void statusById() {
        assertEquals("SHIPPED", service.findById("A-1002").orElseThrow().status());
        assertTrue(service.findById("nope").isEmpty());
    }

    @Test
    void recentNewestFirstAndLimited() {
        var list = service.recentForCustomer("C-1", 2);
        assertEquals(2, list.size());
        assertEquals("A-1003", list.get(0).id());
    }
}
