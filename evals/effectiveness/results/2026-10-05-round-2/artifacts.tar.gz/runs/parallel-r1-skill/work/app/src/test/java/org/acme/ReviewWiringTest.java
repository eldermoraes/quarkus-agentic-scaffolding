package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.workflow.ReviewAgent;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ReviewWiringTest {

    @Inject
    ReviewAgent reviewAgent;

    @Test
    void workflowIsWired() {
        assertNotNull(reviewAgent);
    }
}
