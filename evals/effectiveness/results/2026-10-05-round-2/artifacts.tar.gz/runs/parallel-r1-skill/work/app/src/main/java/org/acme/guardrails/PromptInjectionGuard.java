package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guardrail for entry agents that receive the externally authored product brief.
 * The prompt wraps the brief in {@code <brief>} tags; this guard inspects only the enclosed text.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 8_000;

    private static final String OPEN = "<brief>";
    private static final String CLOSE = "</brief>";

    /** A delimiter smuggled inside the brief would end the data region early. */
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?brief>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int start = text.indexOf(OPEN);
        int end = text.lastIndexOf(CLOSE);
        String brief = (start >= 0 && end > start) ? text.substring(start + OPEN.length(), end) : text;

        if (brief.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(brief).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (brief.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
