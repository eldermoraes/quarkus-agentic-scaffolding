package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.dto.BriefRequest;
import org.acme.dto.ReviewReport;
import org.acme.guardrails.PromptInjectionGuard;
import org.acme.workflow.ReviewAgent;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    @Inject
    ReviewAgent reviewAgent;

    @POST
    @RunOnVirtualThread
    public ReviewReport review(BriefRequest request) {
        // Validate at the edge; escaping exceptions become RFC 9457 problem details.
        if (request == null || request.brief() == null || request.brief().isBlank()) {
            throw new BadRequestException("Brief must not be empty.");
        }
        if (request.brief().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("Brief exceeds the " + PromptInjectionGuard.MAX_INPUT_CHARS
                    + "-character limit.");
        }
        return reviewAgent.review(request.brief());
    }
}
