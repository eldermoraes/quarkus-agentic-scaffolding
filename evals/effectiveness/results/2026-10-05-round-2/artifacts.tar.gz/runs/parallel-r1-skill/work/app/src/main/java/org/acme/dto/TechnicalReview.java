package org.acme.dto;

import java.util.List;

public record TechnicalReview(String summary, List<String> risks, List<String> recommendations) {}
