package org.acme.dto;

public record AskResponse(String answer) {
}
