# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.

## Key features

- **Fast startup**: native executables start in milliseconds.
- **Low memory**: reduced RSS compared to traditional Java stacks.
- **Dev mode**: live reload of code and configuration with `mvn quarkus:dev`.
- **Extensions**: a curated ecosystem of extensions managed by a platform BOM.

## LangChain4j

The `quarkus-langchain4j` extensions let you declare AI services as CDI interfaces
annotated with `@RegisterAiService`. Retrieval-augmented generation is supported
through the Easy RAG extension, which ingests a folder of documents at startup.
