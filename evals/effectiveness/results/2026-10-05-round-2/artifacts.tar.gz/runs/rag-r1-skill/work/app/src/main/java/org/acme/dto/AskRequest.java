package org.acme.dto;

public record AskRequest(String question) {
}
