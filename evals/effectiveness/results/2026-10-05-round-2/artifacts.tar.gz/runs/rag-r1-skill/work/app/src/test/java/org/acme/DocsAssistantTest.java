package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.DocsAssistant;
import org.junit.jupiter.api.Test;

@QuarkusTest
class DocsAssistantTest {

    @Inject
    DocsAssistant assistant;

    @Test
    void wiringSmokeTest() {
        assertNotNull(assistant);
    }
}
