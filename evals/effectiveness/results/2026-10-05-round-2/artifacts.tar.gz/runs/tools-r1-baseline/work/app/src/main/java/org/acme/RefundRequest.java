package org.acme;

public record RefundRequest(String refundId, String orderId, String reason, String status) {
}
