package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderRepository repository;

    @Tool("Looks up the shipping status of an order by its order id (e.g. A1001).")
    public String getShippingStatus(@P("The order id") String orderId) {
        return repository.findOrder(orderId)
                .map(o -> "Order %s (%s): status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s".formatted(
                        o.id(), o.item(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an order. Only call it after the customer explicitly asked for a refund.")
    public String openRefundRequest(@P("The order id") String orderId,
            @P("The customer's reason for the refund") String reason) {
        return repository.findOrder(orderId)
                .map(o -> {
                    var r = repository.openRefund(o, reason);
                    return "Refund request %s for order %s is %s".formatted(r.refundId(), r.orderId(), r.status());
                })
                .orElse("Cannot open refund: no order found with id " + orderId);
    }
}
