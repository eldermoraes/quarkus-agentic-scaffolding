package org.acme;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class ChatResourceTest {

    @Inject
    SupportTools tools;

    @Test
    void shippingStatus() {
        assertTrue(tools.getShippingStatus("a1001").contains("SHIPPED"));
        assertTrue(tools.getShippingStatus("nope").startsWith("No order"));
    }

    @Test
    void refundIsIdempotentPerOrder() {
        String first = tools.openRefundRequest("A1003", "broken");
        assertEquals(first, tools.openRefundRequest("A1003", "again"));
    }

    @Test
    void blankMessageIsRejectedBeforeReachingModel() {
        given().contentType("application/json")
                .body(new ChatResource.ChatRequest("c1", ""))
                .when().post("/chat")
                .then().statusCode(400);
    }
}
