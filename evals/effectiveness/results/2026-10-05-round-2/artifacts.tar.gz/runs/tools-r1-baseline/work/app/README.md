# support-assistant

Customer support assistant (Quarkus + LangChain4j + Ollama) with tool calling.

- Tools (`SupportTools`): look up an order's shipping status; open a refund request (in-memory data in `OrderRepository`; sample orders A1001, A1002, A1003).
- `POST /chat` with `{"conversationId": "c1", "message": "Where is order A1001?"}` returns `{"conversationId": "c1", "reply": "..."}`.
- Per-conversation memory is keyed by `conversationId` (`@MemoryId`, LangChain4j in-memory window).
- Customer text is delimited as data in the prompt and checked by an input guardrail; AI calls have `@Timeout`/`@Retry`/`@Fallback`.

Configure the model in `application.properties` (`quarkus.langchain4j.ollama.*`; Dev Services disabled, expects Ollama at localhost:11434).

Run: `./mvnw quarkus:dev`. OpenAPI/Swagger UI at `/q/swagger-ui`, metrics at `/q/metrics`.
