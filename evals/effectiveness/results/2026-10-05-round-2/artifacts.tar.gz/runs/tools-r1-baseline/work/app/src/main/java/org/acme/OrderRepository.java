package org.acme;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderRepository {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderRepository() {
        List.of(
                new Order("A1001", "ana@example.com", "Wireless headphones", "SHIPPED", "DHL", "DHL-778812",
                        LocalDate.now().plusDays(2)),
                new Order("A1002", "bob@example.com", "Mechanical keyboard", "PROCESSING", null, null,
                        LocalDate.now().plusDays(6)),
                new Order("A1003", "cy@example.com", "USB-C hub", "DELIVERED", "UPS", "UPS-335521",
                        LocalDate.now().minusDays(3)))
                .forEach(o -> orders.put(o.id(), o));
    }

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orderId).map(id -> orders.get(id.trim().toUpperCase()));
    }

    /** Returns the existing refund for the order, or creates one. */
    public RefundRequest openRefund(Order order, String reason) {
        return refunds.computeIfAbsent(order.id(),
                id -> new RefundRequest("R" + refundSeq.incrementAndGet(), id, reason, "OPEN"));
    }
}
