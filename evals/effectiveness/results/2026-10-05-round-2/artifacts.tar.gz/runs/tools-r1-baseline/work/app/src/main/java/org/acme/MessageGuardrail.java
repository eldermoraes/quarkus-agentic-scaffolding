package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects oversized input and any attempt to close the data delimiter early. */
@ApplicationScoped
public class MessageGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 2000;
    private static final String OPEN = "<customer_message>";
    private static final String CLOSE = "</customer_message>";

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return failure("Message must not be empty");
        }
        if (text.length() > MAX_LENGTH + OPEN.length() + CLOSE.length()) {
            return failure("Message too long");
        }
        int start = text.indexOf(OPEN) + OPEN.length();
        int end = text.lastIndexOf(CLOSE);
        if (start < OPEN.length() || end < start || text.substring(start, end).contains(CLOSE)
                || text.substring(start, end).contains(OPEN)) {
            return failure("Invalid message content");
        }
        return success();
    }
}
