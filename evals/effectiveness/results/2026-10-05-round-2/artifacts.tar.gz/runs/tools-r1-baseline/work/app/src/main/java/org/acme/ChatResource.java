package org.acme;

import org.eclipse.microprofile.openapi.annotations.Operation;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/chat")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ChatResource {

    public record ChatRequest(@NotBlank @Size(max = 100) String conversationId,
            @NotBlank @Size(max = MessageGuardrail.MAX_LENGTH) String message) {
    }

    public record ChatResponse(String conversationId, String reply) {
    }

    @Inject
    SupportAssistant assistant;

    @POST
    @RunOnVirtualThread
    @Operation(summary = "Send a customer message within a conversation")
    public ChatResponse chat(@Valid ChatRequest request) {
        return new ChatResponse(request.conversationId(),
                assistant.chat(request.conversationId(), request.message()));
    }
}
