package org.acme;

import java.time.LocalDate;

public record Order(String id, String customerEmail, String item, String status, String carrier,
        String trackingNumber, LocalDate estimatedDelivery) {
}
