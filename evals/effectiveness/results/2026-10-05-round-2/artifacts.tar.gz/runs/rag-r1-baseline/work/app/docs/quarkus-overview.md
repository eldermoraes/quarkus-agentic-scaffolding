# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It offers fast startup times and low memory usage, which suits containers and serverless.

## Dev Mode

Run `mvn quarkus:dev` to start live coding. Code changes are applied on the next request,
and the Dev UI is available at `/q/dev`.

## Native Builds

Quarkus applications can be compiled into native executables with GraalVM using
`mvn package -Dnative`. Native binaries start in milliseconds.

## Extensions

Functionality is added through extensions such as `quarkus-rest`, `quarkus-langchain4j-ollama`
and `quarkus-micrometer-registry-prometheus`. Extension versions are managed by the platform BOM.
