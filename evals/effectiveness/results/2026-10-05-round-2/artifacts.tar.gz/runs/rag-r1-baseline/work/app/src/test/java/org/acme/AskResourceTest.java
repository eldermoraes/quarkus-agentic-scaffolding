package org.acme;

import static io.restassured.RestAssured.given;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
class AskResourceTest {

    @Test
    void blankQuestionIsRejected() {
        given().contentType("application/json").body("{\"question\":\"\"}")
                .when().post("/ask")
                .then().statusCode(400);
    }
}
