package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.acme.dto.OrderStatus;
import org.acme.dto.RefundRequest;

/** In-memory order data and refund requests, exposed to the model as tools. */
@ApplicationScoped
public class OrderTools {

    private final Map<String, OrderStatus> orders = Map.of(
            "1001", new OrderStatus("1001", "SHIPPED", "DHL", "DHL-778812", "2026-10-08"),
            "1002", new OrderStatus("1002", "PROCESSING", "n/a", "n/a", "2026-10-12"),
            "1003", new OrderStatus("1003", "DELIVERED", "UPS", "UPS-445566", "2026-10-01"));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1);

    @Tool("Looks up the shipping status of an order by its order id")
    @RunOnVirtualThread
    public String getOrderStatus(@P("The order id, e.g. 1001") String orderId) {
        return Optional.ofNullable(orders.get(orderId.trim()))
                .map(o -> "Order %s: status=%s, carrier=%s, tracking=%s, estimated delivery=%s"
                        .formatted(o.orderId(), o.status(), o.carrier(), o.trackingNumber(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an existing order. Only call after the customer explicitly asks for a refund and gave a reason")
    @RunOnVirtualThread
    public String openRefundRequest(@P("The order id") String orderId, @P("The customer's reason for the refund") String reason) {
        String id = orderId.trim();
        if (!orders.containsKey(id)) {
            return "Cannot open refund: no order found with id " + orderId;
        }
        // one open refund per order
        RefundRequest created = refunds.computeIfAbsent(id,
                k -> new RefundRequest("RF-" + refundSeq.getAndIncrement(), k, reason, "OPEN"));
        return "Refund request %s for order %s is %s".formatted(created.refundId(), created.orderId(), created.status());
    }
}
