package org.acme.dto;

public record OrderStatus(String orderId, String status, String carrier, String trackingNumber, String estimatedDelivery) {}
