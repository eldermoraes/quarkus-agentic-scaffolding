package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.SupportAssistant;
import org.acme.tools.OrderTools;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    OrderTools tools;

    @Test
    void wiring() {
        assertNotNull(assistant);
    }

    @Test
    void toolsWork() {
        assertTrue(tools.getOrderStatus("1001").contains("SHIPPED"));
        assertTrue(tools.openRefundRequest("1003", "damaged").contains("OPEN"));
        assertTrue(tools.openRefundRequest("9999", "x").contains("no order"));
    }
}
