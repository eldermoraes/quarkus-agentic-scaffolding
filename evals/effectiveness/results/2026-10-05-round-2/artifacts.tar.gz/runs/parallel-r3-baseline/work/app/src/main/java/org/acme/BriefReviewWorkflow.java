package org.acme;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.service.V;

public interface BriefReviewWorkflow {

    @ParallelAgent(name = "brief-review",
            description = "Reviews a product brief technically and commercially in parallel",
            outputKey = "report",
            subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport combine(@V("technicalReview") String technicalReview,
            @V("businessReview") String businessReview) {
        String report = """
                # Product Brief Review

                ## Technical review
                %s

                ## Business review
                %s
                """.formatted(technicalReview, businessReview);
        return new ReviewReport(technicalReview, businessReview, report);
    }
}
