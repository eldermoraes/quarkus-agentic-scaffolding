package org.acme;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty or oversized briefs and any attempt to break out of the {@code <brief>} delimiter. */
@ApplicationScoped
public class BriefInputGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 20_000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text.length() > MAX_LENGTH) {
            return failure("Brief is too long");
        }
        String inner = text.replaceFirst("^<brief>", "").replaceFirst("</brief>$", "");
        if (inner.isBlank()) {
            return failure("Brief is empty");
        }
        if (inner.contains("<brief>") || inner.contains("</brief>")) {
            return failure("Brief contains reserved delimiter tags");
        }
        return success();
    }
}
