package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.TicketClassifier;
import org.junit.jupiter.api.Test;

/** Wiring smoke test: builds the CDI container and AI-service proxy without calling a model. */
@QuarkusTest
class TicketClassifierTest {

    @Inject
    TicketClassifier classifier;

    @Test
    void aiServiceIsWired() {
        assertNotNull(classifier);
    }
}
