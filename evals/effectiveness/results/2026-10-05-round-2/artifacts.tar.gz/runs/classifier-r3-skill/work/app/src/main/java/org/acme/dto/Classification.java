package org.acme.dto;

public record Classification(Category category) {
}
