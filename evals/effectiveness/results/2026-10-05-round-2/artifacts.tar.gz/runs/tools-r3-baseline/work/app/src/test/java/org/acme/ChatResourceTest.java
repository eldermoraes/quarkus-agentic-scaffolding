package org.acme;

import static io.restassured.RestAssured.given;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
class ChatResourceTest {

    @Test
    void rejectsBlankMessage() {
        given().contentType("application/json")
                .body("{\"conversationId\":\"c1\",\"message\":\"\"}")
                .when().post("/chat")
                .then().statusCode(400);
    }
}
