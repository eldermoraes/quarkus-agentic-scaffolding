package org.acme;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of an order by its order id")
    public String getShippingStatus(@P("The order id, e.g. A1001") String orderId) {
        return store.findOrder(orderId)
                .map(o -> "Order %s: status=%s, carrier=%s, estimatedDelivery=%s"
                        .formatted(o.id(), o.status(), o.carrier(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an order and returns the refund id")
    public String openRefundRequest(@P("The order id, e.g. A1001") String orderId,
            @P("The customer's reason for the refund") String reason) {
        try {
            var r = store.openRefund(orderId, reason);
            return "Refund request %s opened for order %s (status %s)".formatted(r.refundId(), r.orderId(), r.status());
        } catch (IllegalArgumentException e) {
            return "Cannot open refund: " + e.getMessage();
        }
    }
}
