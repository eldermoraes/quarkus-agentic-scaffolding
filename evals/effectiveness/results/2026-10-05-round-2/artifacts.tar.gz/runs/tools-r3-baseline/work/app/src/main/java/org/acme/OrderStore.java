package org.acme;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.enterprise.context.ApplicationScoped;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderStore {

    public record Order(String id, String status, String carrier, String estimatedDelivery, double total) {
    }

    public record RefundRequest(String refundId, String orderId, String reason, String status) {
    }

    private final Map<String, Order> orders = new ConcurrentHashMap<>(Map.of(
            "A1001", new Order("A1001", "SHIPPED", "DHL", "2026-10-08", 59.90),
            "A1002", new Order("A1002", "DELIVERED", "UPS", "2026-10-01", 120.00),
            "A1003", new Order("A1003", "PROCESSING", "n/a", "2026-10-12", 15.50)));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public Optional<Order> findOrder(String orderId) {
        return Optional.ofNullable(orders.get(orderId.trim().toUpperCase()));
    }

    public RefundRequest openRefund(String orderId, String reason) {
        var order = findOrder(orderId).orElseThrow(() -> new IllegalArgumentException("Unknown order " + orderId));
        var refund = new RefundRequest("R" + refundSeq.incrementAndGet(), order.id(), reason, "OPEN");
        refunds.put(refund.refundId(), refund);
        return refund;
    }

    public List<RefundRequest> refunds() {
        return List.copyOf(refunds.values());
    }
}
