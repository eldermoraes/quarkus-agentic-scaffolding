# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It offers very fast startup times and low memory usage, which makes it a good fit for
containers and serverless workloads.

## Dev Mode

Running `quarkus dev` (or `mvn quarkus:dev`) starts live coding: source changes are
recompiled and applied on the next request, without restarting the application.

## Native Builds

Quarkus applications can be compiled to a native executable with GraalVM using
`mvn package -Dnative`. Native executables start in milliseconds.

## LangChain4j

The Quarkus LangChain4j extensions integrate large language models through declarative
AI services, annotated with `@RegisterAiService`.
