package org.acme.tools;

import java.util.List;

import org.acme.dto.Order;
import org.acme.service.OrderService;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** Order operations offered to our own model (and reused by the MCP server). */
@ApplicationScoped
public class OrderTools {

    @Inject
    OrderService orders;

    @Tool("Gets the status of an order by its id, e.g. ORD-1001. Returns a not-found message if unknown.")
    @RunOnVirtualThread
    public String getOrderStatus(@P("The order id") String orderId) {
        return orders.findById(orderId)
                .map(o -> "Order %s is %s (placed %s, total %s)".formatted(o.id(), o.status(), o.placedAt(), o.total()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Lists the most recent orders of a customer, newest first.")
    @RunOnVirtualThread
    public List<Order> listRecentOrders(@P("The customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return (1-50)") int limit) {
        return orders.recentForCustomer(customerId, limit);
    }
}
