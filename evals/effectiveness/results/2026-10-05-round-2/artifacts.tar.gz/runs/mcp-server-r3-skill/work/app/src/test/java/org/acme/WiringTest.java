package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.acme.ai.OrderAssistant;
import org.acme.service.OrderService;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class WiringTest {

    @Inject
    OrderAssistant assistant;

    @Inject
    OrderService orders;

    @Test
    void assistantIsWired() {
        assertNotNull(assistant);
    }

    @Test
    void ordersLookup() {
        assertTrue(orders.findById("ORD-1002").isPresent());
        assertEquals("ORD-1003", orders.recentForCustomer("CUST-1", 5).getFirst().id());
    }
}
