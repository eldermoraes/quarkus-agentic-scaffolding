package org.acme.rest;

import org.acme.ai.OrderAssistant;

import dev.langchain4j.guardrail.InputGuardrailException;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    public record AssistantRequest(String question) {
    }

    public record AssistantResponse(String answer) {
    }

    private static final int MAX_QUESTION_CHARS = 2_000;

    @Inject
    OrderAssistant assistant;

    @POST
    @RunOnVirtualThread
    public AssistantResponse ask(AssistantRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be blank");
        }
        if (request.question().length() > MAX_QUESTION_CHARS) {
            throw new BadRequestException("question is too long");
        }
        try {
            return new AssistantResponse(assistant.answer(request.question()));
        } catch (InputGuardrailException e) {
            // Generic message only; the guard's reason stays out of the response.
            throw new BadRequestException("The question was rejected by input validation.");
        }
    }
}
