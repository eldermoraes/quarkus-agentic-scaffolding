package org.acme.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.acme.dto.Order;
import org.acme.dto.OrderStatus;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

/** In-memory order store seeded with sample data. */
@ApplicationScoped
public class OrderService {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    @PostConstruct
    void seed() {
        Instant now = Instant.now();
        add(new Order("ORD-1001", "CUST-1", OrderStatus.DELIVERED, now.minus(20, ChronoUnit.DAYS), new BigDecimal("59.90")));
        add(new Order("ORD-1002", "CUST-1", OrderStatus.SHIPPED, now.minus(3, ChronoUnit.DAYS), new BigDecimal("120.00")));
        add(new Order("ORD-1003", "CUST-1", OrderStatus.PENDING, now.minus(1, ChronoUnit.HOURS), new BigDecimal("15.50")));
        add(new Order("ORD-2001", "CUST-2", OrderStatus.PAID, now.minus(2, ChronoUnit.DAYS), new BigDecimal("310.25")));
        add(new Order("ORD-2002", "CUST-2", OrderStatus.CANCELLED, now.minus(9, ChronoUnit.DAYS), new BigDecimal("42.00")));
    }

    private void add(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> findById(String id) {
        return id == null ? Optional.empty() : Optional.ofNullable(orders.get(id.strip().toUpperCase()));
    }

    /** Most recent orders for a customer, newest first. */
    public List<Order> recentForCustomer(String customerId, int limit) {
        if (customerId == null) {
            return List.of();
        }
        int max = Math.max(1, Math.min(limit, 50));
        String wanted = customerId.strip();
        return orders.values().stream()
                .filter(o -> o.customerId().equalsIgnoreCase(wanted))
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .limit(max)
                .toList();
    }
}
