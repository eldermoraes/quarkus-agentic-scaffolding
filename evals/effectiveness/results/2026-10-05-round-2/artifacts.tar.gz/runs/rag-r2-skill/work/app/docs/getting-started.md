# Getting Started with Acme Widgets

Acme Widgets is a small library for building and composing widgets.

## Installation

Add the `acme-widgets` dependency to your build and run `acme init` to create the
default configuration file `acme.yaml` in your project root.

## Configuration

The `acme.yaml` file supports two settings: `theme` (either `light` or `dark`, default `light`)
and `cache-size` (number of widgets kept in memory, default 100).

## Support

Report problems on the issue tracker. Support is available on weekdays from 9:00 to 17:00 UTC.
