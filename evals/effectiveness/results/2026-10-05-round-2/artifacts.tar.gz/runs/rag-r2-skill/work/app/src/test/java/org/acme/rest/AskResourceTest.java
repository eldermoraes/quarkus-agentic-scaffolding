package org.acme.rest;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.DocsAssistant;
import org.junit.jupiter.api.Test;

@QuarkusTest
class AskResourceTest {

    @Inject
    DocsAssistant assistant;

    @Test
    void aiServiceIsWired() {
        // No model call: proves CDI + AI-service augmentation succeeded.
        assertNotNull(assistant);
    }

    @Test
    void blankQuestionIsRejected() {
        given().contentType("application/json").body("{\"question\":\" \"}")
                .when().post("/ask")
                .then().statusCode(400);
    }
}
