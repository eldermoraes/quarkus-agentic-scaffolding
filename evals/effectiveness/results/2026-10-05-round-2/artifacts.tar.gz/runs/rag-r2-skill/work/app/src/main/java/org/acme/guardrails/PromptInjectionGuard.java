package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Validates the user-authored question wrapped in {@code <question>...</question>} by the
 * AI service prompt. Only the delimited span is inspected: the surrounding wrapper (and any
 * retrieved context appended after it) is not user text.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 2_000;

    /** Reserved delimiter markup: a smuggled tag would end the data region early. */
    public static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?question>", Pattern.CASE_INSENSITIVE);

    private static final String OPEN = "<question>";
    private static final String CLOSE = "</question>";

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int start = text.indexOf(OPEN);
        int end = start < 0 ? -1 : text.indexOf(CLOSE, start);
        if (start < 0 || end < 0) {
            return failure("Input rejected: malformed question.");
        }
        // Exactly one wrapper: a second closing tag means markup was smuggled in.
        if (text.indexOf(CLOSE, end + CLOSE.length()) >= 0) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        String question = text.substring(start + OPEN.length(), end);
        if (question.isBlank()) {
            return failure("Input rejected: empty question.");
        }
        if (question.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(question).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (question.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
