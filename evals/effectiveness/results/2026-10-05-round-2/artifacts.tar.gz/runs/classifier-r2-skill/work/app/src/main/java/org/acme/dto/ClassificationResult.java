package org.acme.dto;

public record ClassificationResult(Category category) {
}
