package org.acme.rest;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.TicketClassifier;
import org.acme.dto.ClassificationResult;
import org.acme.guardrails.PromptInjectionGuard;

@Path("/classify")
public class ClassifyResource {

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public ClassificationResult classify(String ticket) {
        if (ticket == null || ticket.isBlank()) {
            throw new BadRequestException("Ticket text must not be blank.");
        }
        if (ticket.length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("Ticket text is too long.");
        }
        try {
            return new ClassificationResult(classifier.classify(ticket));
        } catch (InputGuardrailException e) {
            throw new BadRequestException("Ticket text was rejected.");
        }
    }
}
