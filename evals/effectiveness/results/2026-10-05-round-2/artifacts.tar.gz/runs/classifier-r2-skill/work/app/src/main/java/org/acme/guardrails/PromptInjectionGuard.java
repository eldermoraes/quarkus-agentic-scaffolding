package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Validates externally originated ticket text before it reaches the model. The prompt wraps the
 * ticket in a single {@code <ticket>…</ticket>} pair; any further delimiter markup inside that
 * span would let the text escape the data region, so it is rejected.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    private static final String OPEN = "<ticket>";
    private static final String CLOSE = "</ticket>";
    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?ticket>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int start = text.indexOf(OPEN);
        int end = text.lastIndexOf(CLOSE);
        String ticket = (start >= 0 && end > start) ? text.substring(start + OPEN.length(), end) : text;

        if (ticket.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(ticket).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (ticket.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
