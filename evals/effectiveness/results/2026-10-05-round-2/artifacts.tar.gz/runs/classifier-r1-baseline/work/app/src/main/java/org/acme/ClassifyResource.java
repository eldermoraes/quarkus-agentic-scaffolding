package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/classify")
public class ClassifyResource {

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    @RunOnVirtualThread
    public ClassificationResult classify(
            @NotBlank @Size(max = TicketInputGuardrail.MAX_LENGTH) String ticketText) {
        return new ClassificationResult(classifier.classify(ticketText));
    }
}
