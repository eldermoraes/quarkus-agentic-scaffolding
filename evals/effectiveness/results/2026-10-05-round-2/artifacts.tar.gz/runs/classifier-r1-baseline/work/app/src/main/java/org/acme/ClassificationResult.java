package org.acme;

public record ClassificationResult(Category category) {
}
