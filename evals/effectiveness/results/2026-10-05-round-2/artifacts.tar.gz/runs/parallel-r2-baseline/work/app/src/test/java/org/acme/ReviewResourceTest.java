package org.acme;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ReviewResourceTest {

    @Test
    void blankBriefIsRejectedWithoutCallingModel() {
        given().contentType("application/json")
                .body(new ReviewResource.BriefRequest("  "))
                .when().post("/review")
                .then().statusCode(400);
    }
}
