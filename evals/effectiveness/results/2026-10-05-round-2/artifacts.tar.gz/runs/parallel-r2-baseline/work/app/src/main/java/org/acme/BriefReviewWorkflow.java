package org.acme;

import dev.langchain4j.agentic.declarative.Output;
import dev.langchain4j.agentic.declarative.ParallelAgent;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.service.V;

/** Runs the technical and business reviewers in parallel and combines their output. */
public interface BriefReviewWorkflow {

    @ParallelAgent(name = "briefReview",
            description = "Reviews a product brief technically and commercially in parallel",
            outputKey = "report",
            subAgents = { TechnicalReviewer.class, BusinessReviewer.class })
    ReviewReport review(@V("brief") String brief);

    @Output
    static ReviewReport combine(AgenticScope scope) {
        String technical = scope.readState("technicalReview", "No technical review produced.");
        String business = scope.readState("businessReview", "No business review produced.");
        String summary = """
                # Product Brief Review

                ## Technical review
                %s

                ## Business review
                %s
                """.formatted(technical, business);
        return new ReviewReport(technical, business, summary);
    }
}
