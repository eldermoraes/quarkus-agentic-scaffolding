package org.acme;

public record ReviewReport(String technicalReview, String businessReview, String summary) {
}
