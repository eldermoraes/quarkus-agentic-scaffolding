package org.acme;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.openapi.annotations.Operation;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    public record BriefRequest(String brief) {
    }

    @Inject
    BriefReviewWorkflow workflow;

    @POST
    @RunOnVirtualThread
    @Operation(summary = "Review a product brief with parallel technical and business reviewers")
    public ReviewReport review(BriefRequest request) {
        if (request == null || request.brief() == null || request.brief().isBlank()) {
            throw new BadRequestException("The brief must not be empty");
        }
        return workflow.review(request.brief());
    }
}
