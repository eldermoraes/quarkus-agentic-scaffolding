# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It is designed for fast startup times and low memory consumption, which makes it a good fit
for containers, serverless functions and microservices.

## Dev Mode

Running `mvn quarkus:dev` starts live coding: code changes are recompiled and applied
automatically on the next request, without restarting the application.

## Native Builds

Quarkus applications can be compiled to a native executable with GraalVM using the
`native` Maven profile (`mvn package -Dnative`). Native executables start in milliseconds.

## LangChain4j

The Quarkus LangChain4j extensions let you declare AI services as CDI interfaces annotated
with `@RegisterAiService`, and support retrieval-augmented generation (RAG) out of the box.
