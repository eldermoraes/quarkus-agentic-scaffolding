package org.acme.rest;

import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.DocsAssistant;
import org.acme.dto.AskRequest;
import org.acme.dto.AskResponse;

@Path("/ask")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AskResource {

    @Inject
    DocsAssistant assistant;

    @POST
    public AskResponse ask(AskRequest request) {
        if (request == null || request.question() == null || request.question().isBlank()) {
            throw new BadRequestException("question must not be blank");
        }
        return new AskResponse(assistant.ask(request.question()));
    }
}
