package org.acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;

@QuarkusTest
class OrderServiceTest {

    @Inject
    OrderService orders;

    @Test
    void statusById() {
        assertEquals(OrderStatus.SHIPPED, orders.findById("ORD-1002").orElseThrow().status());
        assertTrue(orders.findById("nope").isEmpty());
    }

    @Test
    void recentOrdersNewestFirst() {
        var list = orders.recentForCustomer("CUST-1", 2);
        assertEquals(2, list.size());
        assertEquals("ORD-1003", list.get(0).id());
    }
}
