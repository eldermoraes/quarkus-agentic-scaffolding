package org.acme;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/assistant")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AssistantResource {

    public record AssistantRequest(String customerId, String question) {
    }

    public record AssistantResponse(String answer) {
    }

    @Inject
    OrderAssistant assistant;

    @POST
    public AssistantResponse ask(AssistantRequest request) {
        return new AssistantResponse(assistant.answer(request.customerId(), request.question()));
    }
}
