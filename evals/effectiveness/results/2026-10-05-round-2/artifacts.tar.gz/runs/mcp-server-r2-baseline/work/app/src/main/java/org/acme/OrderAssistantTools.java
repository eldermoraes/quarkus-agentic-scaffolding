package org.acme;

import java.util.List;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/** The same order operations, exposed to the LLM assistant. */
@ApplicationScoped
public class OrderAssistantTools {

    @Inject
    OrderService orders;

    @Tool("Get an order by its id, including its status.")
    public String getOrderStatus(@P("Order id, e.g. ORD-1001") String orderId) {
        return orders.findById(orderId).map(Order::toString).orElse("Order not found: " + orderId);
    }

    @Tool("List the most recent orders of a customer, newest first.")
    public List<Order> listRecentOrders(@P("Customer id, e.g. CUST-1") String customerId,
            @P("Maximum number of orders to return") int limit) {
        return orders.recentForCustomer(customerId, limit <= 0 ? 5 : limit);
    }
}
