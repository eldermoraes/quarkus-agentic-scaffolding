package org.acme;

import java.util.Locale;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects empty, oversized, or delimiter-breaking customer input before it reaches the model. */
@ApplicationScoped
public class PromptInjectionGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 1200;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        if (text == null || text.isBlank()) {
            return failure("Question must not be empty");
        }
        if (text.length() > MAX_LENGTH) {
            return failure("Question is too long");
        }
        String lower = text.toLowerCase(Locale.ROOT);
        // The prompt wraps input in <question>/<customer>; input must not be able to close those spans.
        int closers = count(lower, "</question>") + count(lower, "</customer>");
        if (closers > 1 || lower.contains("ignore previous instructions")) {
            return failure("Question contains disallowed content");
        }
        return success();
    }

    private static int count(String text, String needle) {
        int n = 0;
        for (int i = text.indexOf(needle); i >= 0; i = text.indexOf(needle, i + 1)) {
            n++;
        }
        return n;
    }
}
