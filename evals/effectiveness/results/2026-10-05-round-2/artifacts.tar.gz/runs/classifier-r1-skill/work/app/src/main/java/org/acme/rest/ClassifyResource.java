package org.acme.rest;

import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.ai.TicketClassifier;
import org.acme.dto.ClassifyResponse;

@Path("/classify")
public class ClassifyResource {

    @Inject
    TicketClassifier classifier;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public ClassifyResponse classify(String ticket) {
        if (ticket == null || ticket.isBlank()) {
            throw new BadRequestException("Ticket text must not be blank.");
        }
        return new ClassifyResponse(classifier.classify(ticket));
    }
}
