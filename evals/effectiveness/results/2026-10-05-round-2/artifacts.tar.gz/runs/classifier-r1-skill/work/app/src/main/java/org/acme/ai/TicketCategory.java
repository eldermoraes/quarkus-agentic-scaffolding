package org.acme.ai;

public enum TicketCategory {
    BILLING, TECHNICAL, OTHER
}
