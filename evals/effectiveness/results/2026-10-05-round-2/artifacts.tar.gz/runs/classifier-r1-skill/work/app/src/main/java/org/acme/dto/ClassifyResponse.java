package org.acme.dto;

import org.acme.ai.TicketCategory;

public record ClassifyResponse(TicketCategory category) {
}
