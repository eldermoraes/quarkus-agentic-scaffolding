# Quarkus Overview

Quarkus is a Kubernetes-native Java framework tailored for GraalVM and HotSpot.
It offers fast startup times and low memory consumption, and supports both
imperative and reactive programming models.

## Dev Mode

Run `mvn quarkus:dev` to start live coding. Code changes are applied on the
next request without a manual restart. The Dev UI is available at `/q/dev`.

## Native Builds

Build a native executable with `mvn package -Dnative`. Native images start in
milliseconds and use far less memory than a regular JVM process.

## Extensions

Quarkus extensions integrate libraries such as REST, Hibernate ORM and
LangChain4j. Extension versions are managed by the Quarkus platform BOM.
