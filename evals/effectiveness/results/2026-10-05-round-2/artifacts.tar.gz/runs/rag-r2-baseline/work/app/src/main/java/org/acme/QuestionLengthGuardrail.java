package org.acme;

import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import dev.langchain4j.data.message.UserMessage;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class QuestionLengthGuardrail implements InputGuardrail {

    static final int MAX_LENGTH = 2000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        if (userMessage.singleText().length() > MAX_LENGTH) {
            return failure("Question is too long");
        }
        return success();
    }
}
