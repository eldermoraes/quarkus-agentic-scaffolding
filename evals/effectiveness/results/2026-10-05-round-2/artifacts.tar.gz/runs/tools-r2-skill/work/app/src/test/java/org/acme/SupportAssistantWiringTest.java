package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.acme.ai.SupportAssistant;
import org.acme.tools.SupportTools;
import org.junit.jupiter.api.Test;

@QuarkusTest
class SupportAssistantWiringTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    SupportTools tools;

    @Test
    void wiring() {
        assertNotNull(assistant);
    }

    @Test
    void toolsWork() {
        assertTrue(tools.getOrderStatus("ord-1001").contains("SHIPPED"));
        assertTrue(tools.openRefundRequest("ORD-1001", "damaged").contains("RF-"));
        assertTrue(tools.openRefundRequest("NOPE", "x").contains("no order"));
    }
}
