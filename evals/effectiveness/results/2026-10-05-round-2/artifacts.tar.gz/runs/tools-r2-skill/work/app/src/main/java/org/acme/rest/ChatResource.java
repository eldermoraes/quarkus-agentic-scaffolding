package org.acme.rest;

import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.regex.Pattern;
import org.acme.ai.SupportAssistant;
import org.acme.dto.ChatRequest;
import org.acme.dto.ChatResponse;
import org.acme.guardrails.PromptInjectionGuard;

@Path("/chat")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ChatResource {

    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?customer_message>", Pattern.CASE_INSENSITIVE);

    @Inject
    SupportAssistant assistant;

    @POST
    public ChatResponse chat(ChatRequest request) {
        if (request == null || request.message() == null || request.message().isBlank()) {
            throw new BadRequestException("message must not be blank");
        }
        if (request.conversationId() == null || request.conversationId().isBlank()) {
            throw new BadRequestException("conversationId must not be blank");
        }
        if (request.message().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("message is too long");
        }
        // A smuggled closing tag would end the delimited region early.
        if (DELIMITER_MARKUP.matcher(request.message()).find()) {
            throw new BadRequestException("message contains reserved markup");
        }
        String reply = assistant.chat(request.conversationId(), request.message());
        return new ChatResponse(request.conversationId(), reply);
    }
}
