package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 4_000;

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        // The rendered prompt adds a short delimiter wrapper around the customer text.
        if (text.length() > MAX_INPUT_CHARS + 200) {
            return failure("Input exceeds the length limit.");
        }
        // Honest heuristic — real projects tune this (allow-lists, a classifier model, ...).
        if (text.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
