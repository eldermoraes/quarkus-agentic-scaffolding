package org.acme.dto;

public record ChatRequest(String conversationId, String message) {
}
