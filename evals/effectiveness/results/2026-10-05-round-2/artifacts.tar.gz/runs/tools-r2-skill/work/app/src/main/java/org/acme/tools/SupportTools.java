package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.acme.dto.Order;
import org.acme.dto.RefundRequest;

/** In-memory order and refund data exposed to the model as tools. */
@ApplicationScoped
public class SupportTools {

    private final Map<String, Order> orders = Map.of(
            "ORD-1001", new Order("ORD-1001", "Alice", "SHIPPED", "DHL", "DHL123456", "2026-10-08", 59.90),
            "ORD-1002", new Order("ORD-1002", "Bob", "PROCESSING", null, null, "2026-10-12", 120.00),
            "ORD-1003", new Order("ORD-1003", "Carol", "DELIVERED", "UPS", "UPS987654", "2026-09-30", 24.50));

    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    @Tool("Looks up the shipping status of an order by its id (for example ORD-1001).")
    public String getOrderStatus(@P("The order id, e.g. ORD-1001") String orderId) {
        Order o = orders.get(normalize(orderId));
        if (o == null) {
            return "No order found with id " + orderId;
        }
        return "Order %s: status=%s, carrier=%s, tracking=%s, estimatedDelivery=%s".formatted(
                o.id(), o.status(), o.carrier() == null ? "n/a" : o.carrier(),
                o.trackingNumber() == null ? "n/a" : o.trackingNumber(), o.estimatedDelivery());
    }

    @Tool("Opens a refund request for an existing order and returns the refund id. "
            + "Only call this after the customer has clearly asked for a refund.")
    public String openRefundRequest(@P("The order id, e.g. ORD-1001") String orderId,
            @P("Short reason for the refund") String reason) {
        String id = normalize(orderId);
        if (!orders.containsKey(id)) {
            return "Cannot open refund: no order found with id " + orderId;
        }
        String refundId = "RF-" + refundSeq.incrementAndGet();
        refunds.put(refundId, new RefundRequest(refundId, id, reason, "OPEN"));
        Log.infof("Refund %s opened for order %s", refundId, id);
        return "Refund request %s opened for order %s (status OPEN)".formatted(refundId, id);
    }

    private static String normalize(String orderId) {
        return orderId == null ? "" : orderId.trim().toUpperCase();
    }
}
