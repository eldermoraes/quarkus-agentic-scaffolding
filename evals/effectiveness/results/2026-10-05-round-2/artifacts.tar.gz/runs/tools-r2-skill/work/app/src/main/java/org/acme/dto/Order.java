package org.acme.dto;

public record Order(String id, String customer, String status, String carrier, String trackingNumber,
        String estimatedDelivery, double total) {
}
