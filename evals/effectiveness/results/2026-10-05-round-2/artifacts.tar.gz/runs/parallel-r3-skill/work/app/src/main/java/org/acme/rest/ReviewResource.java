package org.acme.rest;

import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.acme.dto.ReviewReport;
import org.acme.dto.ReviewRequest;
import org.acme.guardrails.PromptInjectionGuard;
import org.acme.workflow.BriefReviewAgent;
import org.eclipse.microprofile.openapi.annotations.Operation;

@Path("/review")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReviewResource {

    @Inject
    BriefReviewAgent agent;

    @POST
    @RunOnVirtualThread
    @Operation(summary = "Review a product brief with a technical and a business reviewer in parallel")
    public ReviewReport review(ReviewRequest request) {
        // Validate at the edge, before any model call.
        if (request == null || request.brief() == null || request.brief().isBlank()) {
            throw new BadRequestException("brief must not be empty");
        }
        if (request.brief().length() > PromptInjectionGuard.MAX_INPUT_CHARS) {
            throw new BadRequestException("brief exceeds the " + PromptInjectionGuard.MAX_INPUT_CHARS + "-character limit");
        }
        return agent.review(request.brief());
    }
}
