package org.acme.dto;

import java.util.List;

public record BusinessReview(String summary, List<String> risks, List<String> recommendations) {}
