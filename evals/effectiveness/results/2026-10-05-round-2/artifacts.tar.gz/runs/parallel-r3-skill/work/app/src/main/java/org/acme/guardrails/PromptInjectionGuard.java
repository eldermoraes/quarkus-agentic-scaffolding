package org.acme.guardrails;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.regex.Pattern;

/**
 * Input guardrail for agents that receive the externally authored product brief. The prompt
 * wraps the brief in one pair of {@code <brief>} markers, so the guard strips that outer pair
 * and checks what the author wrote: a smuggled marker would end the delimited region early.
 */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    public static final int MAX_INPUT_CHARS = 8_000;

    private static final Pattern DELIMITER_MARKUP =
            Pattern.compile("</?brief>", Pattern.CASE_INSENSITIVE);

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        String text = userMessage.singleText();
        int open = text.indexOf("<brief>");
        int close = text.lastIndexOf("</brief>");
        String brief = open >= 0 && close > open ? text.substring(open + "<brief>".length(), close) : text;
        if (brief.length() > MAX_INPUT_CHARS) {
            return failure("Input exceeds the " + MAX_INPUT_CHARS + "-character limit.");
        }
        if (DELIMITER_MARKUP.matcher(brief).find()) {
            return failure("Input rejected: it contains reserved delimiter markup.");
        }
        if (brief.toLowerCase().contains("ignore previous instructions")) {
            return failure("Input rejected: possible prompt-injection marker.");
        }
        return success();
    }
}
