package org.acme.rest;

import static io.restassured.RestAssured.given;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
class ReviewResourceTest {

    @Test
    void blankBriefIsRejectedWithoutCallingTheModel() {
        given().contentType("application/json").body("{\"brief\":\"  \"}")
                .when().post("/review")
                .then().statusCode(400);
    }
}
