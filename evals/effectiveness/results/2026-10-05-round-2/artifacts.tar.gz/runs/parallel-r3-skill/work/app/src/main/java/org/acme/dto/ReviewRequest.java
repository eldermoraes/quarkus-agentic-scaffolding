package org.acme.dto;

public record ReviewRequest(String brief) {}
