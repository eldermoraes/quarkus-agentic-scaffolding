package org.acme.dto;

import java.time.LocalDate;

public record Order(String id, String item, ShippingStatus status, String carrier, LocalDate estimatedDelivery) {

    public enum ShippingStatus {
        PROCESSING, SHIPPED, IN_TRANSIT, DELIVERED, CANCELLED
    }
}
