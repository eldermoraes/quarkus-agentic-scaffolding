package org.acme.tools;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import io.smallrye.common.annotation.RunOnVirtualThread;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import org.acme.dto.Order.ShippingStatus;
import org.acme.service.OrderStore;

@ApplicationScoped
public class SupportTools {

    @Inject
    OrderStore store;

    @Tool("Looks up the shipping status of an order by its order id (e.g. A1001).")
    @RunOnVirtualThread
    public String getShippingStatus(@P("The order id, e.g. A1001") String orderId) {
        return store.find(orderId)
                .map(o -> "Order %s (%s): status=%s, carrier=%s, estimatedDelivery=%s"
                        .formatted(o.id(), o.item(), o.status(), o.carrier(), o.estimatedDelivery()))
                .orElse("No order found with id " + orderId);
    }

    @Tool("Opens a refund request for an existing order. Only call after the customer clearly asked for a refund and gave a reason.")
    @RunOnVirtualThread
    public String openRefundRequest(@P("The order id, e.g. A1001") String orderId,
            @P("The customer's reason for the refund") String reason) {
        var order = store.find(orderId);
        if (order.isEmpty()) {
            return "No order found with id " + orderId;
        }
        if (order.get().status() == ShippingStatus.CANCELLED) {
            return "Order %s is already cancelled; no refund can be opened.".formatted(order.get().id());
        }
        var refund = store.openRefund(order.get(), reason);
        return "Refund request %s opened for order %s (status %s)."
                .formatted(refund.refundId(), refund.orderId(), refund.status());
    }
}
