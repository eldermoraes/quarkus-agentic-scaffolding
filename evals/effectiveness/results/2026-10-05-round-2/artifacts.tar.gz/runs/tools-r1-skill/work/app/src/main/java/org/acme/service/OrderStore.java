package org.acme.service;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.enterprise.context.ApplicationScoped;

import org.acme.dto.Order;
import org.acme.dto.Order.ShippingStatus;
import org.acme.dto.RefundRequest;

/** In-memory orders and refund requests. */
@ApplicationScoped
public class OrderStore {

    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    private final Map<String, RefundRequest> refunds = new ConcurrentHashMap<>();
    private final AtomicInteger refundSeq = new AtomicInteger(1000);

    public OrderStore() {
        var today = LocalDate.now();
        put(new Order("A1001", "Wireless headphones", ShippingStatus.IN_TRANSIT, "DHL", today.plusDays(2)));
        put(new Order("A1002", "Mechanical keyboard", ShippingStatus.DELIVERED, "UPS", today.minusDays(3)));
        put(new Order("A1003", "USB-C dock", ShippingStatus.PROCESSING, "n/a", today.plusDays(6)));
        put(new Order("A1004", "Standing desk", ShippingStatus.CANCELLED, "n/a", today));
    }

    private void put(Order order) {
        orders.put(order.id(), order);
    }

    public Optional<Order> find(String orderId) {
        return Optional.ofNullable(orderId).map(id -> orders.get(id.trim().toUpperCase()));
    }

    public RefundRequest openRefund(Order order, String reason) {
        var id = "R" + refundSeq.incrementAndGet();
        var refund = new RefundRequest(id, order.id(), reason, "OPEN");
        refunds.put(id, refund);
        return refund;
    }
}
