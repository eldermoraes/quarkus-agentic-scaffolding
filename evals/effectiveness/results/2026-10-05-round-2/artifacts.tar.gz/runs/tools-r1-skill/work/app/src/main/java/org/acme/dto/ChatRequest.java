package org.acme.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ChatRequest(
        @NotBlank String conversationId,
        @NotBlank @Size(max = 2000) String message) {
}
