package org.acme.guardrails;

import java.util.List;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;

/** Rejects obvious prompt-injection attempts in customer-authored text. */
@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private static final List<String> MARKERS = List.of(
            "ignore previous instructions",
            "ignore all previous instructions",
            "disregard the system prompt",
            "reveal your system prompt",
            "</customer_message>");

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        var text = userMessage.singleText().toLowerCase();
        for (var marker : MARKERS) {
            if (text.contains(marker)) {
                return failure("Message rejected by the prompt-injection guard.");
            }
        }
        return success();
    }
}
