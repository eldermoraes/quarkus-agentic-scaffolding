package org.acme;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

import org.acme.ai.SupportAssistant;
import org.acme.tools.SupportTools;

@QuarkusTest
class SupportAssistantTest {

    @Inject
    SupportAssistant assistant;

    @Inject
    SupportTools tools;

    @Test
    void wiring() {
        assertNotNull(assistant);
    }

    @Test
    void toolsUseInMemoryData() {
        assertTrue(tools.getShippingStatus("A1001").contains("IN_TRANSIT"));
        assertTrue(tools.openRefundRequest("A1002", "damaged").contains("opened"));
        assertTrue(tools.openRefundRequest("ZZZ", "x").contains("No order found"));
    }
}
