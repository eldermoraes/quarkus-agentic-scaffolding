package org.acme.rest;

import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import org.acme.ai.SupportAssistant;
import org.acme.dto.ChatRequest;
import org.acme.dto.ChatResponse;

@Path("/chat")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ChatResource {

    @Inject
    SupportAssistant assistant;

    @POST
    public ChatResponse chat(@Valid ChatRequest request) {
        var reply = assistant.chat(request.conversationId(), request.message());
        return new ChatResponse(request.conversationId(), reply);
    }
}
