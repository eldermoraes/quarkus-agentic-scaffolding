package org.acme.dto;

public record ChatResponse(String conversationId, String reply) {
}
