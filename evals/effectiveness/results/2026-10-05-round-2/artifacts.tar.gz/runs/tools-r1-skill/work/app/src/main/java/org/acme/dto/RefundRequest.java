package org.acme.dto;

public record RefundRequest(String refundId, String orderId, String reason, String status) {
}
